package test;

/*
* 
*   T Hydrofoil Simulator. 
*
*------------------------------------------------------------------------------ 
*
* (c) dmitrynizh 2016.  This software is in the Public Domain.  It may
* be freely copied and used in non-commercial products, assuming
* proper credit to the author is given.  IT MAY NOT BE RESOLD.  If you
* want to use the software for commercial products, contact the
* author.  No copyright is claimed in the United States under Title
* 17, U. S. Code.  This software is provided "as is" without any
* warranty of any kind, either express, implied, or statutory,
* including, but not limited to, any warranty that the software will
* conform to specifications, any implied warranties of
* merchantability, fitness for a particular purpose, and freedom from
* infringement, and any warranty that the documentation will conform
* to the program, or any warranty that the software will be error
* free.  In no event shall NASA be liable for any damages, including,
* but not limited to direct, indirect, special or consequential
* damages, arising out of, resulting from, or in any way connected
* with this software, whether or not based on warranty, contract, tort
* or otherwise, whether or not injury was sustained by persons or
* property or otherwise, and whether or not loss was sustained from,
* or arose out of the results of, or use of, the software or services
* provided hereunder.
*
*------------------------------------------------------------------------------
*
* This foil simulator is derived from "FoilSim III", see its copyright
* and header of FoilSim below.
* 
* This simulator computes lift and drag for a T-shape hydrofoil having
* a vertical strut a.k.a. mast, a main wing, a stabilizer wing, and a
* fuselage. 
*
*
* FoilBoardWithProblems,java contains significant section of re-indented code from Foil.java code. To diff with original, use
* diff -n -r -w
*
*----From FoilSim.java, https://www.grc.nasa.gov/www/k-12/FoilSim------------- 

                      FoilSim III  - Airfoil  mode
   
                           A Java Applet
               to perform Kutta-Joukowski Airfoil analysis
                including drag from wind tunnel tests

                     Version 1.5b   - 3 Sep 13

                              Written by 

                               Tom Benson
                       NASA Glenn Research Center

                                 and
              
                               Anthony Vila
                          Vanderbilt University

>                                NOTICE
>This software is in the Public Domain.  It may be freely copied and used in
>non-commercial products, assuming proper credit to the author is given.  IT
>MAY NOT BE RESOLD.  If you want to use the software for commercial
>products, contact the author.
>No copyright is claimed in the United States under Title 17, U. S. Code.
>This software is provided "as is" without any warranty of any kind, either
>express, implied, or statutory, including, but not limited to, any warranty
>that the software will conform to specifications, any implied warranties of
>merchantability, fitness for a particular purpose, and freedom from
>infringement, and any warranty that the documentation will conform to the
>program, or any warranty that the software will be error free.
>In no event shall NASA be liable for any damages, including, but not
>limited to direct, indirect, special or consequential damages, arising out
>of, resulting from, or in any way connected with this software, whether or
>not based on warranty, contract, tort or otherwise, whether or not injury
>was sustained by persons or property or otherwise, and whether or not loss
>was sustained from, or arose out of the results of, or use of, the software
>or services provided hereunder.
 
  New test -
             * include the drag
             * rename modules and change layout
             * change the color scheme on the plots
             * correct lift of ball from CurveBall
             * change pressure and velocity plots for stalled airfoil
             * add reynolds number calculation
               get moment coefficient - FoilSim IV
               put separation bubble on airfoil graphics - FoilSim IV

                                           TJB  22 Jun 10

  New Test B
           * -Build Drag Data Interpolator to incorporate drag results
             * -Implement interpolator into program (create drag output results textbar)
           * -get drag of elliptical foils

                                           AJV 7/14/10
  New Test C
           *  add drag plots and interpolated data
           *  move plot selection to input side
           *  add analysis panel - 
           *  make input and output buttons - not drop down
           *  add reynolds correction to airfoil - make optional
           *  add induced drag to drag calculation  - make optional
           *  add drag to gage output
           *  add smooth ball / rough ball option 
           *  release as FoilSim III
                                            TJB 29 July 10
           *  move metric/imperial units back on control panel - based on user inputs
           *  add some standard shapes to Shape input with buttons
                                            TJB 23 Nov 10
           *  fix up a symmetry problem for negative camber and drag 
           *  fix up a plotting problem for drag involving the induced drag
                                             TJB 29 Nov 10
           * change number of sig fig on graphs - small airfoils
                                             TJB 17 Feb 11
           * add volume of the wing to the printed output - option "Geometry"
                                             TJB 21 Mar 11
           * add Venus surface atmospherics (need to fix viscosity)
                                             TJB 20 Feb 13
             add relative humidty to the flight input
                                             TJB 3 Sep 13
                                                                                          
*/



//
//web_Ready
//web_AppletName= FoilBoardWithProblems
//web_Description= Foil + Foil + Fuse + Mast + Board!
//web_JavaVersion= http://www.dmitrynizh.com
//web_AppletImage= no
//web_Category= foiling
//web_Date= $Date: 2017-01-01 06:08:18 +0000 (Sun, 01 Jan 2017) $
//web_Features= graphics, AWT-to-Swing

//
//Conversion to JavaScriipt using the SwingJS system by Bob Hanson, Nadia El Mouldi, and Andreas Raduege (St. Olaf College) 
//
//import javax.swing.applet.Applet --> a2s
//
//import java.awt [Applet, Canvas, Checkbox, Choice, Label, Scrollbar] --> a2s
//
//Changed paint() to paintComponent() in BarWavesCanvas and BarWavesFrame
//
//dded Container main and added components to main
//
//resize and show --> useFrame options
//
//added triggerShow()
//
//BH      engine = new Thread(runnable); is not implemented in SwingJS  

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;

import a2s.Applet;
import a2s.Checkbox;
//import a2s.Button;
import a2s.Choice;
import a2s.Label;
import a2s.Scrollbar;
import a2s.TextArea;
import a2s.TextField;

// dmitrynizh: this has been expanded 
//import java.awt.*;

public class FoilBoardWithProblems extends Applet {
  static boolean inited = false;
  

  /**
   * Panel is a substitute for legacy java.awt.Panel for JS conversion,
   * implementing parts of it and its superclasse's functionality that's been
   * deprecated since jdk1.1 and while still supported by modern java, not found
   * in SwingJS.
   * 
   * The main mechanism supported by this class Pain is legacy jdk 1.0 event
   * model involving methods action and handleEvent. This class provides
   * automatically adds listeners to children components added to it, and fires
   * up call to methods action and handleEvent. as appropriate to approximate
   * AWT 1.0 behavior. One could wonder why not to move this bridging
   * functionality to jsjava/awt/Container where it logically belongs but this
   * will enable the legacy behavior with the burden associated with it for
   * SwingJS components - because JComponent derives from java.awt.Container -
   * probably not a good idea.
   * 
   * author: dmitrynizh
   * */
  class Panel extends JPanel implements ActionListener, AdjustmentListener {

    public Panel(LayoutManager layout) {
      super(layout);
    }

    public Panel() {
      super();
    }

    public Component add(Component comp) {
      super.add(comp);
      return comp;
    }

    @Override
    protected void/*Component in jsjava/awt/!*/ addImpl(Component comp, Object constraints, int index) {
      super.addImpl(comp, constraints, index);
      //System.out.println(" -- adding comp: " + comp);
      // this is wrong time for buttons
      //comp.setPreferredSize(comp.getPreferredSize());
      if (comp instanceof Button)
        ((Button)comp).addActionListener(this);
      else if (comp instanceof Scrollbar)
        ((Scrollbar)comp).addAdjustmentListener(this);
      else if (comp instanceof TextField) {
        comp.setPreferredSize(new Dimension(120, 24));
        ((TextField)comp).addActionListener(this);
      } else if (comp instanceof Choice)
        ((Choice)comp).addActionListener(this);
      
      //return comp;
    }

//    public Component add(Button bt) {
//      super.add(bt);
//      bt.addActionListener(this);
//      return bt;
//    }
//
//    public Component add(Scrollbar comp) {
//      super.add(comp);
//      comp.addAdjustmentListener(this);
//      return comp;
//    }
//    public Component add(String pos, Scrollbar comp) {
//      super.add(pos, comp);
//      comp.addAdjustmentListener(this);
//      return comp;
//    }
//
//    public Component add(TextField comp) {
//      super.add(comp);
//      comp.setPreferredSize(new Dimension(400, 80));
//      comp.addActionListener(this);
//      return comp;
//    }
//
//    public Component add(Choice comp) {
//      super.add(comp);
//      // return A2SEvent.addComponent((EventListener)
//      // this.getTopLevelAncestor(), comp);
//      comp.addActionListener(this);
//      return comp;
//    }

    // public boolean action(Event evt, Object arg) { }

    @SuppressWarnings("deprecation")
    public void actionPerformed (ActionEvent e) {
      if (!inited)
        return;
      Object src = e.getSource();
      if (src instanceof TextField) {
        // System.out.println("TF " + src);
        boolean ok = this.action(new Event(src, Event.ACTION_EVENT, e), src);
        if (!ok)
          this.handleEvent(new Event(src, Event.ACTION_EVENT, e));
      } else if (src instanceof Button) {
        //System.out.println("butt " + src + " name: " + ((Button) src).getText());
        boolean ok = this.action(new Event(src, Event.ACTION_EVENT, e), ((Button) src).getText());
        // if (!ok) this.handleEvent(new Event(src, Event.ACTION_EVENT, e));
      } else if (src instanceof Choice) {
        //System.out.println("choice " + src + " idx: " + ((Choice) src).getSelectedIndex() + " sel: " + ((Choice) src).getSelectedItem());
        boolean ok = this.action(new Event(src, Event.ACTION_EVENT, e), src);
        if (!ok)
          this.handleEvent(new Event(src, Event.ACTION_EVENT, e));
      }
    }

    public void adjustmentValueChanged (AdjustmentEvent e) {
      //System.out.println("comp " + e.getSource() + " value: " + ((Scrollbar) e.getSource()).getValue());
      boolean ok = this.action(new Event(e.getSource(), Event.SCROLL_ABSOLUTE, e), e.getSource());
      if (!ok)
        this.handleEvent(new Event(e.getSource(), Event.SCROLL_ABSOLUTE, e));
    }

  } // Panel

  class Canvas extends JPanel {

    Canvas() {

      this.addMouseListener(new MouseListener() {
        @SuppressWarnings("deprecation")
        @Override
        public void mouseReleased(MouseEvent e) {
          // System.out.println(":MOUSE_RELEASED_EVENT:");
          mouseUp(new Event(e.getSource(), Event.MOUSE_UP, e), e.getX(),
              e.getY());
        }
        @SuppressWarnings("deprecation")
        @Override
        public void mousePressed(MouseEvent e) {
          // System.out.println("----------------------------------\n:MOUSE_PRESSED_EVENT:");
          mouseDown(new Event(e.getSource(), Event.MOUSE_DOWN, e), e.getX(),
              e.getY());
        }
        @Override
        public void mouseExited(MouseEvent e) {
          // System.out.println(":MOUSE_EXITED_EVENT:");
        }
        @Override
        public void mouseEntered(MouseEvent e) {
          // System.out.println(":MOUSE_ENTER_EVENT:");
        }
        @Override
        public void mouseClicked(MouseEvent e) {
          // System.out.println(":MOUSE_CLICK_EVENT:");
        }
      });
      this.addMouseMotionListener(new MouseMotionListener() {
        @SuppressWarnings("deprecation")
        public void mouseDragged(MouseEvent e) {
          mouseDrag(new Event(e.getSource(), Event.MOUSE_DRAG, e), e.getX(),
              e.getY());
        }
        @SuppressWarnings("deprecation")
        public void mouseMoved(MouseEvent e) {
          mouseMove(new Event(e.getSource(), Event.MOUSE_MOVE, e), e.getX(),
              e.getY());
        }

      });
    }

    // d.n.: do not seem to need it for Foil...
    @Override 
    public void paint(Graphics g) { update(g); }


    private boolean notified;
    @Override
    public void update(Graphics g) {
      if (!notified)
        System.out.println("neither paint(g) nor update(g) is implemented for "
            + this);
      notified = true;
    }
  }
  
  public class Button extends JButton {

    public Button() {
      super();
      getPreferredSize(); // hack!!
    }

    public Button(String text) {
      super(text);
      getPreferredSize(); // hack!!
    }

  }

  // A note on units. The NASA FoilSim program historically is imperial by default.
  // In the 90s, windsurfing in USA has completed transition to metric system - 
  // if you find a board which length is in feet, or a fin in inches, it is an old piece. 
  // Kiting has been metric from day 1. Hence it makes sense to be metric by default here.
  
  static final int  IMPERIAL = 0, METRIC = 1;
  static double LEN_FT2M = 0.3048, LEN_M2FT = 3.28084;
  
  static Font largeFont = new Font("TimesRoman", Font.PLAIN, 24);
 
  static double convdr = 3.1415926/180. ;
  static double pid2 = 3.1415926/2.0 ;
  static double alpha_degr,thkval,camval;

  static double clift, clift_old;
  static int clift_set_count;

  static double dragCoeff,drag,liftOverDrag,reynolds,viscos ;
  static double thkd,camd,dragco ;
  static double thkinpt,caminpt ;                 /* MODS 10 Sep 99 */
  static double usq,vsq,alt,altmax,area,armax,armin ;
  static double chord,span,aspr,arold,chrdold,span_old ; /* Mod 13 Jan 00 */
  static double q0,ps0,ts0,rho,rlhum; // free stream vars

  final static double STEP_X = 0.4;
  static double xflow ;             /* MODS  20 Jul 99 */
  static double delx,delt,velocity,spin,spindr,yoff,radius ;
  static double vel,pres,lift,side,omega,radcrv,relsy,angr;

  // 
  static String t_foil_name;
  // note on *speed*: here and below, it is velocity of the craft in
  // forward direction.
  static String speed_kts_mph_kmh_ms_info = "";
  static String max_speed_info;
  double        max_speed_speed, max_speed_lift, max_speed_drag;
  static String min_takeoff_speed_info; 
  double        min_takeoff_speed, min_takeoff_lift, min_takeoff_drag;
  static String cruising_info;
  double        cruising_speed, cruising_lift, cruising_drag;
  static String constraint_lift_text_auw = "all-up weight (AUW)";
  static String constraint_lift_text_uplift = "required uplift force";

  // Foiling craft parts with default values
  Part //              name; airfoil     xpos             chord  span  thk camb aoa
  fuse    = new Part("Fuse", FOIL_NACA4, 0,               0.8,   0.02, 04, 0,   0),
    wing  = new Part("Wing", FOIL_NACA4, 0,               0.11,  0.56, 12, 3.34,0), 
    strut = new Part("Mast", FOIL_NACA4, fuse.chord/3,    0.111, 0.95, 12, 0,   0), 
    stab  = new Part("Stab", FOIL_NACA4, fuse.chord-0.05, 0.05,  0.3,  12, -3,  0)
    ;

  // when foil or camber or thickness change, recompute!
  static double[] cache_t_Cl, cache_t_Cd;

  // stall model coeffs cache
  // K = k0 + k1 *AoA + k2 *AoA*AoA +  k3 *AoA*AoA*AoA.
  static double stall_model_k0, stall_model_k1, stall_model_k2, stall_model_k3;
  Part current_part = null;
  double craft_pitch = 0;
  static Button part_button, bt_wing, bt_stab;

  // kinds of foils supported
  static final int 
    FOIL_JOUKOWSKI     = 0, 
    FOIL_NACA4         = 1+ FOIL_JOUKOWSKI,
    FOIL_NACA_64_814   = 1+ FOIL_NACA4,
    FOIL_AQUILA_9P3    = 1+ FOIL_NACA_64_814,
    FOIL_NACA_63_412   = 1+ FOIL_AQUILA_9P3,
    FOIL_BLADERIDER_V1 = 1+ FOIL_NACA_63_412,
    FOIL_ELLIPTICAL    = 1+ FOIL_BLADERIDER_V1,
    FOIL_FLAT_PLATE    = 1+ FOIL_ELLIPTICAL,
    FOIL_CYLINDER      = 1+ FOIL_FLAT_PLATE,
    FOIL_BALL          = 1+ FOIL_CYLINDER;

  static String foil_descr(int foil) {
    switch (foil) {
    case FOIL_JOUKOWSKI:
      return "Joukowski";
    case FOIL_NACA4:
      return "NACA 4 series";
    case FOIL_NACA_64_814:
      return "NACA 64-814";
    case FOIL_AQUILA_9P3:
      return "Aquila 9.3%";
    case FOIL_NACA_63_412:
      return "NACA 63-412";
    case FOIL_BLADERIDER_V1:
      return "NACA 63-412 w/flap";
    case FOIL_ELLIPTICAL: {        
      return "Ellipse";
    }
    case FOIL_FLAT_PLATE: {     
      return "Flat Plate";
    }
    case FOIL_CYLINDER: {     
      return "Rotating Cylinder";
    }
    case FOIL_BALL: {     
      return "Spinning Ball";
    }
    default:
      return "N/A";
    }
      
  }

  // final static int DRAG_COMP_POLY_FOILSIMORIG = 0,
  //       DRAG_COMP_AQUILA_9P3 = 1,
  //       DRAG_COMP_NACA4SERIES = 2;

  // wing
  static double wing_chord, wing_span, wing_area;

  static double rg[][]  = new double[20][40] ; 
  static double thg[][] = new double[20][40] ; 
  static double xg[][]  = new double[20][40] ; 
  static double yg[][]  = new double[20][40] ; 
  static double xm[][]  = new double[20][40] ; 
  static double ym[][]  = new double[20][40] ; 
  static double xpl[][]  = new double[20][40] ; 
  static double ypl[][]  = new double[20][40] ; 
  static double plp[]   = new double[40] ;
  static double plv[]   = new double[40] ;

  static double stall_model_apos = 10, stall_model_aneg = -10;
  
  static final int STALL_MODEL_IDEAL_FLOW = 0,
    STALL_MODEL_DFLT = 1, // default 0.5 + 0.1A + 0.005A^2 and +-10
    STALL_MODEL_REFINED = 2; // this is per foil type.
  
  static final int POINTS_COUNT = 27;
  static final int POINTS_COUNT_HALF = POINTS_COUNT/2 + 1;
  static final int STREAMLINES_COUNT = 15;
  static final int STREAMLINES_COUNT_HALF = STREAMLINES_COUNT/2 + 1;

  int stall_model_type;

  int foil,lunits,lftout,planet,dragOut ;

  //  foil display state
  int displ,viewflg,dispp,dout,doutb,antim,ancol,sldloc; 

  int calcrange,ar_lift_corr,indrag,recor,bdragflag ;
  /* units data */
  static double v_mn,al_mn,ang_mn,v_mx,al_mx,ang_mx ;
  static double ca_mn,thk_mn,ca_mx,thk_mx ;
  static double chrd_mn,span_mn,ar_mn,chrd_mx,span_mx,ar_mx ;
  static double rad_mn,spin_mn,rad_mx,spin_mx ;
  static double vconv,vmax ;
  
  // these conv coeffs can b arcane; if switsding a value to feet,
  // divide it by lconv, if switcing  
  static double pconv,pmax,pmin,lconv,rconv,fconv,fmax,fmaxb;

  /*  probe data */
  static double prg,pthg,pxg,pyg,pxm,pym,pxpl,pypl ;

  int xt1,yt1,xt2,yt2,spanfac ;
  static double fact,xpval,ypval,pbval,factp;
  int pboflag,xt,yt,ntikx,ntiky,npt,xtp,ytp ;


  Solver solver = new Solver() ;
  VPP vpp       = new VPP();

  MainControlsPanel con ;
  In in ;
  Out out ;
  CardLayout layin,layout,layplt ;
  Image offImg1 ;
  Graphics off1Gg ;
  Image offImg2 ;
  Graphics off2Gg ;
  Image offImg3 ;
  Graphics off3Gg ;
  

  String getParameter(String name, String default_val) {
    String val = getParameter(name);
    if (val == null) val = default_val;
    return val;
  }

  boolean foil_is_cylinder_or_ball(int foil) {
    return foil == FOIL_CYLINDER || foil == FOIL_BALL;
  }
  
  /**
   * 
   * @j2sNative
   * 
   *  console.log(args);
   *  this.traceArray(args);
   */
  void trace(Object... args) {
    traceArray(args);
  }
  
 
  void traceArray(Object[] args) {
    for (int i = 0; i < args.length; ++i) {
      System.out.print("|" + args[i] + "| ");
    }
    System.out.println("");
  }

  boolean parseParameters(Part p, String p_name) {
    String p_data   = getParameter(p_name);
    if (p_data == null)
      return false;
    return parseParamData(p, p_name, p_data);
  }
      
  boolean parseParamData_debug = false;
  boolean parseParamData(Part p, String p_name, String p_data) {
    if (parseParamData_debug) trace("parseParamData: ", p, p_name, p_data);
      String[] params = p_data.split("\\s+");
      int i = 0;
      p.foil = -1 + Integer.parseInt(params[i++]);

      String[] chord_spec = params[i++].split("[:;|/]"); // possible chord value separators 

      if (chord_spec.length == 1)
        p.chord = Double.parseDouble(chord_spec[0]);
      else { // compute MAC value. this is silly straightfoward
        // so that is obvious
        int segment_count = chord_spec.length -1;
        double MAC = 0;
        for (int ci = 0; ci < segment_count; ci++)
          // effectibe chord of thsi segment added
          MAC += (Double.parseDouble(chord_spec[ci]) + Double.parseDouble(chord_spec[ci+1])) / 2;
        MAC /= segment_count;
        System.out.println("-- MAC: " + MAC);
        p.chord = MAC;
      }
     
      p.span = Double.parseDouble(params[i++]);

      p.thickness_pst = Double.parseDouble(params[i++]);
      if (p.thickness_pst < 0.1) // user entered thickness in meters, convert to %
        p.thickness_pst = 100* p.thickness_pst / p.chord;

      p.camber = Double.parseDouble(params[i++]);
      if (Math.abs(p.camber) < 0.1) // user likely entererd camber in meters, convert to %
        p.camber = 100* p.camber / p.chord;

      p.aoa = Double.parseDouble(params[i++]);

      // X axis position is optional and is by default if not provided
      if (params.length > i)
        p.xpos = Double.parseDouble(params[i++]);

      return true;
   }
    

  public void init() {

    // any inputs?
    parseParameters(wing, "Wing");
    parseParameters(stab, "Stab");
    if (!parseParameters(strut, "Strut")) parseParameters(strut, "Mast");
    parseParameters(fuse, "Fuse");

    String make_name  = getParameter("Make", "");
    String model_name = getParameter("Model", "Test");
    String year_etc   = getParameter("Year/Variant", "");
    if (year_etc == null)  year_etc = getParameter("Year", "");
    t_foil_name = (make_name + " " + model_name + year_etc).trim();

    offImg1 = createImage(this.size().width,
                          this.size().height) ;
    off1Gg = offImg1.getGraphics() ;
    offImg2 = createImage(this.size().width,
                          this.size().height) ;
    off2Gg = offImg2.getGraphics() ;
    offImg3 = createImage(this.size().width,
                          this.size().height) ;
    off3Gg = offImg3.getGraphics() ;

    setLayout(new GridLayout(2,2,5,5)) ;

    con = new MainControlsPanel(this) ;
    
    // set imperial defaults but switch to metric later afterwards
    solver.setImperialDefaults() ;
    

    in = new In(this) ;
    out = new Out(this) ;

    add(out.viewer) ;
    add(con) ;
    add(in) ;
    add(out) ;
    
   
    solver.getFreeStream ();
    computeFlow () ;
    out.viewer.start() ;
    out.plt.start() ;

    // now, simulate switch to under-water, ocean water conditions
    // with metric units
    
    planet = 2; // water
    in.env.inr.plntch.select(planet);
    con.untch.select(METRIC);
    setUnits(METRIC);
//
//    
    //current_part = wing;
    velocity = 20.0 ; // speed is 20 km/h
    alt = 1; // depth: 1m
    loadInput() ;
//    // make flight tab active
//    con.ibt_flight.dispatchEvent(new ActionEvent((Object)con.ibt_flight, ActionEvent.ACTION_PERFORMED, ""));
//    // temporary switch to stab
//    bt_stab.dispatchEvent(new ActionEvent((Object)bt_wing, ActionEvent.ACTION_PERFORMED, ""));
//    // make wing part active
//    bt_wing.dispatchEvent(new ActionEvent((Object)bt_wing, ActionEvent.ACTION_PERFORMED, ""));

    current_part = null;
    con.recomp_all_parts();
    // loadInput() ;
    // loadOut();
    inited = true;
  }
 
  public Insets insets() {
    return new Insets(10,10,10,10) ;
  }

  double effective_aoa() {
    // strut is vertical and pitch does nto affect it and vice versa.
    // hence for strut, effective_aoa is its own aoa.
    if (current_part == strut)
      return alpha_degr;
    else
      return Math.min(ang_mx, Math.max(ang_mn, alpha_degr + craft_pitch));
  }

  // this avoids some overhead when doing massive computation
  boolean computeFlow_fast_recomp = false;

  public void computeFlow() { 
    solver.getFreeStream () ;
    double effaoa = effective_aoa();
    solver.getCirculation(effaoa, thkinpt, caminpt);
    if (computeFlow_fast_recomp == false)
      solver.compute_foil_geometry(effaoa);

    clift = solver.getClift(effaoa);
    
    if (computeFlow_fast_recomp == false)
      solver.genFlow(effaoa) ;

    // test: is this the same value getClplot gives?
    // if (false) {
    //   double getClplot_val = out.plt.getClplot(camval, thkval, effaoa) ;
    //   if (getClplot_val != clift) {
    //     System.out.println("-- getClplot_val: " + getClplot_val + "yet clift: " + clift);
    //   }
    //   track_clift_changes();
    // }

    reynolds = foil_is_cylinder_or_ball(foil) 
      ? velocity/vconv * 2 * radius/lconv * rho / viscos
      : velocity/vconv * chord/lconv * rho / viscos ;

    if (computeFlow_fast_recomp == false)
      solver.getProbe();

    thkd = thkinpt ;
    camd = caminpt ;

    double alfd = effective_aoa() ;
    //   attempt to fix symmetry problem
    if (camd < 0.0) alfd = - alfd ;

    solver.getDrag(clift, alfd, thkd, camd); 
    dragCoeff = dragco ;
 
    loadOut() ;

    if (computeFlow_fast_recomp == false)
      out.plt.loadPlot() ;
  }

  public int filter0(double inumbr) {
    //  output only to .
    int number ;
    int intermed ;
 
    number = (int) (inumbr);
    return number ;
  }

  public float filter1(double inumbr) {
    //  output only to .1
    float number ;
    int intermed ;
 
    intermed = (int) (inumbr * 10.) ;
    number = (float) (intermed / 10. );
    return number ;
  }
 
  public float filter3(double inumbr) {
    //  output only to .001
    float number ;
    int intermed ;
 
    intermed = (int) (inumbr * 1000.) ;
    number = (float) (intermed / 1000. );
    return number ;
  }
 
  public float filter5(double inumbr) {
    //  output only to .00001
    float number ;
    int intermed ;
 
    intermed = (int) (inumbr * 100000.) ;
    number = (float) (intermed / 100000. );
    return number ;
  }
 
  public float filter9(double inumbr) {
    //  output only to .000000001
    float number ;
    int intermed ;
 
    intermed = (int) (inumbr * 1000000000.) ;
    number = (float) (intermed / 1000000000. );
    return number ;
  }
 
  public void setUnits(int newUnits) {   // Switching Units to what lunits is
    if (lunits == newUnits) return;
    lunits = newUnits;  
    double ovs,chords,spans,aros,chos,spos,rads ;
    double alts,ares ;

    // fist save to imperial units.
    alts = alt / lconv ;
    chords = chord / lconv ;
    spans = span / lconv ;
    ares = area /lconv/lconv ;
    aros = arold /lconv/lconv ;
    chos = chrdold / lconv ;
    spos = span_old / lconv ;
    ovs = velocity / vconv ;
    rads = radius / lconv ;

    switch (lunits) {
    case IMPERIAL: {                             /* English */
      lconv = 1.;                      /*  feet    */
      vconv = .6818; vmax = 250.;   /*  mph  */
      if (planet == 2) vmax = 50. ;
      fconv = 1.0; fmax = 100000.; fmaxb = .5;  /* pounds   */
      pconv = 14.7  ;                   /* lb/sq in */
      break;
    }
    case METRIC: {                             /* Metric */
      lconv = LEN_FT2M;                    /* meters to feet */
      vconv = 1.097; vmax = 400. ;   /* km/hr  */
      if (planet == 2) vmax = 80. ;
      fconv = 4.448 ; fmax = 500000.; fmaxb = 2.5; /* newtons */
      pconv = 101.3 ;               /* kilo-pascals */
      break ;
    }
    }
 
    alt = alts * lconv ;
    chord = chords * lconv ;
    span = spans * lconv ;
    area = ares * lconv * lconv ;
    arold = aros * lconv * lconv ;
    chrdold = chos * lconv ;
    span_old = spos * lconv ;
    velocity  = ovs * vconv;
    radius  = rads * lconv;

    return ;
  }

  // convert spped in kts to current units
  double kts_to_speed(double kts) {
    return (lunits == METRIC) 
      ? kts / 0.539957
      : kts / 0.868976;
  }

  String make_speed_kts_mph_kmh_ms_info(double speed) {
    return (lunits == IMPERIAL)
      ? (filter1(speed * 0.868976) + " kts or " + filter1(speed) + " mph or " + 
         filter1(speed * 1.60934) + " km/h or " + filter1(speed * 0.44704) + " m/s")
      : (filter1(speed * 0.539957) + " kts or " + filter1(speed * 0.621371) + " mph or " + 
         filter1(speed)  + " km/h or " + filter1(speed * 0.277778) + " m/s");
  }
      
  String make_force_newtons_lbs_kg_info(double force, int sz) {
    return (lunits == IMPERIAL)
      ? (filter1(force * 4.44822) + " Newtons or " + filter1(force) + " Lbs or " + 
         filter1(force * 0.453592) + " kg")
      : (filter1(force) + " Newtons or " + 
         filter1(force * 0.224808942443)  + " Lbs or " + filter1(force * 0.101971621) + " kg");
  }

  static String padRight(String s, int n) {
     return String.format("%1$-" + n + "s", s);  
  }

  static String padLeft(String s, int n) {
    return String.format("%1$" + n + "s", s);  
  }

  String make_min_takeoff_speed_info(double min_lift, double max_drag, double speed) {
    min_takeoff_speed = speed;
    in.flt.tf_cruise_starting_speed.setText(""+filter0(min_takeoff_speed));
    min_takeoff_lift  = min_lift;
    min_takeoff_drag  = max_drag;
    return min_takeoff_speed_info = 
      "This foil has been evaluated for minimum possible \n" + 
      "takeoff speed.\n" +
      "It was found that with " + constraint_lift_text_uplift + " of \n" + 
      make_force_newtons_lbs_kg_info(filter1(min_lift),10) + " \n" + 
      "and total hydrodynamic drag not exceeding \n" + 
      make_force_newtons_lbs_kg_info(filter1(max_drag),10) + " \n" + 
      "it can take off at speed of foiling as low as \n" + 
      //filter1(velocity) + " km/h"
      make_speed_kts_mph_kmh_ms_info(speed)
      ;
  }

  String make_cruising_info(double min_lift, double min_drag, double speed) {
    cruising_speed = speed;
    cruising_lift  = min_lift;
    cruising_drag  = min_drag;
    return cruising_info = 
      "This foil has been evaluated for minimum possible \n" + 
      "drag during cruising at speeds >= takeoff speed.\n" +
      "It was found that with " + constraint_lift_text_uplift + " of \n" + 
      make_force_newtons_lbs_kg_info(filter1(min_lift),10) + " \n" + 
      "total hydrodynamic drag would be minimal and not exceeding \n" + 
      make_force_newtons_lbs_kg_info(filter1(min_drag),10) + " \n" + 
      "when cruise-foiling at approximately \n" + 
      //filter1(velocity) + " km/h"
      make_speed_kts_mph_kmh_ms_info(speed)
      ;
  }

  String make_max_speed_info(double min_lift, double max_drag, double speed) {
    max_speed_speed = speed;
    max_speed_lift  = min_lift;
    max_speed_drag  = max_drag;
    return max_speed_info = 
      "This foil has been evaluated for maximum possible \n" 
      + "sustained, controllable flight speed.\n" +
      "It was found that with " + constraint_lift_text_uplift + " of \n" + 
      make_force_newtons_lbs_kg_info(filter1(min_lift),10) + " \n" + 
      "and total hydrodynamic drag not exceeding \n" + 
      make_force_newtons_lbs_kg_info(filter1(max_drag),10) + " \n" + 
      "it can maintain sustained flight speed of at least \n" + 
      //filter1(velocity) + " km/h"
      make_speed_kts_mph_kmh_ms_info(speed)
      ;
  }

  String toStringOptQMFilter1(double val) {
    return (val <= 0) ? "??" : ""+filter1(val);
  }
  String toStringOptQMFilter0(double val) {
    return (val <= 0) ? "??" : ""+filter0(val);
  }

  // note: this also does computeFlow(), 
  // hence no need to do {loadInput();computeFlow();}
  public void loadInput() {   // load the input panels
    int i1,i2,i3,i4,i5,i6 ;
    double v1,v2,v3,v4,v5,v6 ;
    float fl1,fl2,fl3,fl4,fl5,fl6 ;
    //  dimensional
    if (lunits == IMPERIAL) {
      in.siz.inl.l1.setText("Chord-ft") ;
      in.siz.inl.l2.setText("Span-ft") ;
      in.siz.inl.l3.setText("Area-sq ft") ;
      in.flt.l1.setText("Speed-mph") ;
      in.cyl.inl.l2.setText("Radius ft") ;
      in.cyl.inl.l3.setText("Span ft") ;
      in.flt.l2.setText(planet == 2 ? "Load-lb" : "Altitude-ft");
      // in.flt.lbl_min_lift.setText("Total Lift lb >=");
      // in.flt.lbl_max_drag.setText("Total Drag lb <=");
    } else /*METRIC*/ {
      in.siz.inl.l1.setText("Chord-m") ;
      in.siz.inl.l2.setText("Span-m") ;
      in.siz.inl.l3.setText("Area-sq m") ;
      in.flt.l1.setText("Speed-km/h") ;
      in.cyl.inl.l2.setText("Radius m") ;
      in.cyl.inl.l3.setText("Span m") ;
      in.flt.l2.setText(planet == 2 ? "Load-N": "Altitude-m");
      // in.flt.lbl_min_lift.setText("Total Lift N >=");
      // in.flt.lbl_max_drag.setText("Total Drag N <=");
    }
    speed_kts_mph_kmh_ms_info = make_speed_kts_mph_kmh_ms_info(velocity);
    
    in.shp.inr.shapch.select(foil);
    in.cyl.inr.shapch.select(foil);

    v1 = chord ;
    chrd_mn = 0.01*lconv;   chrd_mx = 20.1*lconv ;
    v2 = span ;
    span_mn = 0.01*lconv;   span_mx = 125.1*lconv ;
    if (planet == 2) {
      chrd_mx = 5.1*lconv ;
      span_mx = 10.1*lconv ;
    }
    v3 = area ;
    ar_mn = armin*lconv*lconv; ar_mx = armax*lconv*lconv ;
    v4 = velocity ;
    v_mn = 0.0;   v_mx= vmax ;
    v5 = alt ;
    al_mn = 0.0;  al_mx = altmax*lconv ;
    v6 = radius ;
    rad_mn = .05*lconv;  rad_mx = 5.0*lconv ;
    aspr = span/chord ;
    spanfac = (int)(2.0*fact*aspr*.3535) ;

    fl1 = (float) v1 ;
    fl2 = (float) v2 ;
    fl3 = (float) v3 ;
    fl4 = filter3(v4) ;
    fl5 = (float) v5 ;
    fl6 = (float) v6 ;
   
    in.siz.inl.f1.setText(String.valueOf(fl1)) ;
    in.siz.inl.f2.setText(String.valueOf(fl2)) ;
    in.siz.inl.f3.setText(String.valueOf(fl3)) ;
    in.flt.f1.setText(String.valueOf(fl4)) ;
    in.flt.fAoA.setText(String.valueOf(filter3(craft_pitch))) ;

    // in.flt.f2.setText(String.valueOf(fl5)) ;

    // in.flt.o1.setText(""+Double.valueOf(in.flt.o1.getText()) /lconv);
    // in.flt.o3.setText(""+Double.valueOf(in.flt.o3.getText()) / lconv);

    in.cyl.inl.f2.setText(String.valueOf(fl6)) ;
    in.cyl.inl.f3.setText(String.valueOf(fl2)) ;
   
    i1 = (int) (((v1 - chrd_mn)/(chrd_mx-chrd_mn))*1000.) ;
    i2 = (int) (((v2 - span_mn)/(span_mx-span_mn))*1000.) ;
    i3 = (int) (((v3 - ar_mn)/(ar_mx-ar_mn))*1000.) ;
    i4 = (int) (((v4 - v_mn)/(v_mx-v_mn))*1000.) ;
    i5 = (int) (((v5 - al_mn)/(al_mx-al_mn))*1000.) ;
    i6 = (int) (((v6 - rad_mn)/(rad_mx-rad_mn))*1000.) ;


    in.siz.inr.sld1.s1.setValue(i1) ;
    in.siz.inr.sld2.s2.setValue(i2) ;
    in.siz.inr.sld3.s3.setValue(i3) ;
    in.flt.s1.setValue(i4) ;
    in.flt.sAoA.setValue((int) (((craft_pitch - ang_mn)/(ang_mx-ang_mn))*1000.)) ;
    in.flt.s2.setValue(i5) ;
    in.cyl.inr.s2.setValue(i6) ;
    in.cyl.inr.s3.setValue(i2) ;
    //  non-dimensional
    v1 = caminpt ;
    v2 = thkinpt ;
    v3 = alpha_degr ;
    v4 = spin*60.0 ;

    fl1 = (float) v1 ;
    fl2 = (float) v2 ;
    fl3 = (float) v3 ;
    fl4 = (float) v4 ;

    in.shp.inl.f1.setText(String.valueOf(fl1)) ;
    in.shp.inl.f2.setText(String.valueOf(fl2)) ;
    in.shp.inl.f3.setText(String.valueOf(fl3)) ;
    in.cyl.inl.f1.setText(String.valueOf(fl4)) ;

    i1 = (int) (((v1 - ca_mn)/(ca_mx-ca_mn))*1000.) ;
    i2 = (int) (((v2 - thk_mn)/(thk_mx-thk_mn))*1000.) ;
    i3 = (int) (((v3 - ang_mn)/(ang_mx-ang_mn))*1000.) ;
    i4 = (int) (((v4 - spin_mn)/(spin_mx-spin_mn))*1000.) ;
     
    in.shp.inr.s1.setValue(i1) ;
    in.shp.inr.s2.setValue(i2) ;
    in.shp.inr.s3.setValue(i3) ;
    in.cyl.inr.s1.setValue(i4) ;

    computeFlow() ;
    return ;
  }

  void updateTotals () {
    String outunit = (lunits == METRIC) ? " N" :" lbs" ;
    double lift = total_lift();
    double drag = total_drag();
    con.outTotalLift.setText(String.valueOf(filter1(lift)) + outunit);
    con.outTotalDrag.setText(String.valueOf(filter1(drag)) + outunit);
    // tipping is typically eff_strut.span*2*total_drag
    double lift_loc = total_lift_loc(lift, drag* 2 * 0.5 * strut.span);
    if (lift_loc < wing.xpos-0.01) {
      // con.lbl_lift_loc.setText("CG to Mast");
      con.outTotalLiftLocation.setText(String.valueOf(filter0(100*Math.abs(lift_loc-wing.xpos))) + " cm fore");
    } else {
      if (lift_loc <= wing.xpos+wing.chord+0.01) {
        // con.lbl_lift_loc.setText("CG above Mast");
        con.outTotalLiftLocation.setText("Above Wing!");
        // con.outTotalLiftLocation.setText("" + filter0(100*lift_loc/fuse.chord) + " % aft");
      } else {
        // con.lbl_lift_loc.setText("CG to Mast");
        con.outTotalLiftLocation.setText(String.valueOf(filter0(100*Math.abs(lift_loc-wing.xpos-wing.chord))) + " cm aft");
      }
    }
  }

  static void track_clift_changes() {
    clift_set_count++;
    if (clift != clift_old) {
      System.out.println("-- clift: " + clift + " set: " + clift_set_count);
      clift_old = clift;
    }
  }

  public void loadOut() {   // output routine
    String outunit = (lunits == METRIC) ? " N" :" lbs" ;

    if (!foil_is_cylinder_or_ball(foil)) {     // mapped airfoil
 
      if (lftout == 1) {
        con.outlft_setText(String.valueOf(filter3(clift))) ;
      }
      else if (lftout == 0) {
        lift = clift * q0 * area / lconv / lconv ; /* lift in lbs */
        lift = lift * fconv ;
        if (Math.abs(lift) <= 10.0) {
          con.outlft_setText(String.valueOf(filter3(lift)) + outunit) ;
        }
        if (Math.abs(lift) > 10.0) {
          con.outlft_setText(String.valueOf(filter0(lift)) + outunit) ;
        }
      }
    }
    else {     // cylinder and ball

      lift = rho * velocity/vconv * solver.gamval * velocity/vconv * span/lconv; // lift lbs
      //    ball
      //        if (foil == FOIL_BALL) lift = lift * 3.1415926 / 2.0 ; 
      if (foil == FOIL_BALL) lift = lift * 4.0 * solver.rval / (span/lconv) / 3.0 ; 
      lift = lift * fconv ;
      clift = (lift/fconv) / ( q0 *  area/lconv/lconv) ;
      if (Math.abs(lift) <= 10.0) {
        con.outlft_setText(String.valueOf(filter3(lift)) + outunit) ;
      }
      if (Math.abs(lift) > 10.0) {
        con.outlft_setText(String.valueOf(filter0(lift)) + outunit) ;
      }
      if (lftout == 1) {
        clift = (lift/fconv) / ( q0 *  area/lconv/lconv) ;
        con.outlft_setText(String.valueOf(filter3(clift))) ;
      }
    }

    if (dragOut == 1) 
      {
        con.outDrag_setText(String.valueOf(filter3(dragCoeff))) ;
      }
    if (dragOut == 0) {
      drag = dragCoeff * q0 * area / lconv / lconv ;
      drag = drag * fconv ;
      if (Math.abs(drag) <= 10.0) {
        con.outDrag_setText(String.valueOf(filter3(drag)) + outunit) ;
      }
      if (Math.abs(drag) > 10.0) {
        con.outDrag_setText(String.valueOf(filter0(drag)) + outunit) ;
      }
    }

    liftOverDrag = clift/dragCoeff;
    con.outLD_setText(String.valueOf(filter3(liftOverDrag)));
 
    switch (lunits)  {
    case 0: {                             /* English */
      in.env.inl.o1.setText(String.valueOf(filter3(ps0/144.))) ;
      in.env.inl.lo1.setText("Press lb/in2") ;
      in.env.inl.o5.setText(String.valueOf(filter3(q0))) ;
      in.env.inl.lo5.setText("Dyn Press lb/ft2") ;
      in.env.inr.inr2.o2.setText(String.valueOf(filter0(ts0 - 460.))) ;
      in.env.inr.inr2.lo2.setText("Temp. F") ;
      in.env.inl.lo3.setText("Dens slug/ft3") ;
      in.env.inl.o3.setText(String.valueOf(filter5(rho))) ;
      in.env.inr.inr3.lo4.setText("Visc slug/ft-s") ;
      in.env.inr.inr3.o4.setText(String.valueOf(filter9(viscos))) ;
      in.siz.inl.o4.setText(String.valueOf(filter3(aspr))) ;
      break;
    }
    case 1: {                             /* Metric */
      in.env.inl.o1.setText(String.valueOf(filter3(101.3/14.7*ps0/144.))) ;
      in.env.inl.lo1.setText("Press kPa") ;
      in.env.inl.o5.setText(String.valueOf(filter3(101.3/14.7*q0/144.))) ;
      in.env.inl.lo5.setText("Dyn Press kPa") ;
      in.env.inr.inr2.o2.setText(String.valueOf(filter0(ts0*5.0/9.0 - 273.1))) ;
      in.env.inr.inr2.lo2.setText("Temp. C") ;
      in.env.inl.o3.setText(String.valueOf(filter3(rho*515.4))) ;
      in.env.inl.lo3.setText("Dens kg/m3") ;
      in.env.inr.inr3.o4.setText(String.valueOf(filter9(viscos*47.87))) ;
      in.env.inr.inr3.lo4.setText("Visc kg/m-s") ;
      in.siz.inl.o4.setText(String.valueOf(filter3(aspr))) ;
      break ;
    }
    }

    if (planet == 1 || planet == 2) {
      in.env.inr.inr6.o6.setText(String.valueOf(filter3(rlhum))) ;
    }
    if (planet == 4 || planet == 6) {
      in.env.inr.inr6.o6.setText(String.valueOf(filter3(rlhum))) ;
    }

    con.outReynolds_setText(String.valueOf(filter0(reynolds))) ;

//    if (current_part != null)
//      current_part.save_state();
    
    updateTotals();

    //track_clift_changes();

    return ;
  }

  public void loadProbe() {   // probe output routine

    pbval = 0.0 ;
    if (pboflag == 1) pbval = vel * velocity ;           // velocity
    if (pboflag == 2) pbval = ((ps0 + pres * q0)/2116.) * pconv ; // pressure
 
    out.prb.r.l2.repaint() ;
    return ;
  }

  double total_drag() {
    return wing.drag + stab.drag + fuse.drag + strut.drag;
  }

  // total *vertical* lift (excluded 'lift' of the strut/mast
  double total_lift() {
    return wing.lift + stab.lift + fuse.lift;
  }

  double total_lift_loc(double load, double tippng_mom) {
    // Mcg + Mwing + Mstab + Mfuse = 0
    double ref_pt_fore_fuse = 100.0;
    
    return (tippng_mom +
            wing.lift * (ref_pt_fore_fuse + 0.3 * wing.chord) +
            stab.lift * (ref_pt_fore_fuse + fuse.chord - 0.7 * stab.chord) +
            fuse.lift * (ref_pt_fore_fuse + 0.3 * fuse.chord))
      / load - ref_pt_fore_fuse;
  }

  // just for a test
  double total_lift_loc_aft(double load, double tippng_mom) {
    // Mload + Mwing + Mstab + Mfuse + tippng_mom =  0
    double ref_pt_aft_fuse = 10.0;
    
    return (-tippng_mom +
            wing.lift * (ref_pt_aft_fuse + fuse.chord - 0.3 * wing.chord) +
            stab.lift * (ref_pt_aft_fuse + 0.7 * stab.chord) +
            fuse.lift * (ref_pt_aft_fuse + 0.7 * fuse.chord))
      / load - (ref_pt_aft_fuse + fuse.chord);
  }

  class Solver {
    double ycval, xcval, gamval, rval;

    double lyg,lrg,lthg,lxgt,lygt,lrgt,lthgt;/* MOD 20 Jul */
    double lxm,lym,lxmt,lymt,vxdir;/* MOD 20 Jul */

    Solver() {}

    // aoa_degr: angel fo attack in degrees
    // thickness_pst: typically thkinpt
    // camber_pst   : typically camval
    Solver(double aoa_degr, double thickness_pst, double camber_pst) { 
      this.getFreeStream(); // thsi grabs globals such as velocity, height, planet
      this.getCirculation(aoa_degr, thickness_pst, camber_pst);
      // solver.compute_foil_geometry(aoa_degr);
    }

    public String toString() {
      return "{Solver xcval: " + xcval + " ycval: " + ycval + " gamval: " + gamval + " rval: " + rval + "}";
    }

    public void setImperialDefaults() {

      // for historical reasons, defaults are imperial 
      ar_lift_corr = 1 ;
      indrag = 1 ;
      recor = 1 ;
      bdragflag = 1;  // smooth ball
      planet = 2 ;
      lunits = IMPERIAL ;
      lftout = 0 ;
      foil = FOIL_JOUKOWSKI ;
      thkval = .5 ;
      thkinpt = 12.5 ;                   /* MODS 10 SEP 99 */
      camval = 0.0 ;
      caminpt = 0.0 ;
      alpha_degr = 5.0 ;
      gamval = 0.0 ;
      radius = 1.0 ;
      spin = 0.0 ;
      spindr = 1.0 ;
      rval = 1.0 ;
      ycval = 0.0 ;
      xcval = 0.0 ;
      displ   = 1 ;                            
      viewflg = 0 ;
      dispp = 9 ;
      calcrange = 0 ;
      dout = 0 ;
      doutb = 0 ;

      dragCoeff = 0;
 
      xpval = 2.1;
      ypval = -.5 ;
      pboflag = 0 ;
      xflow = -10.0;                             /* MODS  20 Jul 99 */

      pconv = 14.7;
      pmin = .5 ;
      pmax = 1.0 ;
      fconv = 1.0 ;
      fmax = 100000. ;
      fmaxb = .50 ;
      vconv = .6818 ;
      velocity = 100. ;
      vmax = 250. ;
      lconv = 1.0 ;

      alt = 0.0 ;
      altmax = 50000. ;
      chrdold = chord = 5.0 ;
      span_old = span = 20.0 ;
      aspr = 4.0 ;
      arold = area = 100.0 ;
      armax = 2500.01 ;
      armin = .01 ;                 /* MODS 9 SEP 99 */
 
      xt = 170;  yt = 105; fact = 30.0 ;
      sldloc = 50 ;
      xtp = 95; ytp = 165; factp = 30.0 ;
      spanfac = (int)(2.0*fact*aspr*.3535) ;
      xt1 = xt + spanfac ;
      yt1 = yt - spanfac ;
      xt2 = xt - spanfac;
      yt2 = yt + spanfac ;
 
      stall_model_type = STALL_MODEL_DFLT ;
      v_mn = 0.0;     v_mx = 250.0 ;
      al_mn = 0.0;    al_mx = 50000.0 ;
      ang_mn = -20.0; ang_mx = 20.0 ;
      ca_mn = -20.0;  ca_mx = 20.0 ;
      thk_mn = 1.0; thk_mx = 20.0 ;
      chrd_mn = 0.01 ;  chrd_mx = 20.1 ;
      span_mn = .01 ;  span_mx = 125.1 ;
      ar_mn = .01 ;  ar_mx = 2500.01 ;
      spin_mn = -1500.0;   spin_mx = 1500.0 ;
      rad_mn = .05;   rad_mx = 5.0 ;

      load_stall_model_cache(FOIL_JOUKOWSKI);

      return ;
    }

    void load_stall_model_cache(int foil) {
      switch (foil) {
      case FOIL_NACA4:
        // these k0,k1,k2 align with the ideal aoa line at +- 5 degrees
        // see foilsim-airfoil-stall-correction.xlsx
        // stall_model_k0 = 0.83;
        // stall_model_k1 = 0.06;
        // stall_model_k2 = -0.0052;         
        // stall_model_apos = 5;
        // stall_model_aneg = -5;

        // these k0,k1,k2 align with the ideal aoa line at +- 9 degrees
        // see foilsim-airfoil-stall-correction.xlsx
        stall_model_k0 = 0.8812;
        stall_model_k1 = 0.06;
        stall_model_k2 = -0.0052;         
        stall_model_apos = 9;
        stall_model_aneg = -9;

        // these k0,k1,k2 align with the ideal aoa line at +- 10 degrees
        // see foilsim-airfoil-stall-correction.xlsx
        // stall_model_k0 = 0.86;
        // stall_model_k1 = 0.058;
        // stall_model_k2 = -0.0044;         
        // stall_model_apos = 10;
        // stall_model_aneg = -10;
        break;
      default:
        stall_model_k0 = 0.5;
        stall_model_k1 = 0.1;
        stall_model_k2 = -0.005;
        stall_model_apos = 10;
        stall_model_aneg = -10;
      }
    }

    // free stream conditions
    // call only after planet, height or velocity changed
    void getFreeStream() {    
      /* MODS  19 Jan 00  whole routine*/
       double rgas = 1716. ;                /* ft2/sec2 R */
       double gama = 1.4 ;
       double height_m = alt/lconv ;
       double mu0 = .000000362 ;
       double g0 = 32.2 ;

       switch (planet) {
       case 0: // Earth  standard day
         if (height_m <= 36152.) {           // Troposphere
           ts0 = 518.6 - 3.56 * height_m/1000. ;
           ps0 = 2116. * Math.pow(ts0/518.6,5.256) ;
         } else if (height_m >= 36152. && height_m <= 82345.) {   // Stratosphere
           ts0 = 389.98 ;
           ps0 = 2116. * .2236 *
             Math.exp((36000.-height_m)/(53.35*389.98)) ;
         } else if (height_m >= 82345.) {
           ts0 = 389.98 + 1.645 * (height_m-82345)/1000. ;
           ps0 = 2116. *.02456 * Math.pow(ts0/389.98,-11.388) ;
         }
         
         { 
           double temf = ts0 - 459.6 ;
           if (temf <= 0.0) temf = 0.0 ; 
           rho = ps0/(rgas * ts0) ;
                   
           /* Eq 1:6A  Domasch  - effect of humidity 
          */
           double pvap = rlhum*(2.685+.00354*Math.pow(temf,2.245))/100.;
           rho = (ps0 - .379*pvap)/(rgas * ts0) ; 
           viscos = mu0 * 717.408/(ts0 + 198.72)*Math.pow(ts0/518.688,1.5) ;
         }
         break;

       case 1:   // Mars - curve fit of orbiter data
         rgas = 1149. ;                /* ft2/sec2 R */
         gama = 1.29 ;
         rlhum = 0.0 ;

         if (height_m <= 22960.) {
           ts0 = 434.02 - .548 * height_m/1000. ;
           ps0 = 14.62 * Math.pow(2.71828,-.00003 * height_m) ;
         }
         if (height_m > 22960.) {
           ts0 = 449.36 - 1.217 * height_m/1000. ;
           ps0 = 14.62 * Math.pow(2.71828,-.00003 * height_m) ;
         }
         rho = ps0/(rgas*ts0) ;
         viscos = mu0 * 717.408/(ts0 + 198.72)*Math.pow(ts0/518.688,1.5) ;
         break;

       case 2: // water --  constant density
         height_m = -alt/lconv ;
         rlhum = 100. ;

         ts0 = 520. ;
         rho = 1.9927 ;  // for oceanic water (it is 1027 kg/m3). FoilSim has it at 1/94 slug/ft3
         ps0 = (2116. - rho * g0 * height_m) ;
         mu0 = .0000272 ;
         viscos = mu0 * 717.408/(ts0 + 198.72)*Math.pow(ts0/518.688,1.5) ;
         break;
       case 3:  // specify air temp and pressure 
         rho = ps0/(rgas*ts0) ;
         // reiplot_trace_counto temf
         {
           double temf = ts0 - 459.6 ;
           double pvap = rlhum*(2.685+.00354*Math.pow(temf,2.245))/100.;
         rho = (ps0 - .379*pvap)/(rgas * ts0) ; 
         }

         viscos = mu0 * 717.408/(ts0 + 198.72)*Math.pow(ts0/518.688,1.5) ;
         break;

       case 4:  // specify fluid density and viscosity
         rlhum = 0.0 ;
         ps0 = 2116. ;
         break;

       case 5: // Venus - surface conditions
         rgas = 1149. ;                
         gama = 1.29 ;
         rlhum = 0.0 ;

         ts0 = 1331.6 ;
         ps0 = 194672. ;

         rho = ps0/(rgas*ts0) ;
         viscos = mu0 * 717.408/(ts0 + 198.72)*Math.pow(ts0/518.688,1.5) ;
       default:
       }

      q0  = .5 * rho * velocity * velocity / (vconv * vconv) ;
      // pt0 = ps0 + q0 ;

      return ;
    }

    // circulation from Kutta condition
    // thickness_pst: typically thkinpt
    // camber_pst   : typically camval
    void getCirculation(double effaoa, double thickness_pst, double camber_pst) {   
      double beta;
      double thickness = thickness_pst/100.0; 
      double camber = camber_pst/100.0; 
      xcval = 0.0 ;
      ycval = 2 * camber; // was: camval/2, which is caminpt/25.

      switch (foil) {
      case FOIL_CYLINDER:     /* get circulation for rotating cylnder */
      case FOIL_BALL:         /* get circulation for rotating ball */
        rval = radius/lconv ;
        gamval = 4.0 * 3.1415926 * 3.1415926 *spin * rval * rval
          / (velocity/vconv) ;
        gamval = gamval * spindr ;
        ycval = .0001 ;
        break ;
      default: 
        rval = thickness + Math.sqrt(thickness*thickness + ycval*ycval + 1.0);
        xcval = 1.0 - Math.sqrt(rval*rval - ycval*ycval) ;
        beta = Math.asin(ycval/rval)/convdr ;     /* Kutta condition */
        gamval = 2.0*rval*Math.sin((effaoa+beta)*convdr) ;
        break ;
      }
    }
    
    double getClift(double effaoa) {
      double result;
      switch (foil) {
      case FOIL_AQUILA_9P3: 
        // use fixed table  data and interpolate
        result = ci15(t_lift_AQUILA_9p3, effaoa);
        break;
      case FOIL_NACA_63_412: 
        // use fixed table  data and interpolate
        result = ci15(t_lift_NACA_63_412, effaoa);
        break;
      case FOIL_BLADERIDER_V1: 
        // use fixed table  data and interpolate
        result = ci15(t_lift_NACA_63_412_mod_flap_v1, effaoa);
        break;
      case FOIL_NACA_64_814:
        result = ci25(t_lift_NACA_64_814_teg05, effaoa);
        break;
      case FOIL_NACA4:
        // System.out.println("-- thkd: " + thkd);
        // System.out.println("-- camd: " + camd);
        
        // code without use of cache (slower):
        // result = cache_t_Clci15_from_javafoil_data(t_lift_NACA4, effaoa, thkinpt, caminpt);
        if (cache_t_Cl == null)
          cache_t_Cl = compute_t_Cl(t_lift_NACA4, thkinpt, caminpt);
        result = ci15(cache_t_Cl, effaoa);
        break;
      default:
        result = compClift_Kutta(effaoa);
      }

      if (ar_lift_corr == 1) {  // correction for low aspect ratio
        result = result /(1.0 + Math.abs(result)/(3.14159*aspr)) ;
      }
      return result;
    }

    double compClift_Kutta(double effaoa) {
      double stfact, leg,teg,lem,tem;

      double result;
      /*  compute lift coefficient */
      leg = xcval - Math.sqrt(rval*rval - ycval*ycval) ;
      teg = xcval + Math.sqrt(rval*rval - ycval*ycval) ;
      lem = leg + 1.0/leg ;
      tem = teg + 1.0/teg ;

      double chrd = tem - lem ;
      // stall model
      stfact = 1.0 ;
      switch (stall_model_type) {
      case STALL_MODEL_DFLT:
        if (effaoa > 10 ) {
          stfact = .5 + .1 * effaoa - .005 * effaoa * effaoa ;
        } else if (effaoa < -10 ) {
          stfact = .5 - .1 * effaoa - .005 * effaoa * effaoa ;
        }
        break;
      case STALL_MODEL_REFINED:
        // stfact = stall_model_k0 + stall_model_k1 * Math.abs(effaoa) + stall_model_k2 * effaoa * effaoa ;
        if (effaoa > stall_model_apos ) {
          stfact = stall_model_k0 + stall_model_k1 * +effaoa + stall_model_k2 * effaoa * effaoa ;
        } else if (effaoa < stall_model_aneg ) {
          stfact = stall_model_k0 + stall_model_k1 * -effaoa + stall_model_k2 * effaoa * effaoa ;
        }
        break;
      case STALL_MODEL_IDEAL_FLOW:
      default:
        // do nothing. stfact = 1
      }
      
      result = stfact *
        gamval*4.0*3.1415926/chrd;
        
      return result;
    }
    
    void compute_foil_geometry(double effaoa) {
      double thet, rdm, thtm ;
      int index;

      // geometry
      for (index =1; index <= POINTS_COUNT; ++index) {
        thet = (index -1)*360./(POINTS_COUNT-1) ;
        xg[0][index] = rval * Math.cos(convdr * thet) + xcval ;
        yg[0][index] = rval * Math.sin(convdr * thet) + ycval ;
        rg[0][index] = Math.sqrt(xg[0][index]*xg[0][index] +
                                 yg[0][index]*yg[0][index])  ;
        thg[0][index] = Math.atan2(yg[0][index],xg[0][index])/convdr;
        xm[0][index] = (rg[0][index] + 1.0/rg[0][index])*
          Math.cos(convdr*thg[0][index]) ;
        ym[0][index] = (rg[0][index] - 1.0/rg[0][index])*
          Math.sin(convdr*thg[0][index]) ;
        rdm = Math.sqrt(xm[0][index]*xm[0][index] +
                        ym[0][index]*ym[0][index])  ;
        thtm = Math.atan2(ym[0][index],xm[0][index])/convdr;
        xm[0][index] = rdm * Math.cos((thtm - effaoa)*convdr);
        ym[0][index] = rdm * Math.sin((thtm - effaoa)*convdr);
        getVel(rval,thet) ;
        plp[index] = ((ps0 + pres * q0)/2116.) * pconv ;
        plv[index] = vel * velocity ;
      }

      xt1 = xt + spanfac ;
      yt1 = yt - spanfac ;
      xt2 = xt - spanfac;
      yt2 = yt + spanfac ;

      return ;
    }


    public void genFlow(double effaoa) {   // generate flowfield
      double rnew,thet,psv,fxg;
      //System.out.println("------------- genFlow: ");
      int k,index;

      /* all lines of flow  except stagnation line*/
      for (k=1; k<=STREAMLINES_COUNT; ++k) {
        psv = -.5*(STREAMLINES_COUNT_HALF-1) + .5*(k-1) ;
        fxg = xflow ;
        //System.out.println("-- psv: " + psv + "-- fxg: " + fxg);
        for (index =1; index <=POINTS_COUNT; ++ index) {
          getPoints(fxg,psv) ;
          xg[k][index]  = lxgt ;
          yg[k][index]  = lygt ;
          rg[k][index]  = lrgt ;
          thg[k][index] = lthgt ;
          xm[k][index]  = lxmt ;
          ym[k][index]  = lymt ;

          if (stall_model_type != STALL_MODEL_IDEAL_FLOW) {           // stall model
            double apos = stall_model_type == STALL_MODEL_DFLT ? +10 : stall_model_apos;
            double aneg = stall_model_type == STALL_MODEL_DFLT ? -10 : stall_model_aneg;
            if (effaoa > apos && psv > 0.0) {
              if (xm[k][index] > 0.0) {
                ym[k][index] = ym[k][index -1] ;
              }
            }
            if (effaoa < aneg && psv < 0.0) {
              if (xm[k][index] > 0.0) {
                ym[k][index] = ym[k][index -1] ;
              }
            }
          }
          solver.getVel(lrg,lthg) ;
          fxg = fxg + vxdir*STEP_X ;
        }
      }
      /*  stagnation line */
      k = STREAMLINES_COUNT_HALF ;
      psv = 0.0 ;
      /*  incoming flow */
      for (index =1; index <= POINTS_COUNT_HALF; ++ index) {
        rnew = 10.0 - (10.0 - rval)*Math.sin(pid2*(index-1)/(POINTS_COUNT_HALF-1)) ;
        thet = Math.asin(.999*(psv - gamval*Math.log(rnew/rval))/
                         (rnew - rval*rval/rnew)) ;
        fxg =  - rnew * Math.cos(thet) ;
        getPoints(fxg,psv) ;
        xg[k][index]  = lxgt ;
        yg[k][index]  = lygt ;
        rg[k][index]  = lrgt ;
        thg[k][index] = lthgt ;
        xm[k][index]  = lxmt ;
        ym[k][index]  = lymt ;
      }
      /*  downstream flow */
      for (index = 1; index <= POINTS_COUNT_HALF; ++ index) {
        rnew = 10.0 + .01 - (10.0 - rval)*Math.cos(pid2*(index-1)/(POINTS_COUNT_HALF-1)) ;
        thet = Math.asin(.999*(psv - gamval*Math.log(rnew/rval))/
                         (rnew - rval*rval/rnew)) ;
        fxg =   rnew * Math.cos(thet) ;
        getPoints(fxg,psv) ;
        xg[k][POINTS_COUNT_HALF+index]  = lxgt ;
        yg[k][POINTS_COUNT_HALF+index]  = lygt ;
        rg[k][POINTS_COUNT_HALF+index]  = lrgt ;
        thg[k][POINTS_COUNT_HALF+index] = lthgt ;
        xm[k][POINTS_COUNT_HALF+index]  = lxmt ;
        ym[k][POINTS_COUNT_HALF+index]  = lymt ;
      }
      /*  stagnation point */
      xg[k][POINTS_COUNT_HALF]  = xcval ;
      yg[k][POINTS_COUNT_HALF]  = ycval ;
      rg[k][POINTS_COUNT_HALF]  = Math.sqrt(xcval*xcval+ycval*ycval) ;
      thg[k][POINTS_COUNT_HALF] = Math.atan2(ycval,xcval)/convdr ;
      xm[k][POINTS_COUNT_HALF]  = (xm[k][POINTS_COUNT_HALF+1] + xm[k][POINTS_COUNT_HALF-1])/2.0 ;
      ym[k][POINTS_COUNT_HALF]  = (ym[0][POINTS_COUNT/4+1] + ym[0][POINTS_COUNT/4*3+1])/2.0 ;

    }

    public void getPoints(double fxg, double psv) {   // flow in x-psi
      double radm,thetm ;                /* MODS  20 Jul 99  whole routine*/
      double fnew,y_new,y_old,rfac;
      double xold,xnew,thet ;
      double rmin,rmax ;
      int iter,isign;
      double effaoa = effective_aoa();

      /* get variables in the generating plane */
      /* iterate to find value of yg */
      y_new = 10.0 ;
      y_old = 10.0 ;
      if (psv < 0.0) y_new = -10.0 ;
      if (Math.abs(psv) < .001 && effaoa < 0.0) y_new = rval ;
      if (Math.abs(psv) < .001 && effaoa >= 0.0) y_new = -rval ;
      fnew = 0.1 ;
      iter = 1 ;
      while (Math.abs(fnew) >= .00001 && iter < 25) {
        ++iter ;
        rfac = fxg*fxg + y_new*y_new ;
        if (rfac < rval*rval) rfac = rval*rval + .01 ;
        fnew = psv - y_new*(1.0 - rval*rval/rfac)
          - gamval*Math.log(Math.sqrt(rfac)/rval) ;
        double deriv = - (1.0 - rval*rval/rfac)
          - 2.0 * y_new*y_new*rval*rval/(rfac*rfac)
          - gamval * y_new / rfac ;
        y_old = y_new ;
        y_new = y_old  - .5*fnew/deriv ;
      }
      lyg = y_old ;
      /* rotate for angle of attack */
      lrg = Math.sqrt(fxg*fxg + lyg*lyg) ;
      lthg = Math.atan2(lyg,fxg)/convdr ;
      lxgt = lrg * Math.cos(convdr*(lthg + effaoa)) ;
      lygt = lrg * Math.sin(convdr*(lthg + effaoa)) ;
      /* translate cylinder to generate airfoil */
      lxgt = lxgt + xcval ;
      lygt = lygt + ycval ;
      lrgt = Math.sqrt(lxgt*lxgt + lygt*lygt) ;
      lthgt = Math.atan2(lygt,lxgt)/convdr ;
      /*  Kutta-Joukowski mapping */
      lxm = (lrgt + 1.0/lrgt)*Math.cos(convdr*lthgt) ;
      lym = (lrgt - 1.0/lrgt)*Math.sin(convdr*lthgt) ;
      /* tranforms for view fixed with free stream */
      /* take out rotation for angle of attack mapped and cylinder */
      radm = Math.sqrt(lxm*lxm+lym*lym) ;
      thetm = Math.atan2(lym,lxm)/convdr ;
      lxmt = radm*Math.cos(convdr*(thetm-effaoa)) ;
      lymt = radm*Math.sin(convdr*(thetm-effaoa)) ;

      lxgt = lxgt - xcval ;
      lygt = lygt - ycval ;
      lrgt = Math.sqrt(lxgt*lxgt + lygt*lygt)  ;
      lthgt = Math.atan2(lygt,lxgt)/convdr;
      lxgt = lrgt * Math.cos((lthgt - effaoa)*convdr);
      lygt = lrgt * Math.sin((lthgt - effaoa)*convdr);

      return ;
    }
 
    public void getVel(double rad, double theta) {  //velocity and pressure 
      double ur,uth,jake1,jake2,jakesq ;
      double xloc,yloc,thrad,alfrad ;
      double effaoa = effective_aoa();

      thrad = convdr * theta ;
      alfrad = convdr * effaoa ;
      /* get x, y location in cylinder plane */
      xloc = rad * Math.cos(thrad) ;
      yloc = rad * Math.sin(thrad) ;
      /* velocity in cylinder plane */
      ur  = Math.cos(thrad-alfrad)*(1.0-(rval*rval)/(rad*rad)) ;
      uth = -Math.sin(thrad-alfrad)*(1.0+(rval*rval)/(rad*rad))
        - gamval/rad;
      usq = ur*ur + uth*uth ;
      vxdir = ur * Math.cos(thrad) - uth * Math.sin(thrad) ; // MODS  20 Jul 99 
      /* translate to generate airfoil  */
      xloc = xloc + xcval ;
      yloc = yloc + ycval ;
      /* compute new radius-theta  */
      rad = Math.sqrt(xloc*xloc + yloc*yloc) ;
      thrad  = Math.atan2(yloc,xloc) ;
      /* compute Joukowski Jacobian  */
      jake1 = 1.0 - Math.cos(2.0*thrad)/(rad*rad) ;
      jake2 = Math.sin(2.0*thrad)/(rad*rad) ;
      jakesq = jake1*jake1 + jake2*jake2 ;
      if (Math.abs(jakesq) <= .01) jakesq = .01 ;  /* protection */
      vsq = usq / jakesq ;
      /* vel is velocity ratio - pres is coefficient  (p-p0)/q0   */
      if (!foil_is_cylinder_or_ball(foil)) {
        vel = Math.sqrt(vsq) ;
        pres = 1.0 - vsq ;
      } else  {
        vel = Math.sqrt(usq) ;
        pres = 1.0 - usq ;
      }
      return ;
    }

    public void getProbe () { /* all of the information needed for the probe */
      double prxg;
      int index;
      double effaoa = effective_aoa();
      /* get variables in the generating plane */
      if (Math.abs(ypval) < .01) ypval = .05 ;
      getPoints(xpval,ypval) ;

      solver.getVel(lrg,lthg) ;
      loadProbe() ;

      pxg = lxgt ;
      pyg = lygt ;
      prg = lrgt ;
      pthg = lthgt ;
      pxm = lxmt ;
      pym = lymt ;
      /* smoke */
      if (pboflag == 3 ) {
        prxg = xpval ;
        for (index =1; index <=POINTS_COUNT; ++ index) {
          getPoints(prxg,ypval) ;
          xg[19][index] = lxgt ;
          yg[19][index] = lygt ;
          rg[19][index] = lrgt ;
          thg[19][index] = lthgt ;
          xm[19][index] = lxmt ;
          ym[19][index] = lymt ;
          if (stall_model_type != STALL_MODEL_IDEAL_FLOW) {           // stall model
            double apos = stall_model_type == STALL_MODEL_DFLT ? +10 : stall_model_apos;
            double aneg = stall_model_type == STALL_MODEL_DFLT ? -10 : stall_model_aneg;
            if (xpval > 0.0) {
              if (effaoa > apos  && ypval > 0.0) { 
                ym[19][index] = ym[19][1] ;
              } 
              if (effaoa < aneg && ypval < 0.0) {
                ym[19][index] = ym[19][1] ;
              }
            }
            if (xpval < 0.0) {
              if (effaoa > apos && ypval > 0.0) { 
                if (xm[19][index] > 0.0) {
                  ym[19][index] = ym[19][index-1] ;
                }
              } 
              if (effaoa < aneg && ypval < 0.0) {
                if (xm[19][index] > 0.0) {
                  ym[19][index] = ym[19][index-1] ;
                }
              }
            }
          }
          solver.getVel(lrg,lthg) ;
          prxg = prxg + vxdir*STEP_X ;
        }
      }
      return ;
    }

// from http://paulbourke.net/miscellaneous/interpolation/ 
    double LinearInterpolate(double y1,double y2, double mu) {
      double res = (y1*(1-mu)+y2*mu);
      System.out.println("-- y1: " + y1);
      System.out.println("-- y2: " + y2);
      System.out.println("-- res: " + res);
      return res;
    }

    // from http://paulbourke.net/miscellaneous/interpolation/ 
    // The
    // function requires 4 points in all labeled y0, y1, y2, and y3,
    // mu: 0 to 1 for 
    // interpolating between the segment y1 to y2. 
    double CubicInterpolate(double y0,double y1,
                            double y2,double y3,
                            double mu)
    {
      double a0,a1,a2,a3,mu2;

      mu2 = mu*mu;

      //a0 = y3 - y2 - y0 + y1;
      //a1 = y0 - y1 - a0;
      //a2 = y2 - y0;
      //a3 = y1;

      // Paul Breeuwsma proposes the following coefficients for a
      // smoother interpolated curve, which uses the slope between the
      // previous point and the next as the derivative at the current
      // point. This results in what are generally referred to as
      // Catmull-Rom splines.
      a0 = -0.5*y0 + 1.5*y1 - 1.5*y2 + 0.5*y3;
      a1 = y0 - 2.5*y1 + 2*y2 - 0.5*y3;
      a2 = -0.5*y0 + 0.5*y2;
      a3 = y1;

      return(a0*mu*mu2+a1*mu2+a2*mu+a3);
    }

    // Name = AQUILA 9.3% smoothed
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finis    // h = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      //     Cd       Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     //     [-]      [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.1    // 25   0.39381 -0.021  0.893   0.006   0.931   0.015   -0.317  0.278   0.082
    // -24.0    -0.1    // 63   0.29085 -0.020  0.887   0.007   0.931   0.014   -0.561  0.272   0.128
    // -20.0    -0.2    // 16   0.21866 -0.019  0.881   0.006   0.933   0.011   -0.989  0.259   0.162
    // -16.0    -0.2    // 83   0.16381 -0.019  0.862   0.006   0.937   0.010   -1.727  0.251   0.183
    // -12.0    -0.3    // 36   0.09896 -0.019  0.823   0.006   0.943   0.009   -3.398  0.241   0.194
    // -8.0     -0.2    // 88   0.06640 -0.019  0.728   0.005   0.960   0.007   -4.342  0.253   0.184
    // -4.0     -0.0    // 45   0.03735 -0.020  0.593   0.005   0.975   0.006   -1.216  0.310   -0.186
    // -0.0     0.40    // 0    0.00847 -0.060  0.462   0.012   0.982   0.989   47.277  0.300   0.400
    // 4.0      0.86    // 4    0.00661 -0.066  0.307   0.946   0.986   0.988   130.772 0.263   0.326
    // 8.0      1.29    // 4    0.01596 -0.071  0.152   0.998   0.955   0.998   81.085  0.263   0.305
    // 12.0     1.38    // 8    0.03889 -0.072  0.002   1.000   0.635   1.000   35.696  0.403   0.302
    // 16.0     1.00    // 4    0.14560 -0.027  0.001   1.000   0.003   1.000   6.895   0.311   0.277
    // 20.0     0.68    // 5    0.24856 -0.029  0.001   1.000   0.003   1.000   2.758   0.235   0.293
    // 24.0     0.44    // 3    0.33959 -0.036  0.001   1.000   0.005   1.000   1.304   0.221   0.331
    // 28.0     0.29    // 2    0.48325 -0.041  0.001   0.999   0.007   0.999   0.604   0.218   0.389
    //                  // 
    double[] t_lift_AQUILA_9p3 = {-0.1 ,-0.1 ,-0.2 ,-0.2 ,-0.3 ,-0.2 ,-0.0 ,0.40 ,0.86 ,1.29 ,1.38 ,1.00 ,0.68 ,0.44 ,0.29 };
    double[] t_drag_AQUILA_9p3 = {0.39381, 0.29085, 0.21866, 0.16381, 0.09896, 0.06640, 0.03735, 0.00847, 0.00661, 0.01596, 0.03889, 0.14560, 0.24856, 0.33959, 0.48325 };


    // Name = NACA 63-412 AIRFOIL
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.246  0.48435 -0.015  0.945   0.002   1.000   0.011   -0.508  0.246   0.188
    // -24.0    -0.341  0.38844 -0.016  0.930   0.002   1.000   0.008   -0.878  0.237   0.204
    // -20.0    -0.474  0.25074 -0.018  0.920   0.003   1.000   0.009   -1.889  0.231   0.212
    // -16.0    -0.614  0.14833 -0.021  0.900   0.004   1.000   0.010   -4.138  0.225   0.216
    // -12.0    -0.641  0.08843 -0.022  0.845   0.007   1.000   0.008   -7.245  0.274   0.215
    // -8.0     -0.425  0.05258 -0.025  0.751   0.008   1.000   0.009   -8.089  0.338   0.190
    // -4.0     -0.087  0.01062 -0.071  0.647   0.009   1.000   0.931   -8.197  0.316   -0.567
    // -0.0     0.386   0.00814 -0.079  0.547   0.517   1.000   0.954   47.401  0.266   0.455
    // 4.0      0.856   0.01400 -0.087  0.006   0.660   1.000   0.954   61.186  0.173   0.351
    // 8.0      0.981   0.05228 -0.033  0.004   0.705   0.005   0.955   18.765  0.029   0.284
    // 12.0     1.087   0.08887 -0.036  0.005   0.838   0.005   0.957   12.228  0.935   0.283
    // 16.0     0.989   0.15306 -0.038  0.004   0.888   0.006   0.951   6.461   0.232   0.289
    // 20.0     0.708   0.22957 -0.043  0.004   0.922   0.007   0.951   3.085   0.232   0.310
    // 24.0     0.480   0.34907 -0.048  0.003   0.930   0.009   0.956   1.375   0.226   0.350
    // 28.0     0.329   0.46304 -0.052  0.002   0.930   0.011   0.956   0.710   0.223   0.408

    double[] t_lift_NACA_63_412 = {-0.246, -0.341, -0.474, -0.614, -0.641, -0.425, -0.087, 0.386 , 0.856 , 0.981 , 1.087 , 0.989 , 0.708 , 0.480 , 0.329     };

    double[] t_drag_NACA_63_412 = {0.48435, 0.38844, 0.25074, 0.14833, 0.08843, 0.05258, 0.01062, 0.00814, 0.01400, 0.05228, 0.08887, 0.15306, 0.22957, 0.34907, 0.46304  };

    // attempt to model Bladerider foil. Bladerider foil is modified NACA_63_412 with flap down.
    // the following is produced with (1) NACA_63_412 data from airfoils site inserted in javafoil
    // (2) that foil is modded with trailing gap = 1, flaps: 3- 1, 25 1, 20 1.

    // Name = NACA 63-412 AIRFOIL modded
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.264  0.45319 -0.024  0.999   0.002   0.999   0.010   -0.582  0.231   0.160
    // -24.0    -0.364  0.37355 -0.026  0.999   0.002   0.999   0.008   -0.974  0.224   0.179
    // -20.0    -0.493  0.22506 -0.030  0.999   0.003   0.999   0.010   -2.191  0.219   0.190
    // -16.0    -0.599  0.14758 -0.033  0.862   0.005   0.999   0.010   -4.055  0.135   0.195
    // -12.0    -0.542  0.09361 -0.035  0.824   0.007   0.999   0.008   -5.788  0.270   0.185
    // -8.0     -0.255  0.06026 -0.040  0.799   0.008   0.999   0.009   -4.232  0.358   0.094
    // -4.0     0.148   0.01756 -0.110  0.751   0.416   0.999   0.956   8.449   0.340   0.991
    // -0.0     0.625   0.01845 -0.119  0.568   0.520   0.999   0.958   33.893  0.269   0.440
    // 4.0      1.086   0.02570 -0.128  0.006   0.650   0.999   0.958   42.265  0.108   0.368
    // 8.0      1.124   0.06436 -0.048  0.004   0.677   0.005   0.959   17.464  -0.733  0.293
    // 12.0     1.165   0.10404 -0.051  0.005   0.699   0.005   0.960   11.194  0.216   0.294
    // 16.0     0.974   0.17417 -0.053  0.004   0.951   0.005   0.952   5.593   0.238   0.305
    // 20.0     0.676   0.24795 -0.057  0.004   0.951   0.006   0.952   2.728   0.228   0.334
    // 24.0     0.456   0.37413 -0.065  0.002   0.960   0.010   0.961   1.219   0.220   0.392
    // 28.0     0.314   0.51586 -0.068  0.002   0.960   0.011   0.961   0.608   0.229   0.466
    // 

    double[] t_lift_NACA_63_412_mod_flap_v1 = {-0.264, -0.364, -0.493, -0.599, -0.542, -0.255, 0.148 , 0.625 , 1.086 , 1.124 , 1.165 , 0.974 , 0.676 , 0.456 , 0.314   };
    double[] t_drag_NACA_63_412_mod_flap_v1 = {0.45319, 0.37355, 0.22506, 0.14758, 0.09361, 0.06026, 0.01756, 0.01845, 0.02570, 0.06436, 0.10404, 0.17417, 0.24795, 0.37413, 0.51586  };


    // NACA(camber)4(thickness) airfoil drag tables computed by
    // javafoil for NAcA 4 digit geometry and -28 to +28 step 4 AoA
    // and for Re=300000 and infine aspect ratio, Used for
    // interpolation instead of original FoilSim III polynomials.  The
    // reynolds correction and induced drag low aspect corrections of
    // FoilSim woudl hen apply (see the end of getDrag() method).
    // Tables produced by dmitrynizh 2016.

    // To convert Javafoil data to an array of 15 Cd values, set Polar tab to generate
    // 15 AoA values, chose single Re and press Copy(Text), and
    // then use this emacs keyboard macro (eval and then M-x execute-kbd-macro)
    /*
       (fset 'insert_javafoil_drag_15rows_test
       [?\C-y ?\C-  ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-x ?r ?t ?  ?  ?  ?  ?/ ?/ ?  return ?\C-r ?c ?d ?\C-n ?\C-n ?\C-  ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-\M-f ?\C-\M-f ?\C-x ?r ?\M-w ?\C-n ?\C-n ?  ?  ?  ?  ?d ?o ?u ?b ?l ?e ?  ?\C-b ?\[ ?\] ?\C-e ?t ?_ ?x ?y ?z ?_ ?\C-r ?n ?a ?m ?e ?\C-\M-f ?\C-f ?\C-f ?\C-f ?\C-  ?\C-\M-f ?\M-w ?\C-s ?x ?y ?z ?_ ?\C-b ?\C-f ?\C-y ?  ?= ?  ?\{ return return return return return return return return return return return return return return return ?\} ?\; ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-x ?r ?y ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-  ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-x ?r ?t ?, return ?\C-n ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\C-e return return])

       (fset 'insert_javafoil_lift_15rows_test
       [?\C-r ?c ?l ?\C-n ?\C-n ?\C-  ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-\M-f ?\C-\M-f ?\C-f ?\C-x ?r ?\M-w ?\C-n ?\C-n ?  ?  ?  ?  ?d ?o ?u ?b ?l ?e ?  ?\C-b ?\[ ?\] ?\C-e ?t ?_ ?x ?y ?z ?_ ?\C-r ?n ?a ?m ?e ?\C-\M-f ?\C-f ?\C-f ?\C-f ?\C-  ?\C-e ?\M-w ?\C-s ?x ?y ?z ?_ ?\C-b ?\C-f ?\C-y ?  ?= ?  ?\{ ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\C-m ?\} ?\; ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-x ?r ?y ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-p ?\C-e ?\C-  ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-n ?\C-x ?r ?t ?, ?\C-m ?\C-n ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\C-e ?\C-m ?\C-m])

       also see M-x edit-named-kbd-macro

    */

    // Name = NACA 0005
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.034  0.41708 0.007   1.000   0.004   1.000   0.016   -0.082  0.208   0.467
    // -24.0    -0.052  0.31201 0.007   1.000   0.003   1.000   0.016   -0.167  0.214   0.377
    // -20.0    -0.086  0.22381 0.006   1.000   0.003   1.000   0.013   -0.386  0.227   0.314
    // -16.0    -0.156  0.23465 0.004   1.000   0.002   1.000   0.009   -0.667  0.238   0.277
    // -12.0    -0.302  0.12617 0.003   1.000   0.002   1.000   0.006   -2.396  0.242   0.260
    // -8.0     -0.489  0.06937 0.002   1.000   0.001   1.000   0.003   -7.043  0.212   0.254
    // -4.0     -0.353  0.03531 0.001   0.990   0.005   1.000   0.008   -9.988  0.254   0.253
    // -0.0     -0.000  0.00661 -0.000  0.909   0.909   1.000   0.999   -0.000  0.253   0.250
    // 4.0      0.353   0.03531 -0.001  0.005   0.990   0.008   0.998   9.988   0.254   0.253
    // 8.0      0.489   0.06937 -0.002  0.001   0.998   0.003   0.998   7.043   0.212   0.254
    // 12.0     0.302   0.12617 -0.003  0.002   0.998   0.006   0.998   2.396   0.242   0.260
    // 16.0     0.156   0.23465 -0.004  0.002   0.998   0.009   0.999   0.667   0.238   0.277
    // 20.0     0.086   0.22381 -0.006  0.003   0.998   0.013   0.999   0.386   0.227   0.314
    // 24.0     0.052   0.31201 -0.007  0.003   0.998   0.016   0.999   0.167   0.214   0.377
    // 28.0     0.034   0.41708 -0.007  0.004   0.998   0.016   0.998   0.082   0.208   0.467

    double[] t_lift_NACA4_0005 = {-0.034, -0.052, -0.086, -0.156, -0.302, -0.489, -0.353, -0.000, 0.353 , 0.489 , 0.302 , 0.156 , 0.086 , 0.052 , 0.034     };


    double[] t_drag_NACA4_0005 = {0.41708, 0.31201, 0.22381, 0.23465, 0.12617, 0.06937, 0.03531, 0.00661, 0.03531, 0.06937, 0.12617, 0.23465, 0.22381, 0.31201, 0.41708};

    // Name = NACA 5405
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.025  0.37907 -0.047  0.970   0.005   0.984   0.018   -0.066  0.271   -1.640
    // -24.0    -0.036  0.28615 -0.047  0.966   0.004   0.985   0.017   -0.126  0.312   -1.054
    // -20.0    -0.055  0.20679 -0.045  0.962   0.004   0.985   0.013   -0.264  0.309   -0.578
    // -16.0    -0.087  0.21957 -0.044  0.951   0.003   0.988   0.010   -0.398  0.299   -0.251
    // -12.0    -0.138  0.12871 -0.041  0.930   0.003   0.994   0.007   -1.072  0.354   -0.048
    // -8.0     -0.141  0.06818 -0.038  0.886   0.002   1.000   0.004   -2.070  0.256   -0.021
    // -4.0     0.113   0.03873 -0.043  0.807   0.004   1.000   0.006   2.924   0.363   0.628
    // -0.0     0.602   0.00810 -0.122  0.660   0.998   1.000   0.998   74.366  0.340   0.452
    // 4.0      1.039   0.01528 -0.126  0.006   0.998   1.000   0.998   67.990  -0.015  0.371
    // 8.0      0.924   0.06111 -0.037  0.001   0.999   0.002   0.999   15.128  0.411   0.290
    // 12.0     0.531   0.11562 -0.045  0.001   0.998   0.004   0.998   4.597   0.229   0.334
    // 16.0     0.250   0.21581 -0.051  0.001   0.998   0.006   0.999   1.158   0.217   0.453
    // 20.0     0.127   0.22715 -0.058  0.001   0.999   0.010   0.999   0.560   0.180   0.704
    // 24.0     0.072   0.31187 -0.063  0.002   0.999   0.014   0.999   0.232   0.149   1.126
    // 28.0     0.045   0.42785 -0.066  0.003   0.998   0.015   0.998   0.105   0.148   1.718

    double[] t_lift_NACA4_0505 = {-0.025, -0.036, -0.055, -0.087, -0.138, -0.141, 0.113 , 0.602 , 1.039 , 0.924 , 0.531 , 0.250 , 0.127 , 0.072 , 0.045     };


    double[] t_drag_NACA4_0505 = { 0.37907, 0.28615, 0.20679, 0.21957, 0.12871, 0.06818, 0.03873, 0.00810, 0.01528, 0.06111, 0.11562, 0.21581, 0.22715, 0.31187, 0.42785};

    // Name = NACA 10405
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.018  0.36031 -0.096  0.933   0.005   0.968   0.019   -0.049  0.741   -5.123
    // -24.0    -0.024  0.26584 -0.093  0.918   0.005   0.972   0.016   -0.089  0.629   -3.672
    // -20.0    -0.032  0.37840 -0.091  0.900   0.004   0.976   0.014   -0.084  0.569   -2.609
    // -16.0    -0.039  0.21784 -0.088  0.872   0.004   0.979   0.011   -0.181  -1.092  -1.976
    // -12.0    -0.027  0.12650 -0.085  0.827   0.002   0.984   0.008   -0.215  0.190   -2.856
    // -8.0     0.111   0.06993 -0.079  0.765   0.002   0.989   0.005   1.593   0.236   0.958
    // -4.0     0.538   0.04199 -0.076  0.680   0.002   0.996   0.004   12.820  0.400   0.392
    // -0.0     1.188   0.01390 -0.241  0.442   0.012   1.000   1.000   85.498  0.407   0.453
    // 4.0      1.623   0.02178 -0.247  0.008   0.999   0.965   0.999   74.544  -0.534  0.402
    // 8.0      1.402   0.05662 -0.074  0.001   0.998   0.002   0.998   24.755  0.458   0.303
    // 12.0     0.812   0.10739 -0.078  0.000   0.998   0.002   0.998   7.561   0.232   0.346
    // 16.0     0.363   0.19528 -0.093  0.001   0.998   0.004   0.998   1.860   0.208   0.505
    // 20.0     0.175   0.34912 -0.104  0.001   0.998   0.007   0.998   0.500   0.156   0.848
    // 24.0     0.095   0.30416 -0.118  0.001   0.998   0.011   0.999   0.312   0.066   1.494
    // 28.0     0.057   0.42323 -0.126  0.002   0.998   0.013   0.999   0.135   0.035   2.463

    double[] t_lift_NACA4_1005 = {-0.018, -0.024, -0.032, -0.039, -0.027, 0.111 , 0.538 , 1.188 , 1.623 , 1.402 , 0.812 , 0.363 , 0.175 , 0.095 , 0.057     };

    double[] t_drag_NACA4_1005 = { 0.36031, 0.26584, 0.37840, 0.21784, 0.12650, 0.06993, 0.04199, 0.01390, 0.02178, 0.05662, 0.10739, 0.19528, 0.34912, 0.30416, 0.42323};


    // Name = NACA 15405
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.012  0.32283 -0.134  0.887   0.006   0.962   0.019   -0.039  1.795   -10.522
    // -24.0    -0.015  0.24936 -0.131  0.864   0.005   0.965   0.016   -0.058  3.235   -8.773
    // -20.0    -0.015  0.31099 -0.128  0.834   0.005   0.968   0.013   -0.047  -0.436  -8.445
    // -16.0    -0.005  0.19555 -0.124  0.794   0.004   0.971   0.010   -0.024  0.175   -26.339
    // -12.0    0.052   0.12269 -0.123  0.742   0.003   0.974   0.008   0.425   0.229   2.600
    // -8.0     0.302   0.07011 -0.118  0.680   0.002   0.974   0.006   4.305   0.229   0.641
    // -4.0     0.914   0.04890 -0.104  0.596   0.001   0.970   0.003   18.695  0.276   0.364
    // -0.0     1.398   0.04196 -0.147  0.423   0.009   0.956   0.013   33.316  0.458   0.355
    // 4.0      2.153   0.02201 -0.362  0.402   0.117   0.934   1.000   97.804  0.152   0.418
    // 8.0      1.874   0.05406 -0.100  0.000   0.998   0.001   0.998   34.664  0.502   0.303
    // 12.0     1.117   0.09799 -0.101  0.000   0.998   0.001   0.998   11.399  0.232   0.340
    // 16.0     0.488   0.16991 -0.126  0.000   0.998   0.003   0.998   2.874   0.203   0.507
    // 20.0     0.226   0.29952 -0.143  0.000   0.998   0.004   0.998   0.755   0.147   0.882
    // 24.0     0.119   0.29247 -0.164  0.000   0.998   0.007   0.998   0.406   -0.018  1.629
    // 28.0     0.070   0.38894 -0.185  0.000   0.998   0.012   0.998   0.179   -0.179  2.909
    double[] t_lift_NACA4_1505 = {-0.012, -0.015, -0.015, -0.005, 0.052 , 0.302 , 0.914 , 1.398 , 2.153 , 1.874 , 1.117 , 0.488 , 0.226 , 0.119 , 0.070     };

    double[] t_drag_NACA4_1505 = { 0.32283, 0.24936, 0.31099, 0.19555, 0.12269, 0.07011, 0.04890, 0.04196, 0.02201, 0.05406, 0.09799, 0.16991, 0.29952, 0.29247, 0.38894};

    // Name = NACA 20405
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.008  0.57582 -0.160  0.842   0.006   0.959   0.016   -0.014  -4.904  -19.221
    // -24.0    -0.007  0.40338 -0.154  0.808   0.006   0.961   0.012   -0.018  -0.403  -21.406
    // -20.0    -0.001  0.26903 -0.155  0.769   0.005   0.962   0.011   -0.003  0.299   0.250
    // -16.0    0.024   0.17489 -0.156  0.726   0.004   0.961   0.010   0.139   0.245   6.654
    // -12.0    0.119   0.11192 -0.154  0.676   0.003   0.957   0.008   1.068   0.241   1.540
    // -8.0     0.468   0.07128 -0.152  0.618   0.002   0.949   0.006   6.571   0.232   0.574
    // -4.0     1.259   0.05833 -0.134  0.438   0.001   0.935   0.003   21.578  0.274   0.357
    // -0.0     1.803   0.04912 -0.184  0.417   0.008   0.913   0.011   36.714  0.330   0.352
    // 4.0      2.145   0.03163 -0.205  0.015   0.998   0.014   0.998   67.810  0.031   0.346
    // 8.0      2.320   0.05230 -0.071  0.000   0.188   0.000   0.999   44.360  0.385   0.280
    // 12.0     1.427   0.09462 -0.108  0.000   0.998   0.000   0.998   15.077  0.201   0.326
    // 16.0     0.621   0.15797 -0.154  0.000   0.998   0.002   0.998   3.932   0.189   0.498
    // 20.0     0.282   0.25769 -0.178  0.000   0.998   0.003   0.998   1.094   0.156   0.881
    // 24.0     0.145   0.40268 -0.199  0.000   0.998   0.004   0.998   0.360   0.007   1.620
    // 28.0     0.083   0.37534 -0.226  0.000   0.998   0.007   0.998   0.222   -0.194  2.963

    double[] t_lift_NACA4_2005 = {-0.008, -0.007, -0.001, 0.024 , 0.119 , 0.468 , 1.259 , 1.803 , 2.145 , 2.320 , 1.427 , 0.621 , 0.282 , 0.145 , 0.083     };


    double[] t_drag_NACA4_2005 = {0.57582, 0.40338, 0.26903, 0.17489, 0.11192, 0.07128, 0.05833, 0.04912, 0.03163, 0.05230, 0.09462, 0.15797, 0.25769, 0.40268, 0.37534};

    // Name = NACA 0010
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.312  0.58589 0.011   1.000   0.002   1.000   0.010   -0.532  0.239   0.286
    // -24.0    -0.442  0.39243 0.010   1.000   0.002   1.000   0.009   -1.126  0.239   0.272
    // -20.0    -0.626  0.24464 0.008   1.000   0.003   1.000   0.006   -2.561  0.242   0.262
    // -16.0    -0.831  0.15129 0.007   1.000   0.004   1.000   0.007   -5.494  0.241   0.258
    // -12.0    -0.877  0.09026 0.005   0.980   0.005   1.000   0.010   -9.720  0.313   0.256
    // -8.0     -0.873  0.01804 0.009   0.953   0.007   1.000   0.972   -48.387 0.252   0.261
    // -4.0     -0.470  0.01248 0.005   0.887   0.157   1.000   0.999   -37.657 0.261   0.260
    // -0.0     0.000   0.00939 -0.000  0.683   0.683   1.000   0.999   0.000   0.260   0.250
    // 4.0      0.470   0.01243 -0.005  0.157   0.887   1.000   0.999   37.800  0.261   0.260
    // 8.0      0.873   0.01805 -0.009  0.007   0.953   0.971   0.999   48.340  0.252   0.261
    // 12.0     0.877   0.09026 -0.005  0.005   0.980   0.010   0.998   9.720   0.313   0.256
    // 16.0     0.831   0.15130 -0.007  0.004   0.998   0.007   0.998   5.494   0.241   0.258
    // 20.0     0.626   0.24464 -0.008  0.003   0.998   0.006   0.998   2.561   0.242   0.262
    // 24.0     0.442   0.39243 -0.010  0.002   0.998   0.009   0.999   1.126   0.239   0.272
    // 28.0     0.312   0.58589 -0.011  0.002   0.998   0.010   0.999   0.532   0.239   0.286

    double[] t_lift_NACA4_0010 = {-0.312, -0.442, -0.626, -0.831, -0.877, -0.873, -0.470, 0.000 , 0.470 , 0.873 , 0.877 , 0.831 , 0.626 , 0.442 , 0.312     };


    double[] t_drag_NACA4_0010 = {0.58589, 0.39243, 0.24464, 0.15129, 0.09026, 0.01804, 0.01248, 0.00939, 0.01243, 0.01805, 0.09026, 0.15130, 0.24464, 0.39243, 0.58589};

    // Name = NACA 5410
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.225  0.57593 -0.043  0.968   0.002   0.988   0.012   -0.391  0.269   0.060
    // -24.0    -0.302  0.43337 -0.041  0.961   0.002   0.986   0.010   -0.698  0.256   0.113
    // -20.0    -0.403  0.26078 -0.042  0.945   0.003   0.988   0.010   -1.544  0.251   0.146
    // -16.0    -0.493  0.16004 -0.041  0.922   0.005   1.000   0.008   -3.079  0.216   0.166
    // -12.0    -0.469  0.09461 -0.044  0.882   0.006   1.000   0.010   -4.962  0.280   0.156
    // -8.0     -0.230  0.05678 -0.049  0.818   0.007   1.000   0.015   -4.045  0.369   0.036
    // -4.0     0.159   0.01223 -0.119  0.716   0.019   1.000   0.999   12.979  0.337   1.000
    // -0.0     0.635   0.01243 -0.124  0.507   0.234   1.000   0.999   51.108  0.262   0.446
    // 4.0      1.103   0.01368 -0.130  0.382   0.998   1.000   0.998   80.657  0.262   0.368
    // 8.0      1.474   0.02429 -0.135  0.012   0.998   0.928   0.998   60.678  -0.045  0.341
    // 12.0     1.325   0.08785 -0.065  0.003   0.999   0.019   0.999   15.084  0.552   0.299
    // 16.0     1.202   0.14406 -0.053  0.002   0.998   0.005   0.998   8.346   0.277   0.294
    // 20.0     0.891   0.23484 -0.053  0.002   0.998   0.004   0.998   3.793   0.246   0.310
    // 24.0     0.603   0.36941 -0.055  0.001   0.999   0.004   0.999   1.632   0.229   0.342
    // 28.0     0.409   0.55037 -0.063  0.001   0.999   0.007   0.999   0.743   0.209   0.405

    double[] t_lift_NACA4_0510 = {-0.225, -0.302, -0.403, -0.493, -0.469, -0.230, 0.159 , 0.635 , 1.103 , 1.474 , 1.325 , 1.202 , 0.891 , 0.603 , 0.409     };



    double[] t_drag_NACA4_0510 = {0.57593, 0.43337, 0.26078, 0.16004, 0.09461, 0.05678, 0.01223, 0.01243, 0.01368, 0.02429, 0.08785, 0.14406, 0.23484, 0.36941, 0.55037};

    // Name = NACA10410
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.156  0.55779 -0.092  0.927   0.003   0.978   0.014   -0.280  0.347   -0.342
    // -24.0    -0.194  0.42638 -0.089  0.909   0.002   0.978   0.011   -0.456  0.364   -0.206
    // -20.0    -0.231  0.27471 -0.084  0.880   0.002   0.979   0.008   -0.840  0.281   -0.113
    // -16.0    -0.228  0.17306 -0.088  0.841   0.003   0.982   0.010   -1.317  0.277   -0.134
    // -12.0    -0.098  0.09841 -0.087  0.785   0.007   0.985   0.009   -1.001  0.266   -0.637
    // -8.0     0.216   0.05836 -0.095  0.716   0.008   0.984   0.012   3.705   0.291   0.688
    // -4.0     0.617   0.03798 -0.117  0.616   0.012   0.983   0.030   16.237  0.394   0.440
    // -0.0     1.250   0.01607 -0.244  0.429   0.051   0.972   0.999   77.811  0.375   0.445
    // 4.0      1.696   0.01798 -0.252  0.396   0.998   0.950   0.998   94.302  0.269   0.399
    // 8.0      2.078   0.02261 -0.260  0.357   0.998   0.913   0.999   91.919  0.274   0.375
    // 12.0     2.136   0.04955 -0.263  0.001   0.998   0.786   0.999   43.120  0.599   0.373
    // 16.0     1.593   0.13978 -0.091  0.000   0.998   0.003   0.999   11.398  0.433   0.307
    // 20.0     1.162   0.22691 -0.084  -0.000  0.998   0.002   0.998   5.123   0.253   0.322
    // 24.0     0.764   0.34279 -0.088  -0.001  0.998   0.002   0.998   2.228   0.219   0.365
    // 28.0     0.502   0.50645 -0.105  -0.000  0.998   0.004   0.998   0.992   0.186   0.459

    double[] t_lift_NACA4_1010 = {-0.156, -0.194, -0.231, -0.228, -0.098, 0.216 , 0.617 , 1.250 , 1.696 , 2.078 , 2.136 , 1.593 , 1.162 , 0.764 , 0.502     };

    double[] t_drag_NACA4_1010 = {0.55779, 0.42638, 0.27471, 0.17306, 0.09841, 0.05836, 0.03798, 0.01607, 0.01798, 0.02261, 0.04955, 0.13978, 0.22691, 0.34279, 0.50645};

    // Name = NACA 15410
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.104  0.56368 -0.136  0.881   0.003   0.971   0.016   -0.184  0.933   -1.064
    // -24.0    -0.114  0.38568 -0.129  0.850   0.003   0.973   0.012   -0.296  42.400  -0.882
    // -20.0    -0.104  0.26987 -0.125  0.812   0.003   0.974   0.010   -0.385  0.119   -0.950
    // -16.0    -0.027  0.17805 -0.118  0.766   0.003   0.974   0.007   -0.154  0.269   -4.044
    // -12.0    0.202   0.10790 -0.131  0.713   0.003   0.971   0.010   1.870   0.277   0.897
    // -8.0     0.620   0.06455 -0.136  0.643   0.008   0.965   0.011   9.606   0.272   0.469
    // -4.0     1.079   0.04598 -0.150  0.538   0.011   0.955   0.016   23.467  0.367   0.389
    // -0.0     1.513   0.03854 -0.240  0.419   0.029   0.934   0.141   39.263  0.438   0.409
    // 4.0      2.235   0.02495 -0.368  0.400   0.123   0.906   0.999   89.592  0.375   0.415
    // 8.0      2.634   0.03055 -0.380  0.374   0.998   0.868   0.998   86.238  0.291   0.394
    // 12.0     2.681   0.06598 -0.386  -0.000  0.998   0.759   0.998   40.632  0.680   0.394
    // 16.0     2.008   0.13522 -0.111  -0.001  0.998   0.001   0.998   14.853  0.490   0.305
    // 20.0     1.410   0.21574 -0.081  -0.002  0.998   0.000   0.998   6.533   0.268   0.307
    // 24.0     0.905   0.33285 -0.091  -0.001  0.997   0.000   0.998   2.718   0.209   0.351
    // 28.0     0.580   0.51209 -0.115  -0.001  0.997   0.001   0.997   1.133   0.176   0.448

    double[] t_lift_NACA4_1510 = {-0.104, -0.114, -0.104, -0.027, 0.202 , 0.620 , 1.079 , 1.513 , 2.235 , 2.634 , 2.681 , 2.008 , 1.410 , 0.905 , 0.580     };



    double[] t_drag_NACA4_1510 = {0.56368, 0.38568, 0.26987, 0.17805, 0.10790, 0.06455, 0.04598, 0.03854, 0.02495, 0.03055, 0.06598, 0.13522, 0.21574, 0.33285, 0.51209};

    // Name = NACA 20410
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.064  0.50315 -0.170  0.830   0.004   0.968   0.016   -0.128  -0.384  -2.397
    // -24.0    -0.054  0.36072 -0.163  0.794   0.004   0.967   0.013   -0.149  0.050   -2.791
    // -20.0    -0.008  0.25522 -0.159  0.753   0.003   0.965   0.011   -0.032  0.178   -19.222
    // -16.0    0.128   0.18811 -0.150  0.707   0.003   0.960   0.007   0.679   0.226   1.426
    // -12.0    0.448   0.11397 -0.148  0.654   0.002   0.951   0.006   3.933   0.277   0.580
    // -8.0     0.978   0.06955 -0.174  0.587   0.005   0.940   0.011   14.056  0.284   0.427
    // -4.0     1.521   0.05437 -0.185  0.436   0.010   0.919   0.013   27.966  0.332   0.371
    // -0.0     1.903   0.05042 -0.250  0.416   0.018   0.895   0.048   37.747  0.399   0.381
    // 4.0      2.706   0.03367 -0.361  0.402   0.083   0.865   0.251   80.377  0.459   0.384
    // 8.0      3.077   0.04065 -0.495  0.384   0.183   0.828   0.999   75.687  0.542   0.411
    // 12.0     3.202   0.08594 -0.506  -0.001  0.997   0.732   0.997   37.261       0.408
    // 16.0     2.347   0.13276      -0.002  0.998   -0.000  0.998   17.682        
    // 20.0     1.618   0.21740      -0.002  0.998   -0.001  0.998   7.441         
    // 24.0     1.018   0.32675      -0.001  0.998   -0.001  0.998   3.114         
    // 28.0     0.640   0.47934      -0.001  0.998   -0.002  0.998   1.336         
    
    double[] t_lift_NACA4_2010 = {-0.064, -0.054, -0.008, 0.128 , 0.448 , 0.978 , 1.521 , 1.903 , 2.706 , 3.077 , 3.202 , 2.347 , 1.618 , 1.018 , 0.640     };


    double[] t_drag_NACA4_2010 = {0.50315, 0.36072, 0.25522, 0.18811, 0.11397, 0.06955, 0.05437, 0.05042, 0.03367, 0.04065, 0.08594, 0.13276, 0.21740, 0.32675, 0.47934};
    

    // Name = NACA 0015
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.909  0.37476 0.021   1.000   0.005   1.000   0.024   -2.425  0.248   0.273
    // -24.0    -1.075  0.27558 0.020   1.000   0.006   1.000   0.038   -3.902  0.245   0.269
    // -20.0    -1.207  0.18765 0.019   0.978   0.007   1.000   0.057   -6.432  0.240   0.266
    // -16.0    -1.247  0.11477 0.019   0.961   0.011   1.000   0.135   -10.862 0.271   0.265
    // -12.0    -1.230  0.03657 0.020   0.935   0.017   1.000   0.641   -33.619 0.264   0.266
    // -8.0     -0.942  0.01998 0.014   0.879   0.038   1.000   0.938   -47.139 0.267   0.265
    // -4.0     -0.490  0.01435 0.007   0.758   0.231   1.000   0.998   -34.131 0.265   0.265
    // -0.0     0.000   0.01263 -0.000  0.504   0.504   1.000   0.998   0.000   0.265   0.250
    // 4.0      0.490   0.01434 -0.007  0.231   0.757   1.000   0.999   34.175  0.265   0.265
    // 8.0      0.942   0.01998 -0.014  0.038   0.879   0.938   0.999   47.133  0.267   0.265
    // 12.0     1.230   0.03657 -0.020  0.017   0.935   0.641   0.998   33.620  0.264   0.266
    // 16.0     1.247   0.11477 -0.019  0.011   0.961   0.135   0.999   10.862  0.271   0.265
    // 20.0     1.207   0.18765 -0.019  0.007   0.978   0.057   0.999   6.432   0.240   0.266
    // 24.0     1.075   0.27559 -0.020  0.006   0.990   0.038   0.999   3.902   0.245   0.269
    // 28.0     0.909   0.37476 -0.021  0.005   0.998   0.024   0.999   2.425   0.248   0.273

    double[] t_lift_NACA4_0015 = {-0.909, -1.075, -1.207, -1.247, -1.230, -0.942, -0.490, 0.000 , 0.490 , 0.942 , 1.230 , 1.247 , 1.207 , 1.075 , 0.909     };



    double[] t_drag_NACA4_0015 = {0.37476, 0.27558, 0.18765, 0.11477, 0.03657, 0.01998, 0.01435, 0.01263, 0.01434, 0.01998, 0.03657, 0.11477, 0.18765, 0.27559, 0.37476};

    // Name = NACA 5415
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.691  0.37662 -0.040  0.956   0.008   0.984   0.016   -1.835  0.225   0.191
    // -24.0    -0.814  0.27866 -0.044  0.940   0.008   0.984   0.021   -2.919  0.208   0.197
    // -20.0    -0.857  0.19629 -0.047  0.916   0.009   0.985   0.029   -4.365  0.685   0.195
    // -16.0    -0.790  0.12841 -0.054  0.882   0.010   0.986   0.044   -6.156  0.307   0.182
    // -12.0    -0.584  0.07936 -0.063  0.829   0.015   0.990   0.077   -7.358  0.344   0.142
    // -8.0     -0.283  0.02303 -0.101  0.751   0.024   1.000   0.622   -12.299 0.323   -0.108
    // -4.0     0.176   0.01448 -0.118  0.626   0.059   1.000   0.998   12.148  0.276   0.923
    // -0.0     0.669   0.01257 -0.126  0.433   0.239   0.983   0.999   53.266  0.266   0.438
    // 4.0      1.147   0.01587 -0.134  0.367   0.960   0.964   0.998   72.246  0.268   0.367
    // 8.0      1.583   0.02096 -0.142  0.262   0.998   0.921   0.998   75.521  0.267   0.340
    // 12.0     1.872   0.03973 -0.146  0.020   0.998   0.776   0.998   47.114  0.269   0.328
    // 16.0     1.913   0.06716 -0.148  0.009   0.998   0.603   0.998   28.482  0.279   0.327
    // 20.0     1.706   0.13226 -0.142  0.004   0.999   0.361   0.999   12.896  0.320   0.333
    // 24.0     1.374   0.26459 -0.110  0.003   0.998   0.079   0.999   5.193   0.321   0.330
    // 28.0     1.114   0.37281 -0.100  0.002   0.999   0.037   0.999   2.988   0.291   0.340

    double[] t_lift_NACA4_0515 = {-0.691, -0.814, -0.857, -0.790, -0.584, -0.283, 0.176 , 0.669 , 1.147 , 1.583 , 1.872 , 1.913 , 1.706 , 1.374 , 1.114     };


    double[] t_drag_NACA4_0515 = {0.37662, 0.27866, 0.19629, 0.12841, 0.07936, 0.02303, 0.01448, 0.01257, 0.01587, 0.02096, 0.03973, 0.06716, 0.13226, 0.26459, 0.37281};

    // Name = NACA 10415
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.488  0.39183 -0.092  0.911   0.008   0.977   0.015   -1.246  0.215   0.062
    // -24.0    -0.539  0.28429 -0.094  0.884   0.009   0.978   0.017   -1.896  0.142   0.076
    // -20.0    -0.530  0.20067 -0.097  0.849   0.009   0.979   0.019   -2.643  0.307   0.068
    // -16.0    -0.398  0.13467 -0.102  0.804   0.010   0.979   0.023   -2.958  0.291   -0.006
    // -12.0    -0.120  0.08682 -0.114  0.742   0.013   0.979   0.035   -1.380  0.294   -0.698
    // -8.0     0.256   0.05511 -0.131  0.667   0.019   0.976   0.061   4.647   0.334   0.760
    // -4.0     0.704   0.03087 -0.183  0.550   0.033   0.968   0.272   22.816  0.360   0.510
    // -0.0     1.315   0.01847 -0.247  0.420   0.091   0.949   0.999   71.164  0.320   0.438
    // 4.0      1.764   0.02077 -0.257  0.388   0.998   0.922   0.998   84.921  0.274   0.396
    // 8.0      2.195   0.02592 -0.268  0.352   0.998   0.881   0.999   84.666  0.278   0.372
    // 12.0     2.496   0.03499 -0.278  0.296   0.999   0.820   0.999   71.328  0.293   0.361
    // 16.0     2.488   0.07778 -0.281  0.006   0.999   0.672   0.999   31.992  0.220   0.363
    // 20.0     2.241   0.11730 -0.285  0.001   0.999   0.573   0.999   19.102  0.243   0.377
    // 24.0     1.841   0.18043 -0.285  -0.001  0.999   0.453   0.999   10.202  0.311   0.405
    // 28.0     1.368   0.34584 -0.232  -0.001  0.999   0.129   1.000   3.956   0.363   0.420

    double[] t_lift_NACA4_1015 = {-0.488, -0.539, -0.530, -0.398, -0.120, 0.256 , 0.704 , 1.315 , 1.764 , 2.195 , 2.496 , 2.488 , 2.241 , 1.841 , 1.368     };


    double[] t_drag_NACA4_1015 = {0.39183, 0.28429, 0.20067, 0.13467, 0.08682, 0.05511, 0.03087, 0.01847, 0.02077, 0.02592, 0.03499, 0.07778, 0.11730, 0.18043, 0.34584};

    // Name = NACA 15415
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.329  0.40223 -0.142  0.861   0.005   0.973   0.019   -0.819  0.210   -0.181
    // -24.0    -0.323  0.29105 -0.142  0.827   0.006   0.972   0.019   -1.109  0.177   -0.189
    // -20.0    -0.244  0.20322 -0.136  0.785   0.010   0.971   0.015   -1.199  0.248   -0.307
    // -16.0    -0.040  0.13660 -0.141  0.736   0.011   0.968   0.017   -0.291  0.276   -3.298
    // -12.0    0.306   0.09048 -0.150  0.679   0.012   0.963   0.021   3.379   0.285   0.740
    // -8.0     0.727   0.06098 -0.168  0.609   0.015   0.953   0.032   11.921  0.307   0.481
    // -4.0     1.166   0.04689 -0.199  0.444   0.026   0.937   0.063   24.879  0.369   0.421
    // -0.0     1.635   0.03655 -0.276  0.417   0.055   0.913   0.266   44.728  0.402   0.419
    // 4.0      2.322   0.02820 -0.374  0.398   0.140   0.883   0.999   82.358  0.354   0.411
    // 8.0      2.726   0.03441 -0.390  0.370   0.998   0.844   0.998   79.228  0.290   0.393
    // 12.0     3.073   0.04338 -0.404  0.350   0.998   0.791   0.998   70.832  0.324   0.382
    // 16.0     3.029   0.09726 -0.412  0.002   0.998   0.679   0.999   31.139  0.193   0.386
    // 20.0     2.721   0.13509 -0.424  -0.003  0.998   0.616   0.999   20.142  0.221   0.406
    // 24.0     2.243   0.18511 -0.435  -0.003  0.998   0.555   0.998   12.118  0.231   0.444
    // 28.0     1.750   0.25303 -0.442  -0.003  0.999   0.483   0.999   6.916   0.236   0.503

    double[] t_lift_NACA4_1515 = {-0.329, -0.323, -0.244, -0.040, 0.306 , 0.727 , 1.166 , 1.635 , 2.322 , 2.726 , 3.073 , 3.029 , 2.721 , 2.243 , 1.750     };


    double[] t_drag_NACA4_1515 = {0.40223, 0.29105, 0.20322, 0.13660, 0.09048, 0.06098, 0.04689, 0.03655, 0.02820, 0.03441, 0.04338, 0.09726, 0.13509, 0.18511, 0.25303};

    // Name = NACA 20415
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.204  0.41542 -0.172  0.815   0.004   0.967   0.016   -0.492  0.296   -0.594
    // -24.0    -0.151  0.29248 -0.175  0.775   0.005   0.965   0.018   -0.518  0.284   -0.905
    // -20.0    -0.011  0.21007 -0.179  0.732   0.005   0.961   0.019   -0.053  0.265   -15.854
    // -16.0    0.266   0.14033 -0.181  0.684   0.009   0.953   0.018   1.899   0.258   0.930
    // -12.0    0.687   0.09525 -0.184  0.631   0.012   0.942   0.018   7.213   0.270   0.518
    // -8.0     1.170   0.06669 -0.199  0.565   0.014   0.926   0.022   17.548  0.301   0.420
    // -4.0     1.610   0.05493 -0.231  0.434   0.018   0.903   0.038   29.306  0.367   0.394
    // -0.0     2.020   0.05076 -0.298  0.415   0.038   0.878   0.110   39.797  0.369   0.398
    // 4.0      2.809   0.03721 -0.374  0.401   0.099   0.848   0.272   75.474  0.430   0.383
    // 8.0      3.182   0.04496 -0.507  0.383   0.190   0.812   0.999   70.765  0.472   0.409
    // 12.0     3.506   0.05533 -0.529  0.364   0.997   0.769   0.997   63.361  0.351   0.401
    // 16.0     3.536   0.12258 -0.543  -0.005  0.998   0.672   0.998   28.850  0.146   0.403
    // 20.0     3.177   0.16124 -0.563  -0.005  0.998   0.626   0.998   19.702  0.206   0.427
    // 24.0     2.624   0.21018 -0.583  -0.005  0.998   0.583   0.998   12.484  0.217   0.472
    // 28.0     2.053   0.26914 -0.600  -0.005  0.997   0.540   0.998   7.628   0.219   0.542

    double[] t_lift_NACA4_2015 = {-0.204, -0.151, -0.011, 0.266 , 0.687 , 1.170 , 1.610 , 2.020 , 2.809 , 3.182 , 3.506 , 3.536 , 3.177 , 2.624 , 2.053     };


    double[] t_drag_NACA4_2015 = {0.41542, 0.29248, 0.21007, 0.14033, 0.09525, 0.06669, 0.05493, 0.05076, 0.03721, 0.04496, 0.05533, 0.12258, 0.16124, 0.21018, 0.26914};

    // Name = NACA 0020
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -1.475  0.31137 0.040   0.978   0.013   1.000   0.103   -4.736  0.242   0.277
    // -24.0    -1.605  0.21713 0.039   0.966   0.015   1.000   0.156   -7.390  0.237   0.274
    // -20.0    -1.658  0.13342 0.038   0.949   0.018   1.000   0.269   -12.425 0.414   0.273
    // -16.0    -1.578  0.06898 0.035   0.921   0.027   1.000   0.467   -22.871 0.279   0.272
    // -12.0    -1.353  0.03465 0.029   0.876   0.045   1.000   0.714   -39.052 0.274   0.272
    // -8.0     -0.979  0.02160 0.021   0.789   0.108   1.000   0.901   -45.316 0.272   0.271
    // -4.0     -0.505  0.01676 0.011   0.622   0.247   1.000   0.969   -30.149 0.271   0.271
    // -0.0     -0.000  0.01576 -0.000  0.421   0.421   1.000   0.999   -0.000  0.271   0.250
    // 4.0      0.505   0.01676 -0.011  0.247   0.622   0.969   0.999   30.149  0.271   0.271
    // 8.0      0.979   0.02160 -0.021  0.108   0.789   0.901   0.999   45.316  0.272   0.271
    // 12.0     1.353   0.03465 -0.029  0.045   0.876   0.714   0.998   39.052  0.274   0.272
    // 16.0     1.578   0.06898 -0.035  0.027   0.921   0.467   0.999   22.871  0.279   0.272
    // 20.0     1.658   0.13342 -0.038  0.018   0.949   0.269   0.999   12.425  0.414   0.273
    // 24.0     1.605   0.21713 -0.039  0.015   0.966   0.156   1.000   7.390   0.237   0.274
    // 28.0     1.475   0.31137 -0.040  0.013   0.978   0.103   0.999   4.736   0.242   0.277

    double[] t_lift_NACA4_0020 = {-1.475, -1.605, -1.658, -1.578, -1.353, -0.979, -0.505, -0.000, 0.505 , 0.979 , 1.353 , 1.578 , 1.658 , 1.605 , 1.475     };

    double[] t_drag_NACA4_0020 = {0.31137, 0.21713, 0.13342, 0.06898, 0.03465, 0.02160, 0.01676, 0.01576, 0.01676, 0.02160, 0.03465, 0.06898, 0.13342, 0.21713, 0.31137};


    // Name = NACA 5420
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -1.172  0.32119 -0.046  0.937   0.013   0.980   0.064   -3.650  0.155   0.211
    // -24.0    -1.203  0.23686 -0.049  0.914   0.015   0.981   0.077   -5.080  0.484   0.210
    // -20.0    -1.140  0.16504 -0.053  0.883   0.020   0.981   0.095   -6.909  0.310   0.203
    // -16.0    -0.964  0.10403 -0.063  0.840   0.024   0.982   0.160   -9.270  0.302   0.185
    // -12.0    -0.674  0.05455 -0.077  0.774   0.034   0.983   0.311   -12.350 0.313   0.135
    // -8.0     -0.307  0.01755 -0.104  0.682   0.055   0.983   0.908   -17.486 0.295   -0.090
    // -4.0     0.193   0.01673 -0.116  0.547   0.113   0.978   0.998   11.558  0.272   0.852
    // -0.0     0.704   0.01727 -0.127  0.417   0.251   0.962   1.000   40.790  0.272   0.431
    // 4.0      1.190   0.01858 -0.138  0.357   0.835   0.934   1.000   64.050  0.273   0.366
    // 8.0      1.645   0.02406 -0.149  0.267   0.938   0.883   1.000   68.400  0.274   0.341
    // 12.0     2.007   0.03759 -0.158  0.123   0.972   0.782   1.000   53.405  0.276   0.329
    // 16.0     2.207   0.06538 -0.164  0.031   0.999   0.635   1.000   33.754  0.291   0.324
    // 20.0     2.249   0.10615 -0.168  0.017   1.000   0.505   1.000   21.185  0.167   0.325
    // 24.0     2.126   0.16852 -0.171  0.010   1.000   0.392   1.000   12.616  0.252   0.330
    // 28.0     1.864   0.26323 -0.168  0.007   1.000   0.269   1.000   7.081   0.261   0.340

    double[] t_lift_NACA4_0520 = {-1.172, -1.203, -1.140, -0.964, -0.674, -0.307, 0.193 , 0.704 , 1.190 , 1.645 , 2.007 , 2.207 , 2.249 , 2.126 , 1.864     };


    double[] t_drag_NACA4_0520 = {0.32119, 0.23686, 0.16504, 0.10403, 0.05455, 0.01755, 0.01673, 0.01727, 0.01858, 0.02406, 0.03759, 0.06538, 0.10615, 0.16852, 0.26323};

    // Name = NACA 10420
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.889  0.32829 -0.108  0.889   0.013   0.974   0.040   -2.707  0.347   0.129
    // -24.0    -0.860  0.24399 -0.110  0.857   0.014   0.974   0.046   -3.526  0.304   0.122
    // -20.0    -0.721  0.17311 -0.117  0.817   0.016   0.975   0.059   -4.163  0.287   0.088
    // -16.0    -0.470  0.11761 -0.125  0.767   0.020   0.973   0.074   -3.997  0.282   -0.015
    // -12.0    -0.120  0.07725 -0.136  0.703   0.028   0.970   0.097   -1.558  0.301   -0.878
    // -8.0     0.298   0.04607 -0.164  0.620   0.038   0.963   0.201   6.472   0.351   0.799
    // -4.0     0.875   0.01875 -0.237  0.475   0.065   0.950   0.999   46.674  0.329   0.520
    // -0.0     1.381   0.02113 -0.249  0.415   0.134   0.927   0.999   65.347  0.277   0.430
    // 4.0      1.832   0.02459 -0.262  0.384   0.294   0.896   0.999   74.517  0.281   0.393
    // 8.0      2.269   0.02947 -0.276  0.348   0.999   0.851   0.999   76.997  0.284   0.372
    // 12.0     2.641   0.03927 -0.290  0.294   0.999   0.795   0.999   67.247  0.295   0.360
    // 16.0     2.841   0.05832 -0.302  0.202   0.999   0.720   0.999   48.709  0.351   0.356
    // 20.0     2.817   0.11372 -0.308  0.015   0.999   0.592   0.999   24.771  0.180   0.359
    // 24.0     2.639   0.16530 -0.316  0.004   0.999   0.513   0.999   15.964  0.220   0.370
    // 28.0     2.299   0.23083 -0.323  0.001   0.999   0.444   0.999   9.958   0.229   0.391

    double[] t_lift_NACA4_1020 = {-0.889, -0.860, -0.721, -0.470, -0.120, 0.298 , 0.875 , 1.381 , 1.832 , 2.269 , 2.641 , 2.841 , 2.817 , 2.639 , 2.299     };


    double[] t_drag_NACA4_1020 = {0.32829, 0.24399, 0.17311, 0.11761, 0.07725, 0.04607, 0.01875, 0.02113, 0.02459, 0.02947, 0.03927, 0.05832, 0.11372, 0.16530, 0.23083};

    // Name = NACA 15420
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.610  0.33188 -0.148  0.843   0.014   0.969   0.025   -1.839  0.277   0.008
    // -24.0    -0.529  0.24819 -0.150  0.807   0.014   0.967   0.028   -2.132  0.284   -0.034
    // -20.0    -0.341  0.17883 -0.157  0.764   0.015   0.965   0.034   -1.905  0.289   -0.211
    // -16.0    -0.031  0.12377 -0.169  0.712   0.017   0.960   0.046   -0.253  0.287   -5.163
    // -12.0    0.365   0.08391 -0.183  0.651   0.021   0.952   0.060   4.344   0.288   0.753
    // -8.0     0.806   0.05803 -0.201  0.574   0.031   0.940   0.080   13.885  0.315   0.500
    // -4.0     1.260   0.04408 -0.242  0.439   0.045   0.920   0.163   28.577  0.385   0.442
    // -0.0     2.007   0.02681 -0.363  0.415   0.085   0.894   0.999   74.844  0.371   0.431
    // 4.0      2.411   0.03169 -0.381  0.398   0.166   0.862   0.999   76.096  0.295   0.408
    // 8.0      2.820   0.03844 -0.400  0.368   0.999   0.823   0.999   73.363  0.299   0.392
    // 12.0     3.181   0.04803 -0.419  0.346   0.999   0.774   0.999   66.235  0.311   0.382
    // 16.0     3.429   0.06302 -0.437  0.312   0.999   0.720   0.999   54.420  0.407   0.377
    // 20.0     3.413   0.08593 -0.455  0.267   0.999   0.665   0.999   39.716  0.163   0.383
    // 24.0     3.117   0.18356 -0.464  -0.002  0.999   0.563   0.999   16.979  0.216   0.399
    // 28.0     2.695   0.24323 -0.479  -0.005  0.999   0.513   0.999   11.079  0.215   0.428

    double[] t_lift_NACA4_1520 = {-0.610, -0.529, -0.341, -0.031, 0.365 , 0.806 , 1.260 , 2.007 , 2.411 , 2.820 , 3.181 , 3.429 , 3.413 , 3.117 , 2.695     };


    double[] t_drag_NACA4_1520 = {0.33188, 0.24819, 0.17883, 0.12377, 0.08391, 0.05803, 0.04408, 0.02681, 0.03169, 0.03844, 0.04803, 0.06302, 0.08593, 0.18356, 0.24323};


    // Name = NACA 20420
    // Mach = 0; Re = 300000; T.U. = 1.0; T.L. = 1.0
    // Surface Finish = 0; Stall model = 0; Transition model = 1; Aspect Ratio = 0; ground effect = 0
    //       Cl      Cd      Cm 0.25 T.U.    T.L.    S.U.    S.L.    L/D     A.C.    C.P.
    // [ ]   [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]     [-]
    // -28.0    -0.384  0.33708 -0.193  0.796   0.009   0.965   0.029   -1.139  0.185   -0.253
    // -24.0    -0.247  0.24958 -0.184  0.758   0.013   0.960   0.024   -0.988  0.233   -0.497
    // -20.0    0.002   0.18194 -0.186  0.715   0.015   0.952   0.024   0.010   0.269   100.285
    // -16.0    0.368   0.12932 -0.196  0.668   0.017   0.944   0.028   2.849   0.282   0.781
    // -12.0    0.812   0.09027 -0.212  0.612   0.018   0.930   0.036   8.994   0.296   0.511
    // -8.0     1.281   0.06551 -0.238  0.534   0.022   0.914   0.053   19.551  0.311   0.435
    // -4.0     1.705   0.05543 -0.267  0.433   0.036   0.890   0.076   30.768  0.354   0.406
    // -0.0     2.139   0.05160 -0.327  0.415   0.063   0.863   0.166   41.447  0.354   0.403
    // 4.0      2.914   0.04079 -0.393  0.402   0.120   0.833   0.321   71.432  0.417   0.385
    // 8.0      3.290   0.04952 -0.519  0.383   0.205   0.798   0.999   66.443  0.468   0.408
    // 12.0     3.616   0.06034 -0.546  0.363   0.998   0.758   0.999   59.932  0.337   0.401
    // 16.0     3.894   0.07538 -0.571  0.347   0.999   0.708   0.999   51.655  0.412   0.397
    // 20.0     3.920   0.09570 -0.595  0.333   0.999   0.649   0.999   40.963  0.120   0.402
    // 24.0     3.558   0.21309 -0.615  -0.007  0.999   0.584   0.999   16.695  0.199   0.423
    // 28.0     3.063   0.26953 -0.639  -0.009  0.999   0.547   0.999   11.365  0.202   0.459

    double[] t_lift_NACA4_2020 = {-0.384, -0.247, 0.002 , 0.368 , 0.812 , 1.281 , 1.705 , 2.139 , 2.914 , 3.290 , 3.616 , 3.894 , 3.920 , 3.558 , 3.063     };

    double[] t_drag_NACA4_2020 = {0.33708, 0.24958, 0.18194, 0.12932, 0.09027, 0.06551, 0.05543, 0.05160, 0.04079, 0.04952, 0.06034, 0.07538, 0.09570, 0.21309, 0.26953};

    double[][] t_lift_NACA4 = {
      t_lift_NACA4_0005, 
      t_lift_NACA4_0505, 
      t_lift_NACA4_1005, 
      t_lift_NACA4_1505, 
      t_lift_NACA4_2005, 
      t_lift_NACA4_0010,
      t_lift_NACA4_0510,
      t_lift_NACA4_1010,
      t_lift_NACA4_1510,
      t_lift_NACA4_2010,
      t_lift_NACA4_0015,
      t_lift_NACA4_0515,
      t_lift_NACA4_1015,
      t_lift_NACA4_1515,
      t_lift_NACA4_2015,
      t_lift_NACA4_0020,
      t_lift_NACA4_0520,
      t_lift_NACA4_1020,
      t_lift_NACA4_1520,
      t_lift_NACA4_2020
    };

    double[][] t_drag_NACA4 = {
      t_drag_NACA4_0005, 
      t_drag_NACA4_0505, 
      t_drag_NACA4_1005, 
      t_drag_NACA4_1505, 
      t_drag_NACA4_2005, 

      t_drag_NACA4_0010,
      t_drag_NACA4_0510,
      t_drag_NACA4_1010,
      t_drag_NACA4_1510,
      t_drag_NACA4_2010,

      t_drag_NACA4_0015,
      t_drag_NACA4_0515,
      t_drag_NACA4_1015,
      t_drag_NACA4_1515,
      t_drag_NACA4_2015,

      t_drag_NACA4_0020,
      t_drag_NACA4_0520,
      t_drag_NACA4_1020,
      t_drag_NACA4_1520,
      t_drag_NACA4_2020
    };


    // NACA 6 series variants
    // use this to convert excel column of 25 values to array initializer:
    /* 
       (fset 'conv_25_rows_to_array_initializer
   [?\C-y ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\M-^ ?\C-a ?\{ ?\C-e ?\} ?\C-  ?\C-\M-b ?\C-e ?\C-  ?\C-a ?\C-x ?n ?n ?\C-a ?\M-x ?r ?e ?p ?l ?  ?s ?t ?r ?i ?n ?g return ?  return ?, ?  return ?\C-b ?\C-b ?\C-d ?\C-d ?\C-a ?\C-x ?n ?w])
    */

    // NACA 64_814 with TE gap = 0.5%
    double[] t_lift_NACA_64_814_teg05 = {-0.436, -0.495, -0.549, -0.585, -0.585, -0.521, -0.415, -0.271, -0.097, 0.112, 0.353, 0.596, 0.835, 1.073, 1.302, 1.494, 1.644, 1.715, 1.408, 1.315, 1.167, 1.003, 0.843, 0.702, 0.584};
    double[] t_drag_NACA_64_814_teg05 = {0.31324, 0.2687, 0.21301, 0.17075, 0.13549, 0.1072, 0.08288, 0.06413, 0.05002, 0.01114, 0.00998, 0.00805, 0.00833, 0.00811, 0.00777, 0.021, 0.02575, 0.03206, 0.08869, 0.11247, 0.14528, 0.18438, 0.23803, 0.29672, 0.34426};
    

    // cubic-interpolate using array of -28 to +28 step 4 lift or drag data.
    // for CI, the array must have 2 padding values on each size of target range.
    // hence target range here is -20...20
    // example: ci15(t_drag_NACA4_20020, 3.21);
    double ci15(double[] tab, double aoa) {
      if (tab.length != 15) 
        System.out.println(" *** WARNING  ci15 cubic interpolates arrays of 15. got tab.length: " + tab.length);
      int aoa_4 = (int)Math.floor(aoa/4);
      int t_idx = aoa_4 + 7; // 7 is (15-1)/2

      // direct hit?
      if (aoa/4 == (double)aoa_4) // this also allows to grab any of 15 valies, -28...28: ci15(mytab, -28)
        return tab[t_idx];

      double c_0 = tab[t_idx-1];
      double c_1 = tab[t_idx];
      double c_2 = tab[t_idx+1];
      double c_3 = tab[t_idx+2];
      double mu = Math.abs(aoa - 4*aoa_4)/4.0;
      double res = CubicInterpolate(c_0, c_1, c_2, c_3, mu);
      return res;
    }

    // cubic-interpolate using array of -24 to +24 step 2 lift or drag data.
    // for CI, the array must have 2 padding values on each size of target range.
    // hence target range here is -20...20
    // example: ci25(t_drag_NACA_64_814_teg05, 3.21);
    double ci25(double[] tab, double aoa) {
      if (tab.length != 25) 
        System.out.println(" *** WARNING  ci25 cubic interpolates arrays of 25. got tab.length: " + tab.length);
      int aoa_2 = (int)Math.floor(aoa/2);
      int t_idx = aoa_2 + 12; // (25-1)/2

      // direct hit?
      if (aoa/2 == (double)aoa_2) // this also allows to grab any of 25 valies: ci25(mytab, -24)
        return tab[t_idx];

      double c_0 = tab[t_idx-1];
      double c_1 = tab[t_idx];
      double c_2 = tab[t_idx+1];
      double c_3 = tab[t_idx+2];
      double mu = Math.abs(aoa - 2*aoa_2)/2.0;
      double res = CubicInterpolate(c_0, c_1, c_2, c_3, mu);
      return res;
    }



    double ci15_from_javafoil_data(double[][] t_thick_camb, double aoa, double thickness, double camber) {

      double c_Cam0Thk5, c_Cam5Thk5, c_Cam10Thk5, c_Cam15Thk5, c_Cam20Thk5;
      double c_Cam0Thk10, c_Cam5Thk10, c_Cam10Thk10, c_Cam15Thk10, c_Cam20Thk10;
      double c_Cam0Thk15, c_Cam5Thk15, c_Cam10Thk15, c_Cam15Thk15, c_Cam20Thk15;
      double c_Cam0Thk20, c_Cam5Thk20, c_Cam10Thk20, c_Cam15Thk20, c_Cam20Thk20;
      double c_Thk5, c_Thk10, c_Thk15, c_Thk20;

      double c = 1;

      // System.out.println("-- doing C__COMP_NACA4SERIES ");
      // thickness 5%
      c_Cam0Thk5  = ci15(t_thick_camb[0], aoa);
      c_Cam5Thk5  = ci15(t_thick_camb[1], aoa);
      c_Cam10Thk5 = ci15(t_thick_camb[2], aoa);
      c_Cam15Thk5 = ci15(t_thick_camb[3], aoa);
      c_Cam20Thk5 = ci15(t_thick_camb[4], aoa);

      // thickness 10%
      c_Cam0Thk10  = ci15(t_thick_camb[5], aoa);
      c_Cam5Thk10  = ci15(t_thick_camb[6], aoa);
      c_Cam10Thk10 = ci15(t_thick_camb[7], aoa);
      c_Cam15Thk10 = ci15(t_thick_camb[8], aoa);
      c_Cam20Thk10 = ci15(t_thick_camb[9], aoa);

      // thickness 15%
      c_Cam0Thk15  = ci15(t_thick_camb[10], aoa);
      c_Cam5Thk15  = ci15(t_thick_camb[11], aoa);
      c_Cam10Thk15 = ci15(t_thick_camb[12], aoa);
      c_Cam15Thk15 = ci15(t_thick_camb[13], aoa);
      c_Cam20Thk15 = ci15(t_thick_camb[14], aoa);

      // thickness 20%
      c_Cam0Thk20  = ci15(t_thick_camb[15], aoa);
      c_Cam5Thk20  = ci15(t_thick_camb[16], aoa);
      c_Cam10Thk20 = ci15(t_thick_camb[17], aoa);
      c_Cam15Thk20 = ci15(t_thick_camb[18], aoa);
      c_Cam20Thk20 = ci15(t_thick_camb[19], aoa);

      if (-20.0 <= camber && camber < -15.0)
        {
          c_Thk5 = (camber/5 + 4)*(c_Cam15Thk5 - c_Cam20Thk5) + c_Cam20Thk5;
          c_Thk10 = (camber/5 + 4)*(c_Cam15Thk10 - c_Cam20Thk10) + c_Cam20Thk10;
          c_Thk15 = (camber/5 + 4)*(c_Cam15Thk15 - c_Cam20Thk15) + c_Cam20Thk15;
          c_Thk20 = (camber/5 + 4)*(c_Cam15Thk20 - c_Cam20Thk20) + c_Cam20Thk20;
                    
          if (1.0 <= thickness && thickness <= 5.0)
            {
              c = c_Thk5;
            }
          else if (5.0 < thickness && thickness <= 10.0)
            {
              c = (thickness/5 - 1)*(c_Thk10 - c_Thk5) + c_Thk5;
            }
          else if (10.0 < thickness && thickness <= 15.0)
            {
              c = (thickness/5 - 2)*(c_Thk15 - c_Thk10) + c_Thk10;
            }
          else if (15.0 < thickness && thickness <= 20.0)
            {
              c = (thickness/5 - 3)*(c_Thk20 - c_Thk15) + c_Thk15;
            }
        }
      else if (-15.0 <= camber && camber < -10.0)
        {
          c_Thk5 = (camber/5 + 3)*(c_Cam10Thk5 - c_Cam15Thk5) + c_Cam15Thk5;
          c_Thk10 = (camber/5 + 3)*(c_Cam10Thk10 - c_Cam15Thk10) + c_Cam15Thk10;
          c_Thk15 = (camber/5 + 3)*(c_Cam10Thk15 - c_Cam15Thk15) + c_Cam15Thk15;
          c_Thk20 = (camber/5 + 3)*(c_Cam10Thk20 - c_Cam15Thk20) + c_Cam15Thk20;

          if (1.0 <= thickness && thickness <= 5.0)
            {
              c = c_Thk5;
            }
          else if (5.0 < thickness && thickness <= 10.0)
            {
              c = (thickness/5 - 1)*(c_Thk10 - c_Thk5) + c_Thk5;
            }
          else if (10.0 < thickness && thickness <= 15.0)
            {
              c = (thickness/5 - 2)*(c_Thk15 - c_Thk10) + c_Thk10;
            }
          else if (15.0 < thickness && thickness <= 20.0)
            {
              c = (thickness/5 - 3)*(c_Thk20 - c_Thk15) + c_Thk15;
            }
        }
      else if (-10.0 <= camber && camber < -5.0)
        {
          c_Thk5 = (camber/5 + 2)*(c_Cam5Thk5 - c_Cam10Thk5) + c_Cam10Thk5;
          c_Thk10 = (camber/5 + 2)*(c_Cam5Thk10 - c_Cam10Thk10) + c_Cam10Thk10;
          c_Thk15 = (camber/5 + 2)*(c_Cam5Thk15 - c_Cam10Thk15) + c_Cam10Thk15;
          c_Thk20 = (camber/5 + 2)*(c_Cam5Thk20 - c_Cam10Thk20) + c_Cam10Thk20;

          if (1.0 <= thickness && thickness <= 5.0)
            {
              c = c_Thk5;
            }
          else if (5.0 < thickness && thickness <= 10.0)
            {
              c = (thickness/5 - 1)*(c_Thk10 - c_Thk5) + c_Thk5;
            }
          else if (10.0 < thickness && thickness <= 15.0)
            {
              c = (thickness/5 - 2)*(c_Thk15 - c_Thk10) + c_Thk10;
            }
          else if (15.0 < thickness && thickness <= 20.0)
            {
              c = (thickness/5 - 3)*(c_Thk20 - c_Thk15) + c_Thk15;
            }
        }
      else if (-5.0 <= camber && camber < 0)
        {
          c_Thk5 = (camber/5 + 1)*(c_Cam0Thk5 - c_Cam5Thk5) + c_Cam5Thk5;
          c_Thk10 = (camber/5 + 1)*(c_Cam0Thk10 - c_Cam5Thk10) + c_Cam5Thk10;
          c_Thk15 = (camber/5 + 1)*(c_Cam0Thk15 - c_Cam5Thk15) + c_Cam5Thk15;
          c_Thk20 = (camber/5 + 1)*(c_Cam0Thk20 - c_Cam5Thk20) + c_Cam5Thk20;

          if (1.0 <= thickness && thickness <= 5.0)
            {
              c = c_Thk5;
            }
          else if (5.0 < thickness && thickness <= 10.0)
            {
              c = (thickness/5 - 1)*(c_Thk10 - c_Thk5) + c_Thk5;
            }
          else if (10.0 < thickness && thickness <= 15.0)
            {
              c = (thickness/5 - 2)*(c_Thk15 - c_Thk10) + c_Thk10;
            }
          else if (15.0 < thickness && thickness <= 20.0)
            {
              c = (thickness/5 - 3)*(c_Thk20 - c_Thk15) + c_Thk15;
            }
        }
      else if (0 <= camber && camber < 5)
        {
          c_Thk5 = (camber/5)*(c_Cam5Thk5 - c_Cam0Thk5) + c_Cam0Thk5;
          c_Thk10 = (camber/5)*(c_Cam5Thk10 - c_Cam0Thk10) + c_Cam0Thk10;
          c_Thk15 = (camber/5)*(c_Cam5Thk15 - c_Cam0Thk15) + c_Cam0Thk15;
          c_Thk20 = (camber/5)*(c_Cam5Thk20 - c_Cam0Thk20) + c_Cam0Thk20;

          if (1.0 <= thickness && thickness <= 5.0)
            {
              c = c_Thk5;
            }
          else if (5.0 < thickness && thickness <= 10.0)
            {
              c = (thickness/5 - 1)*(c_Thk10 - c_Thk5) + c_Thk5;
            }
          else if (10.0 < thickness && thickness <= 15.0)
            {
              c = (thickness/5 - 2)*(c_Thk15 - c_Thk10) + c_Thk10;
            }
          else if (15.0 < thickness && thickness <= 20.0)
            {
              c = (thickness/5 - 3)*(c_Thk20 - c_Thk15) + c_Thk15;
            }
        }
      else if (5 <= camber && camber < 10)
        {
          c_Thk5 = (camber/5 - 1)*(c_Cam10Thk5 - c_Cam5Thk5) + c_Cam5Thk5;
          c_Thk10 = (camber/5 - 1)*(c_Cam10Thk10 - c_Cam5Thk10) + c_Cam5Thk10;
          c_Thk15 = (camber/5 - 1)*(c_Cam10Thk15 - c_Cam5Thk15) + c_Cam5Thk15;
          c_Thk20 = (camber/5 - 1)*(c_Cam10Thk20 - c_Cam5Thk20) + c_Cam5Thk20;

          if (1.0 <= thickness && thickness <= 5.0)
            {
              c = c_Thk5;
            }
          else if (5.0 < thickness && thickness <= 10.0)
            {
              c = (thickness/5 - 1)*(c_Thk10 - c_Thk5) + c_Thk5;
            }
          else if (10.0 < thickness && thickness <= 15.0)
            {
              c = (thickness/5 - 2)*(c_Thk15 - c_Thk10) + c_Thk10;
            }
          else if (15.0 < thickness && thickness <= 20.0)
            {
              c = (thickness/5 - 3)*(c_Thk20 - c_Thk15) + c_Thk15;
            }
        }
      else if (10 <= camber && camber < 15)
        {
          c_Thk5 = (camber/5 - 2)*(c_Cam15Thk5 - c_Cam10Thk5) + c_Cam10Thk5;
          c_Thk10 = (camber/5 - 2)*(c_Cam15Thk10 - c_Cam10Thk10) + c_Cam10Thk10;
          c_Thk15 = (camber/5 - 2)*(c_Cam15Thk15 - c_Cam10Thk15) + c_Cam10Thk15;
          c_Thk20 = (camber/5 - 2)*(c_Cam15Thk20 - c_Cam10Thk20) + c_Cam10Thk20;

          if (1.0 <= thickness && thickness <= 5.0)
            {
              c = c_Thk5;
            }
          else if (5.0 < thickness && thickness <= 10.0)
            {
              c = (thickness/5 - 1)*(c_Thk10 - c_Thk5) + c_Thk5;
            }
          else if (10.0 < thickness && thickness <= 15.0)
            {
              c = (thickness/5 - 2)*(c_Thk15 - c_Thk10) + c_Thk10;
            }
          else if (15.0 < thickness && thickness <= 20.0)
            {
              c = (thickness/5 - 3)*(c_Thk20 - c_Thk15) + c_Thk15;
            }
        }
      else if (15 <= camber && camber <= 20)
        {
          c_Thk5 = (camber/5 - 3)*(c_Cam20Thk5 - c_Cam15Thk5) + c_Cam15Thk5;
          c_Thk10 = (camber/5 - 3)*(c_Cam20Thk10 - c_Cam15Thk10) + c_Cam15Thk10;
          c_Thk15 = (camber/5 - 3)*(c_Cam20Thk15 - c_Cam15Thk15) + c_Cam15Thk15;
          c_Thk20 = (camber/5 - 3)*(c_Cam20Thk20 - c_Cam15Thk20) + c_Cam15Thk20;

          if (1.0 <= thickness && thickness <= 5.0)
            {
              c = c_Thk5;
            }
          else if (5.0 < thickness && thickness <= 10.0)
            {
              c = (thickness/5 - 1)*(c_Thk10 - c_Thk5) + c_Thk5;
            }
          else if (10.0 < thickness && thickness <= 15.0)
            {
              c = (thickness/5 - 2)*(c_Thk15 - c_Thk10) + c_Thk10;
            }
          else if (15.0 < thickness && thickness <= 20.0)
            {
              c = (thickness/5 - 3)*(c_Thk20 - c_Thk15) + c_Thk15;
            }
        }

      // System.out.println("-- aoa: " + aoa + " camber: " + camber + " c: " + c);
      // allow re and aspect corrections if(true) return; 
      return c;
    }

    // Compute 15-elt array of Cl values for given cl tables, thickness and camber.
    // Can beused to load cache cache_t_Cl
    double[] compute_t_Cl(double[][] t_lift, double thickness, double camber) {
      double[] result = new double[15];
      for (int aoa = -28, i = 0; aoa <= 28; aoa += 4, i++) 
        result[i] = ci15_from_javafoil_data(t_lift, aoa, thickness, camber);
      return result;
    }

    // Drag Interpolator
    // effaoa is in dgegrees
    // thickness and camber are in %
    public void getDrag(double cldin, double effaoa, double thickness, double camber)
    {
      double reynolds_correction_fixpt = 50000; // value used by FoilSim

      int index,ifound ;  
      double dragCam0Thk5, dragCam5Thk5, dragCam10Thk5, dragCam15Thk5, dragCam20Thk5;
      double dragCam0Thk10, dragCam5Thk10, dragCam10Thk10, dragCam15Thk10, dragCam20Thk10;
      double dragCam0Thk15, dragCam5Thk15, dragCam10Thk15, dragCam15Thk15, dragCam20Thk15;
      double dragCam0Thk20, dragCam5Thk20, dragCam10Thk20, dragCam15Thk20, dragCam20Thk20;
      double dragThk5, dragThk10, dragThk15, dragThk20;
      double dragCam0, dragCam5, dragCam10, dragCam15, dragCam20;  //used for the flat plate drag values
      double recyl[]  = {.1, .2, .4, .5, .6, .8, 1.0,
                         2.0, 4.0, 5.0, 6.0, 8.0, 10.0,
                         20.0, 40.0, 50.0, 60.0, 80.0, 100.0,
                         200.0, 400.0, 500.0, 600.0, 800.0, 1000.,
                         2000., 4000., 5000., 6000., 8000., 10000.,
                         100000.,200000.,400000.,500000.,600000.,800000.,1000000.,
                         2000000.,4000000.,5000000.,6000000.,8000000.,1000000000000. } ; 
      double cdcyl[]  = {70., 35., 20., 17., 15., 13., 10.,
                         7., 5.5, 5.0, 4.5, 4., 3.5,
                         3.0, 2.7, 2.5, 2.0, 2.0, 1.9,
                         1.6, 1.4, 1.2, 1.1, 1.1, 1.0, 
                         1.2, 1.4, 1.4, 1.5, 1.5, 1.6,
                         1.6, 1.4, .4, .28, .32, .4, .45,
                         .6, .8, .8, .85, .9, .9 } ; 
      double resps[]  = {.1, .2, .4, .5, .6, .8, 1.0,
                         2.0, 4.0, 5.0, 6.0, 8.0, 10.0,
                         20., 40., 50., 60., 80.0, 100.0,
                         200., 400., 500., 600., 800.0, 1000.,
                         2000., 4000., 5000., 6000., 8000., 10000.,
                         20000., 40000., 50000., 60000., 80000., 100000.,
                         200000., 400000., 500000., 600000., 800000., 1000000.,
                         2000000., 4000000., 5000000., 6000000., 8000000., 1000000000000. } ; 

      double cdsps[]  = {270., 110., 54., 51., 40., 35., 28.,
                         15., 8.5, 7.5, 6.0, 5.4, 4.9,
                         3.1, 1.9, 1.8, 1.5, 1.3, 1.1,
                         0.81, 0.6, 0.58, 0.56, 0.5, 0.49, 
                         0.40, 0.41, 0.415, 0.42, 0.43, 0.44,
                         0.44, 0.45, 0.455, 0.46, 0.47, 0.48, 
                         0.47, 0.10, 0.098, 0.1, 0.15, 0.19, 
                         0.30, 0.35, 0.370, 0.4, 0.40, 0.42 } ; 
      double cdspr[]  = {270., 110., 54., 51., 40., 35., 28.,
                         15., 8.5, 7.5, 6.0, 5.4, 4.9,
                         3.1, 1.9, 1.8, 1.5, 1.3, 1.1,
                         0.81, 0.6, 0.58, 0.56, 0.5, 0.49, 
                         0.40, 0.41, 0.415, 0.42, 0.43, 0.44,
                         0.44, 0.45, 0.455, 0.46, 0.42, 0.15, 
                         0.27, 0.33, 0.35, 0.37, 0.38, 0.39, 
                         0.40, 0.41, 0.41, 0.42, 0.43, 0.44 } ; 
      double cdspg[]  = {270., 110., 54., 51., 40., 35., 28.,
                         15., 8.5, 7.5, 6.0, 5.4, 4.9,
                         3.1, 1.9, 1.8, 1.5, 1.3, 1.1,
                         0.81, 0.6, 0.58, 0.56, 0.5, 0.49, 
                         0.40, 0.41, 0.415, 0.42, 0.43, 0.44,
                         0.44, 0.28, 0.255, 0.24, 0.24, 0.25, 
                         0.26, 0.27, 0.290, 0.33, 0.37, 0.40, 
                         0.41, 0.42, 0.420, 0.43, 0.44, 0.45 } ; 
      if (stall_model_type == STALL_MODEL_IDEAL_FLOW) {
        dragco = 0;
      } else {
          switch (foil)
            {
            case FOIL_JOUKOWSKI:    //airfoil drag logic
              {
                //switch (in.anl.foil_drag_comp_method) {
                //case DRAG_COMP_POLY_FOILSIMORIG: {
                // thickness 5%
                dragCam0Thk5 = -9E-07*Math.pow(effaoa,3) + 0.0007*Math.pow(effaoa,2) + 0.0008*effaoa + 0.015;
                dragCam5Thk5 = 4E-08*Math.pow(effaoa,5) - 7E-07*Math.pow(effaoa,4) - 1E-05*Math.pow(effaoa,3) + 0.0009*Math.pow(effaoa,2) + 0.0033*effaoa + 0.0301;
                dragCam10Thk5 = -9E-09*Math.pow(effaoa,6) - 6E-08*Math.pow(effaoa,5) + 5E-06*Math.pow(effaoa,4) + 3E-05*Math.pow(effaoa,3) - 0.0001*Math.pow(effaoa,2) - 0.0025*effaoa + 0.0615;
                dragCam15Thk5 = 8E-10*Math.pow(effaoa,6) - 5E-08*Math.pow(effaoa,5) - 1E-06*Math.pow(effaoa,4) + 3E-05*Math.pow(effaoa,3) + 0.0008*Math.pow(effaoa,2) - 0.0027*effaoa + 0.0612;
                dragCam20Thk5 = 8E-9*Math.pow(effaoa,6) + 1E-8*Math.pow(effaoa,5) - 5E-6*Math.pow(effaoa,4) + 6E-6*Math.pow(effaoa,3) + 0.001*Math.pow(effaoa,2) - 0.001*effaoa + 0.1219;

                // thickness 10%
                dragCam0Thk10 = -1E-08*Math.pow(effaoa,6) + 6E-08*Math.pow(effaoa,5) + 6E-06*Math.pow(effaoa,4) - 2E-05*Math.pow(effaoa,3) - 0.0002*Math.pow(effaoa,2) + 0.0017*effaoa + 0.0196;
                dragCam5Thk10 = 3E-09*Math.pow(effaoa,6) + 6E-08*Math.pow(effaoa,5) - 2E-06*Math.pow(effaoa,4) - 3E-05*Math.pow(effaoa,3) + 0.0008*Math.pow(effaoa,2) + 0.0038*effaoa + 0.0159;
                dragCam10Thk10 = -5E-09*Math.pow(effaoa,6) - 3E-08*Math.pow(effaoa,5) + 2E-06*Math.pow(effaoa,4) + 1E-05*Math.pow(effaoa,3) + 0.0004*Math.pow(effaoa,2) - 3E-05*effaoa + 0.0624;
                dragCam15Thk10 = -2E-09*Math.pow(effaoa,6) - 2E-08*Math.pow(effaoa,5) - 5E-07*Math.pow(effaoa,4) + 8E-06*Math.pow(effaoa,3) + 0.0009*Math.pow(effaoa,2) + 0.0034*effaoa + 0.0993;
                dragCam20Thk10 = 2E-09*Math.pow(effaoa,6) - 3E-08*Math.pow(effaoa,5) - 2E-06*Math.pow(effaoa,4) + 2E-05*Math.pow(effaoa,3) + 0.0009*Math.pow(effaoa,2) + 0.0023*effaoa + 0.1581;

                // thickness 15%
                dragCam0Thk15 = -5E-09*Math.pow(effaoa,6) + 7E-08*Math.pow(effaoa,5) + 3E-06*Math.pow(effaoa,4) - 3E-05*Math.pow(effaoa,3) - 7E-05*Math.pow(effaoa,2) + 0.0017*effaoa + 0.0358;
                dragCam5Thk15 = -4E-09*Math.pow(effaoa,6) - 8E-09*Math.pow(effaoa,5) + 2E-06*Math.pow(effaoa,4) - 9E-07*Math.pow(effaoa,3) + 0.0002*Math.pow(effaoa,2) + 0.0031*effaoa + 0.0351;
                dragCam10Thk15 = 3E-09*Math.pow(effaoa,6) + 3E-08*Math.pow(effaoa,5) - 2E-06*Math.pow(effaoa,4) - 1E-05*Math.pow(effaoa,3) + 0.0009*Math.pow(effaoa,2) + 0.004*effaoa + 0.0543;
                dragCam15Thk15 = 3E-09*Math.pow(effaoa,6) + 5E-08*Math.pow(effaoa,5) - 2E-06*Math.pow(effaoa,4) - 3E-05*Math.pow(effaoa,3) + 0.0008*Math.pow(effaoa,2) + 0.0087*effaoa + 0.1167;
                dragCam20Thk15 = 3E-10*Math.pow(effaoa,6) - 3E-08*Math.pow(effaoa,5) - 6E-07*Math.pow(effaoa,4) + 3E-05*Math.pow(effaoa,3) + 0.0006*Math.pow(effaoa,2) + 0.0008*effaoa + 0.1859;

                // thickness 20%
                dragCam0Thk20 = -3E-09*Math.pow(effaoa,6) + 2E-08*Math.pow(effaoa,5) + 2E-06*Math.pow(effaoa,4) - 8E-06*Math.pow(effaoa,3) - 4E-05*Math.pow(effaoa,2) + 0.0003*effaoa + 0.0416;
                dragCam5Thk20 = -3E-09*Math.pow(effaoa,6) - 7E-08*Math.pow(effaoa,5) + 1E-06*Math.pow(effaoa,4) + 3E-05*Math.pow(effaoa,3) + 0.0004*Math.pow(effaoa,2) + 5E-05*effaoa + 0.0483;
                dragCam10Thk20 = 1E-08*Math.pow(effaoa,6) + 4E-08*Math.pow(effaoa,5) - 6E-06*Math.pow(effaoa,4) - 2E-05*Math.pow(effaoa,3) + 0.0014*Math.pow(effaoa,2) + 0.007*effaoa + 0.0692;
                dragCam15Thk20 = 3E-09*Math.pow(effaoa,6) - 9E-08*Math.pow(effaoa,5) - 3E-06*Math.pow(effaoa,4) + 4E-05*Math.pow(effaoa,3) + 0.001*Math.pow(effaoa,2) + 0.0021*effaoa + 0.139;
                dragCam20Thk20 = 3E-09*Math.pow(effaoa,6) - 7E-08*Math.pow(effaoa,5) - 3E-06*Math.pow(effaoa,4) + 4E-05*Math.pow(effaoa,3) + 0.0012*Math.pow(effaoa,2) + 0.001*effaoa + 0.1856;

                if (-20.0 <= camber && camber < -15.0)
                  {
                    dragThk5 = (camber/5 + 4)*(dragCam15Thk5 - dragCam20Thk5) + dragCam20Thk5;
                    dragThk10 = (camber/5 + 4)*(dragCam15Thk10 - dragCam20Thk10) + dragCam20Thk10;
                    dragThk15 = (camber/5 + 4)*(dragCam15Thk15 - dragCam20Thk15) + dragCam20Thk15;
                    dragThk20 = (camber/5 + 4)*(dragCam15Thk20 - dragCam20Thk20) + dragCam20Thk20;
                    
                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      { // dragco = two_pt(5.0, 10.0, dragThk5, dragThk10)
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 15.0)
                      {
                        dragco = (thickness/5 - 2)*(dragThk15 - dragThk10) + dragThk10;
                      }
                    else if (15.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/5 - 3)*(dragThk20 - dragThk15) + dragThk15;
                      }
                  }
                else if (-15.0 <= camber && camber < -10.0)
                  {
                    dragThk5 = (camber/5 + 3)*(dragCam10Thk5 - dragCam15Thk5) + dragCam15Thk5;
                    dragThk10 = (camber/5 + 3)*(dragCam10Thk10 - dragCam15Thk10) + dragCam15Thk10;
                    dragThk15 = (camber/5 + 3)*(dragCam10Thk15 - dragCam15Thk15) + dragCam15Thk15;
                    dragThk20 = (camber/5 + 3)*(dragCam10Thk20 - dragCam15Thk20) + dragCam15Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 15.0)
                      {
                        dragco = (thickness/5 - 2)*(dragThk15 - dragThk10) + dragThk10;
                      }
                    else if (15.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/5 - 3)*(dragThk20 - dragThk15) + dragThk15;
                      }
                  }
                else if (-10.0 <= camber && camber < -5.0)
                  {
                    dragThk5 = (camber/5 + 2)*(dragCam5Thk5 - dragCam10Thk5) + dragCam10Thk5;
                    dragThk10 = (camber/5 + 2)*(dragCam5Thk10 - dragCam10Thk10) + dragCam10Thk10;
                    dragThk15 = (camber/5 + 2)*(dragCam5Thk15 - dragCam10Thk15) + dragCam10Thk15;
                    dragThk20 = (camber/5 + 2)*(dragCam5Thk20 - dragCam10Thk20) + dragCam10Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 15.0)
                      {
                        dragco = (thickness/5 - 2)*(dragThk15 - dragThk10) + dragThk10;
                      }
                    else if (15.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/5 - 3)*(dragThk20 - dragThk15) + dragThk15;
                      }
                  }
                else if (-5.0 <= camber && camber < 0)
                  {
                    dragThk5 = (camber/5 + 1)*(dragCam0Thk5 - dragCam5Thk5) + dragCam5Thk5;
                    dragThk10 = (camber/5 + 1)*(dragCam0Thk10 - dragCam5Thk10) + dragCam5Thk10;
                    dragThk15 = (camber/5 + 1)*(dragCam0Thk15 - dragCam5Thk15) + dragCam5Thk15;
                    dragThk20 = (camber/5 + 1)*(dragCam0Thk20 - dragCam5Thk20) + dragCam5Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 15.0)
                      {
                        dragco = (thickness/5 - 2)*(dragThk15 - dragThk10) + dragThk10;
                      }
                    else if (15.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/5 - 3)*(dragThk20 - dragThk15) + dragThk15;
                      }
                  }
                else if (0 <= camber && camber < 5)
                  {
                    dragThk5 = (camber/5)*(dragCam5Thk5 - dragCam0Thk5) + dragCam0Thk5;
                    dragThk10 = (camber/5)*(dragCam5Thk10 - dragCam0Thk10) + dragCam0Thk10;
                    dragThk15 = (camber/5)*(dragCam5Thk15 - dragCam0Thk15) + dragCam0Thk15;
                    dragThk20 = (camber/5)*(dragCam5Thk20 - dragCam0Thk20) + dragCam0Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 15.0)
                      {
                        dragco = (thickness/5 - 2)*(dragThk15 - dragThk10) + dragThk10;
                      }
                    else if (15.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/5 - 3)*(dragThk20 - dragThk15) + dragThk15;
                      }
                  }
                else if (5 <= camber && camber < 10)
                  {
                    dragThk5 = (camber/5 - 1)*(dragCam10Thk5 - dragCam5Thk5) + dragCam5Thk5;
                    dragThk10 = (camber/5 - 1)*(dragCam10Thk10 - dragCam5Thk10) + dragCam5Thk10;
                    dragThk15 = (camber/5 - 1)*(dragCam10Thk15 - dragCam5Thk15) + dragCam5Thk15;
                    dragThk20 = (camber/5 - 1)*(dragCam10Thk20 - dragCam5Thk20) + dragCam5Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 15.0)
                      {
                        dragco = (thickness/5 - 2)*(dragThk15 - dragThk10) + dragThk10;
                      }
                    else if (15.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/5 - 3)*(dragThk20 - dragThk15) + dragThk15;
                      }
                  }
                else if (10 <= camber && camber < 15)
                  {
                    dragThk5 = (camber/5 - 2)*(dragCam15Thk5 - dragCam10Thk5) + dragCam10Thk5;
                    dragThk10 = (camber/5 - 2)*(dragCam15Thk10 - dragCam10Thk10) + dragCam10Thk10;
                    dragThk15 = (camber/5 - 2)*(dragCam15Thk15 - dragCam10Thk15) + dragCam10Thk15;
                    dragThk20 = (camber/5 - 2)*(dragCam15Thk20 - dragCam10Thk20) + dragCam10Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 15.0)
                      {
                        dragco = (thickness/5 - 2)*(dragThk15 - dragThk10) + dragThk10;
                      }
                    else if (15.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/5 - 3)*(dragThk20 - dragThk15) + dragThk15;
                      }
                  }
                else if (15 <= camber && camber <= 20)
                  {
                    dragThk5 = (camber/5 - 3)*(dragCam20Thk5 - dragCam15Thk5) + dragCam15Thk5;
                    dragThk10 = (camber/5 - 3)*(dragCam20Thk10 - dragCam15Thk10) + dragCam15Thk10;
                    dragThk15 = (camber/5 - 3)*(dragCam20Thk15 - dragCam15Thk15) + dragCam15Thk15;
                    dragThk20 = (camber/5 - 3)*(dragCam20Thk20 - dragCam15Thk20) + dragCam15Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 15.0)
                      {
                        dragco = (thickness/5 - 2)*(dragThk15 - dragThk10) + dragThk10;
                      }
                    else if (15.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/5 - 3)*(dragThk20 - dragThk15) + dragThk15;
                      }
                  }
              }
              // break;
              // case DRAG_COMP_AQUILA_9P3:  break;
              // case DRAG_COMP_NACA4SERIES:  break;
              // default: break;
              // }
              break; // FOIL_JOUKOWSKI
            case FOIL_NACA4:
              reynolds_correction_fixpt = 300000;
              dragco = ci15_from_javafoil_data(t_drag_NACA4, effaoa, thickness, camber);
              break; // FOIL_NACA4
            case FOIL_NACA_64_814:
              reynolds_correction_fixpt = 300000;
              dragco = ci25(t_drag_NACA_64_814_teg05, effaoa);
              break;
            case FOIL_AQUILA_9P3:
                reynolds_correction_fixpt = 300000;
                dragco = ci15(t_drag_AQUILA_9p3, effaoa);
                break;
            case FOIL_NACA_63_412:
                reynolds_correction_fixpt = 300000;
                dragco = ci15(t_drag_NACA_63_412, effaoa);
                break;
            case FOIL_BLADERIDER_V1:
                reynolds_correction_fixpt = 300000;
                dragco = ci15(t_drag_NACA_63_412_mod_flap_v1, effaoa);
                break;
            case FOIL_ELLIPTICAL:   //elliptical drag logic
              {
                dragCam0Thk5 = -6E-07*Math.pow(effaoa,3) + 0.0007*Math.pow(effaoa,2) + 0.0007*effaoa + 0.0428;
                dragCam10Thk5 = 5E-09*Math.pow(effaoa,6) - 7E-08*Math.pow(effaoa,5) - 3E-06*Math.pow(effaoa,4) + 5E-05*Math.pow(effaoa,3) + 0.0009*Math.pow(effaoa,2) - 0.0058*effaoa + 0.0758;
                dragCam20Thk5 = 1E-08*Math.pow(effaoa,6) - 2E-08*Math.pow(effaoa,5) - 7E-06*Math.pow(effaoa,4) + 1E-05*Math.pow(effaoa,3) + 0.0015*Math.pow(effaoa,2) + 0.0007*effaoa + 0.1594;
                    
                dragCam0Thk10 = 3E-09*Math.pow(effaoa,6) + 4E-08*Math.pow(effaoa,5) - 3E-06*Math.pow(effaoa,4) - 9E-06*Math.pow(effaoa,3) + 0.0013*Math.pow(effaoa,2) + 0.0007*effaoa + 0.0112;
                dragCam10Thk10 = -4E-09*Math.pow(effaoa,6) - 9E-08*Math.pow(effaoa,5) + 2E-06*Math.pow(effaoa,4) + 7E-05*Math.pow(effaoa,3) + 0.0008*Math.pow(effaoa,2) - 0.0095*effaoa + 0.0657;
                dragCam20Thk10 = -8E-09*Math.pow(effaoa,6) - 9E-08*Math.pow(effaoa,5) + 3E-06*Math.pow(effaoa,4) + 6E-05*Math.pow(effaoa,3) + 0.0005*Math.pow(effaoa,2) - 0.0088*effaoa + 0.2088;

                dragCam0Thk20 = -7E-09*Math.pow(effaoa,6) - 1E-07*Math.pow(effaoa,5) + 4E-06*Math.pow(effaoa,4) + 6E-05*Math.pow(effaoa,3) + 0.0001*Math.pow(effaoa,2) - 0.0087*effaoa + 0.0596;
                dragCam10Thk20 = -2E-09*Math.pow(effaoa,6) + 2E-07*Math.pow(effaoa,5) + 1E-06*Math.pow(effaoa,4) - 6E-05*Math.pow(effaoa,3) + 0.0004*Math.pow(effaoa,2) - 7E-05*effaoa + 0.1114;
                dragCam20Thk20 = 4E-09*Math.pow(effaoa,6) - 7E-08*Math.pow(effaoa,5) - 3E-06*Math.pow(effaoa,4) + 3E-05*Math.pow(effaoa,3) + 0.001*Math.pow(effaoa,2) - 0.0018*effaoa + 0.1925;

                if (-20.0 <= camber && camber < -10.0)
                  {
                    dragThk5 = (camber/10 + 2)*(dragCam10Thk5 - dragCam20Thk5) + dragCam20Thk5;
                    dragThk10 = (camber/10 + 2)*(dragCam10Thk10 - dragCam20Thk10) + dragCam20Thk10;
                    dragThk20 = (camber/10 + 2)*(dragCam10Thk20 - dragCam20Thk20) + dragCam20Thk20;
                    
                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/10 - 1)*(dragThk20 - dragThk10) + dragThk10;
                      }
                  }
                else if (-10.0 <= camber && camber < 0)
                  {
                    dragThk5 = (camber/10 + 1)*(dragCam0Thk5 - dragCam10Thk5) + dragCam10Thk5;
                    dragThk10 = (camber/10 + 1)*(dragCam0Thk10 - dragCam10Thk10) + dragCam10Thk10;
                    dragThk20 = (camber/10 + 1)*(dragCam0Thk20 - dragCam10Thk20) + dragCam10Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/10 - 1)*(dragThk20 - dragThk10) + dragThk10;
                      }
                  }
                else if (0 <= camber && camber < 10)
                  {
                    dragThk5 = (camber/10)*(dragCam10Thk5 - dragCam0Thk5) + dragCam0Thk5;
                    dragThk10 = (camber/10)*(dragCam10Thk10 - dragCam0Thk10) + dragCam0Thk10;
                    dragThk20 = (camber/10)*(dragCam10Thk20 - dragCam0Thk20) + dragCam0Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/10 - 1)*(dragThk20 - dragThk10) + dragThk10;
                      }
                  }
                else if (10 <= camber && camber < 20)
                  {
                    dragThk5 = (camber/10 - 1)*(dragCam20Thk5 - dragCam10Thk5) + dragCam10Thk5;
                    dragThk10 = (camber/10 - 1)*(dragCam20Thk10 - dragCam10Thk10) + dragCam10Thk10;
                    dragThk20 = (camber/10 - 1)*(dragCam20Thk20 - dragCam10Thk20) + dragCam10Thk20;

                    if (1.0 <= thickness && thickness <= 5.0)
                      {
                        dragco = dragThk5;
                      }
                    else if (5.0 < thickness && thickness <= 10.0)
                      {
                        dragco = (thickness/5 - 1)*(dragThk10 - dragThk5) + dragThk5;
                      }
                    else if (10.0 < thickness && thickness <= 20.0)
                      {
                        dragco = (thickness/10 - 1)*(dragThk20 - dragThk10) + dragThk10;
                      }
                  }

                break;
              } // end of FOIL_ELLIPTICAL
            case FOIL_FLAT_PLATE:    //flat plate drag logic
              {
                dragCam0 = -9E-07*Math.pow(effaoa,3) + 0.0007*Math.pow(effaoa,2) + 0.0008*effaoa + 0.015;
                dragCam5 = 1E-08*Math.pow(effaoa,6) + 4E-08*Math.pow(effaoa,5) - 9E-06*Math.pow(effaoa,4) - 1E-05*Math.pow(effaoa,3) + 0.0021*Math.pow(effaoa,2) + 0.0033*effaoa + 0.006;
                dragCam10 = -9E-09*Math.pow(effaoa,6) - 6E-08*Math.pow(effaoa,5) + 5E-06*Math.pow(effaoa,4) + 3E-05*Math.pow(effaoa,3) - 0.0001*Math.pow(effaoa,2) - 0.0025*effaoa + 0.0615;
                dragCam15 = 8E-10*Math.pow(effaoa,6) - 5E-08*Math.pow(effaoa,5) - 1E-06*Math.pow(effaoa,4) + 3E-05*Math.pow(effaoa,3) + 0.0008*Math.pow(effaoa,2) - 0.0027*effaoa + 0.0612;
                dragCam20 = 8E-9*Math.pow(effaoa,6) + 1E-8*Math.pow(effaoa,5) - 5E-6*Math.pow(effaoa,4) + 6E-6*Math.pow(effaoa,3) + 0.001*Math.pow(effaoa,2) - 0.001*effaoa + 0.1219;

                if (-20.0 <= camber && camber < -15.0)
                  {
                    dragco = (camber/5 + 4)*(dragCam15 - dragCam20) + dragCam20;
                  }
                else if (-15.0 <= camber && camber < -10.0)
                  {
                    dragco = (camber/5 + 3)*(dragCam10 - dragCam15) + dragCam15;
                  }
                else if (-10.0 <= camber && camber < -5.0)
                  {
                    dragco = (camber/5 + 2)*(dragCam5 - dragCam10) + dragCam10;
                  }
                else if (-5.0 <= camber && camber < 0)
                  {
                    dragco = (camber/5 + 1)*(dragCam0 - dragCam5) + dragCam5;
                  }
                else if (0 <= camber && camber < 5)
                  {
                    dragco = (camber/5)*(dragCam5 - dragCam0) + dragCam0;
                  }
                else if (5 <= camber && camber < 10)
                  {
                    dragco = (camber/5 - 1)*(dragCam10 - dragCam5) + dragCam5;
                  }
                else if (10 <= camber && camber < 15)
                  {
                    dragco = (camber/5 - 2)*(dragCam15 - dragCam10) + dragCam10;
                  }
                else if (15 <= camber && camber <= 20)
                  {
                    dragco = (camber/5 - 3)*(dragCam20 - dragCam15) + dragCam15;
                  }
                break;
              } // end of FOIL_FLAT_PLATE
            case FOIL_CYLINDER:   //cylinder drag logic
              {
                ifound = 0 ;
                for (index = 0; index <= 43 ; ++ index) {
                  if(reynolds >= recyl[index] && reynolds < recyl[index+1]) ifound = index;
                }

                dragco = ((cdcyl[ifound+1]-cdcyl[ifound])/(recyl[ifound+1]-recyl[ifound]))*
                  (reynolds - recyl[ifound]) + cdcyl[ifound];

                break;
              }
            case FOIL_BALL:   //sphere drag logic
              {
                ifound = 0 ;
                for (index = 0; index <= 48 ; ++ index) {
                  if(reynolds >= resps[index] && reynolds < resps[index+1]) ifound = index;
                }
                    
                if ( bdragflag == 1) {    // smooth ball
                  dragco = ((cdsps[ifound+1]-cdsps[ifound])/(resps[ifound+1]-resps[ifound]))*
                    (reynolds - resps[ifound]) + cdsps[ifound];
                }
                if ( bdragflag == 2) {    // rough ball
                  dragco = ((cdspr[ifound+1]-cdspr[ifound])/(resps[ifound+1]-resps[ifound]))*
                    (reynolds - resps[ifound]) + cdspr[ifound];
                }
                if ( bdragflag == 3) {    // golf ball
                  dragco = ((cdspg[ifound+1]-cdspg[ifound])/(resps[ifound+1]-resps[ifound]))*
                    (reynolds - resps[ifound]) + cdspg[ifound];
                }

                break;
              }
            default:;
            }

          if(recor == 1) {    // reynolds correction
            if (!foil_is_cylinder_or_ball(foil)) {       // airfoil 
              dragco = dragco * Math.pow((reynolds_correction_fixpt/reynolds),.11) ;
            }
          }

          if (indrag == 1) {    // induced drag coefficient  factor = .85 for rectangle
            dragco = dragco + (cldin * cldin)/ (3.1415926 * aspr * .85) ;
          }
        }
    }
  } // end Solver

  class Part {
    /**/ String name; int foil; double xpos; double chord; double span; double thickness_pst; double camber; double aoa;
    Part(String name, int foil, double xpos, double chord, double span, double thickness_pst, double camber, double aoa) {
      this.name = name;
      this.foil = foil;
      this.xpos = xpos;
      this.chord = chord;
      this.span = span;
      this.thickness_pst = thickness_pst;
      this.camber = camber;
      this.aoa = aoa;
    }

    void save_state() {
      // check data integrity
      if (false) { // if (DEBUG) {
        double thickness = thkinpt;
        if (thickness/25 != thkval) {
          System.out.println("-- attention: thickness/35 != thkval. thickness: " + thickness + " thkval: " + thkval);
        }
        if (thkd != thkinpt) {
          System.out.println("-- attention: thkd != thkinpt. thkd: " + thkd + " thkinpt: " + thkinpt);
        }
      }

      // Part state is always metric
      double conv = (lunits == METRIC) ? 1.0 : LEN_FT2M;
      
      //System.out.println(this.name + ": " + "foil  was: " + this.foil     + " new: " +  FoilBoardWithProblems.this.foil);
      System.out.println(this.name + ": " + "chord was: " + this.chord    + " new: " +  conv * FoilBoardWithProblems.this.chord);
      System.out.println(this.name + ": " + "span  was: " + this.span     + " new: " +  conv * FoilBoardWithProblems.this.span);
      System.out.println(this.name + ": " + "thick was: " + this.thickness_pst+ " new: " +  FoilBoardWithProblems.this.thkinpt);
      System.out.println(this.name + ": " + "cambe was: " + this.camber   + " new: " +  FoilBoardWithProblems.this.camval * 25);
      
      new Exception(this.name).printStackTrace(System.out);
      
      this.foil       = FoilBoardWithProblems.this.foil;
      
      this.chord      = conv * FoilBoardWithProblems.this.chord;
      this.span       = conv * FoilBoardWithProblems.this.span;
      
      this.thickness_pst  = FoilBoardWithProblems.this.thkinpt;
      
      this.camber     = FoilBoardWithProblems.this.camval * 25;
      this.aoa        = FoilBoardWithProblems.this.alpha_degr;
      this.lift       = FoilBoardWithProblems.this.lift;
      this.drag       = FoilBoardWithProblems.this.drag;
      this.t_Cl = cache_t_Cl;
      this.t_Cd = cache_t_Cd;
      
    }
    /*cache*/
    double lift; double drag;
    double[] t_Cd, t_Cl; // when this.foil, this.camber or this.thickness change, recompute!

    String foil_descr() {
      if (foil == FOIL_NACA4) {
        String thickness_str = ""+Math.round(this.thickness_pst);
        if (thickness_str.length() < 2) thickness_str = "0" + thickness_str;
        return "NACA" + (Math.round(Math.abs(camber))) + "4" + thickness_str;
      } else
        return FoilBoardWithProblems.foil_descr(foil);
    }

    void print(String header, TextArea ta_out) {
      if (header != null) {
        ta_out.append("\n\n *** " + header + " ***");
      }

      switch (foil) {
      case FOIL_JOUKOWSKI:
        ta_out.append( "\n Joukowski Airfoil" ) ;
        break ;
      case FOIL_NACA4:
        ta_out.append( "\n NACA 4 series Airfoil" ) ;
        break ;
      case FOIL_NACA_64_814:
        ta_out.append( "\n NACA 64-814" ) ;
        ta_out.append(" " + foil_descr()) ;
        break ;
      case FOIL_AQUILA_9P3:
        ta_out.append( "\n Aquila 9.3% Airfoil" ) ;
        break ;
      case FOIL_NACA_63_412:
        ta_out.append( "\n NACA 63-412 FoilBoardWithProblems" ) ;
        break ;
      case FOIL_BLADERIDER_V1:
        ta_out.append( "\n Bladerider, modded NACA 63-412 FoilBoardWithProblems" ) ;
        break ;
      case FOIL_ELLIPTICAL: {        
        ta_out.append( "\n Elliptical Airfoil" ) ;
        break ;
      }
      case FOIL_FLAT_PLATE: {     
        ta_out.append( "\n Plate" ) ;
        break ;
      }
      case FOIL_CYLINDER: {     
        ta_out.append( "\n Rotating Cylinder" ) ;
        break ;
      }
      case FOIL_BALL: {     
        ta_out.append( "\n Spinning Ball" ) ;
        break ;
      }
      }
      if (!foil_is_cylinder_or_ball(foil)) {
        if (lunits == IMPERIAL) {
          ta_out.append( "\n Chord = " + filter3(chord*12) + " inches.") ;
          ta_out.append( "\n Span = " + filter3(span*12) + " inches.") ;
          ta_out.append( "\n Surface Area = " + filter3(span*chord*144) + " sq inches.") ;
          ta_out.append( "\n Thickness = " + filter3(0.01 * thickness_pst * chord * 12) + " inches") ;
          ta_out.append( " or " + filter3(thickness_pst) + " % of chord ," ) ;
          ta_out.append( "\n Camber = " + filter3(camber) + " % chord ," ) ;
          ta_out.append( "\n Angle of attack = " + filter3(aoa) + " degrees ," ) ;
        } else {
          ta_out.append( "\n Chord = " + filter3(chord*100) + " cm.") ;
          ta_out.append( "\n Span = " + filter3(span*100) + " cm.") ;
          ta_out.append( "\n Surface Area = " + filter3(span*chord*100*100) + " sq cm.") ;
          ta_out.append( "\n Thickness = " + filter3(0.01 * thickness_pst * chord * 100) + " cm") ;
          ta_out.append( " or " + filter3(thickness_pst) + " % of chord ," ) ;
          ta_out.append( "\n Camber = " + filter3(camber) + " % chord ," ) ;
          ta_out.append( "\n  Angle of attack = " + filter3(aoa) + " degrees ," ) ;
        }
      } else { // cylinder or ball
        // ta_out.append( "\n Spin  = " + filter3(spin*60.0) ) ;
        // ta_out.append( " rpm ," ) ;
        // ta_out.append( " Radius = " + filter3(radius) ) ;
        // if (lunits == IMPERIAL) ta_out.append( " ft ," ) ;
        // else /*METRIC*/         ta_out.append( " m ," ) ;
        ta_out.append( "\n Span = " + filter3(span) ) ;
        if (lunits == IMPERIAL) ta_out.append( " ft." ) ;
        else /*METRIC*/          ta_out.append( " m." ) ;
      }

    }
  }

  class VPP {     // Velocity Prediction Procedures aka VPP
    boolean trace;
    void trace(String msg) {
      if (trace) System.out.println("--   " + msg);
    }

    void find_aoa_of_min_drag_slow() {
      // preamble: make sure inputs are in
      loadInput();
      con.recomp_all_parts();

      double min_drag = total_drag();
      double min_drag_aoa = craft_pitch;
      for (double p = ang_mn/2; p < ang_mx; p += 0.1) {
        craft_pitch = p;
        loadInput();
        con.recomp_all_parts();
        if (total_drag() < min_drag)
          min_drag_aoa = craft_pitch;
      }
      craft_pitch = min_drag_aoa;
      loadInput();
      con.recomp_all_parts();
    }

    // pivoting algorithm
    void find_aoa_of_min_drag() {
      // preamble: make sure inputs are in
      loadInput();
      con.recomp_all_parts();

      double min_drag = total_drag();
      double min_drag_aoa = craft_pitch;
      double step = 0.5;
      double prev_drag = min_drag;
      double p = Math.min(min_drag_aoa + step, ang_mx - 4*step);
      while (p < ang_mx && p > ang_mn) {
        craft_pitch = p;
        loadInput();
        con.recomp_all_parts();
        double drag = total_drag();
        if (drag > prev_drag) { // pivot
          // do not! p -= step; // go back 1 'old' step 
          step = -step/2; // shrink step
          if (Math.abs(step) < 0.05) break;
        } else if (drag < min_drag) {
          min_drag_aoa = craft_pitch;
        }
        prev_drag = drag;
        p += step;
      }
      craft_pitch = min_drag_aoa;
      loadInput();
      con.recomp_all_parts();
    }

    void find_min_takeoff_v(double min_lift, double max_drag) {
      double saved_speed = velocity;
      // steap one. guess a reasonable starting speed to iterate
      // by setting pitch to 10 and finding speed at enough lift,
      double speed = 5;
      double pitch = 10;
      for (; speed < v_mx; speed += 1) {
        velocity = speed;
        craft_pitch = pitch;
        loadInput();
        con.recomp_all_parts();
        if (total_lift() >= min_lift) 
          break;
      }

      pitch = 0;
      double speed_step = 2, pitch_step = 0.25;
      while(0 < (speed=find_min_takeoff_v_aux(min_lift, max_drag, speed, speed_step, pitch, pitch_step))) {
        pitch = craft_pitch - Math.abs(craft_pitch/3);
        speed_step /=2;
        pitch_step /=2;
      }
      if (speed == -2) {
        System.out.println("Can not takeoff with such small drag requirement, increase it.");
        velocity = saved_speed;
        loadInput();
        con.recomp_all_parts();
      }
    }

    // returns negative speed when done or failed to satisfy the constraints
    // otherwise returns speed to re-iterate from.
    double find_min_takeoff_v_aux(double min_lift, double max_drag, double speed, double speed_step, double pitch_init, double pitch_step) {
      double pitch = pitch_init;
      double pitch_limit = ang_mx*0.7;
      {
        // trace("speed_step: " + speed_step + " pitch_step: " + pitch_step);
        for (; speed < v_mx; speed += speed_step) {
          velocity = speed;
          // if the startimg pitch guess when at this point was too high, 
          // drag will be too big at this point; then reduce pitch
          while (pitch > ang_mn/2) {
            craft_pitch = pitch;
            loadInput();
            con.recomp_all_parts();
            if (total_drag() >= max_drag)
              pitch = Math.max(pitch_init, craft_pitch - Math.abs(craft_pitch/4));
            else 
              break; // while (pitch > ang_mn/2)
          }              
              
          trace("for() speed: " + speed + " pitch: " + pitch);
          for (;pitch < pitch_limit; pitch += pitch_step) {
            craft_pitch = pitch;
            loadInput();
            con.recomp_all_parts();
            if (total_drag() >= max_drag) {
              // stop increasing pitch, won't work. need more speed
              trace("to much drag. speed: " + speed + " pitch: " + pitch + " lift " + total_lift());
              pitch = Math.max(pitch_init, craft_pitch - Math.abs(craft_pitch/4));
              break; // for (pitch...)
            }
            if (total_lift() >= min_lift) {
              if (speed_step > 0.25) {
                trace("request reiterate. speed: " + speed + " pitch: " + pitch + " lift " + total_lift() + " speed_step: " + speed_step);
                return Math.max(0, velocity - speed_step); // request to reiterate
              } else {
                // done!
                make_min_takeoff_speed_info(min_lift, max_drag, velocity); 
                System.out.println("\nDone!\n----------------\n" + min_takeoff_speed_info);
                return -1;
              }
            } 
          }
          // need to start from lowest pitch?
          if (pitch >= pitch_limit) pitch = pitch_init;
        }
      }
      return -2; // can not find solution
    }



    // start speed must be >= than takeoff spped
    void easy_ride(double min_lift, double start_speed) {      
      double pitch = 0;
      double min_drag = 10000.0;
      double min_drag_speed = -1;
      for (double speed = start_speed; speed < v_mx; speed += 0.5) {
        velocity = speed;
        for (pitch = 0; pitch <= ang_mx; pitch += 0.1) {
          craft_pitch = pitch;
          loadInput();
          con.recomp_all_parts();
          // if (total_drag() >= max_drag) {
          //   trace("warning speed: " + speed + " pitch: " + pitch + " lift " + total_lift());
          //   return;
          // }
          if (total_lift() >= min_lift) {
            double drag = total_drag();
            if (min_drag > drag) {
              min_drag = drag;
              min_drag_speed = velocity;
              break;
            } else {
              // drag goes up now. can be done now, but
              // as a heuristic, now try from the upepr limit, and then find range:
              max_speed(min_lift, min_drag + 2, false);
              if (velocity < min_drag_speed) {
                // something went wrong (iteration stepped over the sweets spot etc)
                // so we take min_lift, min_drag, amd min_drag_speed  as is
                make_cruising_info(min_lift, min_drag, min_drag_speed); 
                System.out.println("\nDone!\n----------------\n" + cruising_info);
              } else {
              // done, report with average of min_drag_speed and velocity
                make_cruising_info(min_lift, min_drag+1, (min_drag_speed+velocity)/2); 
                trace("done with refinement! ");
                System.out.println("\nDone!\n----------------\n" + cruising_info);
              }
              return;
            }
          }
        }
      }
    }


    void max_speed_slow(double min_lift, double max_drag, double v_start, double v_step, double pitch_start, double pitch_step) {
      double speed = v_start;
      double pitch;
      for (; speed >= 0; speed += v_step) {
        velocity = speed;
        for (pitch = pitch_start; pitch <= ang_mx; pitch += pitch_step) {
          craft_pitch = pitch;
          loadInput();
          con.recomp_all_parts();
          if (total_lift() >= min_lift) {
            // reached lift, what is the drag?
            if (total_drag() >= max_drag) {
              // stop increasing pitch, won't work. likely need less speed
              trace("speed: " + speed + " pitch: " + pitch);
              break;
            }
            make_max_speed_info(min_lift, max_drag, velocity);
            trace("done " + max_speed_info);
            return;
          }
        }
      }
    }

    void max_speed(double min_lift, double max_drag, boolean update_info) {
      // step 1: find lowest drag pitch at v=20kts
      velocity = kts_to_speed(20);
      find_aoa_of_min_drag();
      double pitch_of_min_drag = craft_pitch;
      trace("pitch_of_min_drag: " + pitch_of_min_drag);

      // step 2. with current (lowest drag) pitch, iterate speed up
      // until drag exceeds max_drag.
      double speed =  (total_drag() > max_drag) || total_lift() > min_lift
        ? kts_to_speed(5) // pretty arbitrary...
        : velocity;

      for (; speed < v_mx; speed += 1) { 
        velocity = speed;
        loadInput();
        con.recomp_all_parts();
        if (total_drag() > max_drag) 
          break;
      }

      trace("velocity after step2: " + velocity);

      // // at min drag angle can not produce enough lift? unsolvable.
      // if (total_lift() < min_lift) {
      //   trace("can not solve 'fild max speed' task for given inputs.\nincrease drag input or decrease lift input");
      //   return;
      // }

      // step 3. pitch_of_min_drag correction for too much lift...
      if (total_lift() > min_lift) {
        // unsustainable, needs less pitch & speed...
        // reduce min_pitch until lift is OK
        while(pitch_of_min_drag > ang_mn) {
          pitch_of_min_drag -= 0.05;
          craft_pitch = pitch_of_min_drag;
          loadInput();
          con.recomp_all_parts();
          if (total_lift() <= min_lift)
            break;
        }
        trace("corrected pitch_of_min_drag: " + pitch_of_min_drag);
      }

      // step 4. from this speed, iterate speed down
      for (speed = velocity; speed >= 0; speed -= 1) {
        trace("speed: " + speed);
        double lift = 0;
        double drag = 0;
        double pitch = pitch_of_min_drag;
        velocity = speed;
        for (; pitch < ang_mx; pitch += 0.1) {
          craft_pitch = pitch;
          loadInput();
          con.recomp_all_parts();
          lift = total_lift();
          drag = total_drag();
          if (drag >= max_drag) {
            // stop increasing pitch, won't work. 
            //likely need less speed
            trace("too much drag, break. speed: " + speed + " pitch: " + pitch);
            break;
          }
          if (lift >= min_lift) {
            trace("done ");
            if (update_info) {
              make_max_speed_info(min_lift, max_drag, velocity);
              System.out.println("\nDone!\n----------------\n" + max_speed_info);
            }
            return;
          } 
        }
        // here pitch is at max. what about lift?
        if (pitch >= ang_mx && lift < min_lift) {
          trace("oops, can not be solved.\nincrease drag limit or decrease lift threshold!");
          return;
        }
      }
    }
    
  } // class VPP

  class MainControlsPanel extends JPanel {
    FoilBoardWithProblems app ;
    Label l1,l2,blank,pitchMomentLabel,liftOverDrag,reynoldsLabel,FSlabel, lbl_lift_loc;
    Choice outch,dragOutputCh,untch, selectFoilBoard;
    Button bt3,ibt_flight,ibt_shape,ibt_size,ibt_sel_plot,ibt_analysis, ibt_env;
    Button[] all_inputs;
    Button bt_plot,bt_probe,bt_gages,bt_geom,bt_data ;
    TextField outlft_wing, outlft_stab, outlft_strut, outlft_fuse;
    TextField outDrag_wing, outDrag_stab, outDrag_strut, outDrag_fuse;
    TextField outMoment,outLD_wing,outLD_stab,outReynolds_wing, outReynolds_stab;
    TextField outTotalLift, outTotalDrag, outTotalLiftLocation;

    void switch_to_part(Part p) {
      if (current_part != null)
        current_part.save_state();

      double conv = (lunits == METRIC) ? 1.0 : LEN_M2FT;
      current_part = p;
      foil = p.foil;
      chrdold = chord = p.chord * conv ;
      span_old = span =  p.span  * conv ;
      arold = area = span * chord ;
      aspr = span/chord ;

      thkinpt = p.thickness_pst;
      thkval = thkinpt/25;
      caminpt = p.camber ;
      camval = caminpt / 25.0 ;
      alpha_degr = p.aoa;

      cache_t_Cl = p.t_Cl;
      cache_t_Cd = p.t_Cd;

      solver.load_stall_model_cache(p.foil);

      // take care of accessibility of input controls
      switch (foil) {
      // fixed geomtery foils block thickness and camber coplot_trace_countols
        case FOIL_AQUILA_9P3 :
        case FOIL_NACA_63_412 :
        case FOIL_NACA_64_814 :
        case FOIL_BLADERIDER_V1 :
          in.shp.inl.f1.setEnabled(false);
          in.shp.inl.f2.setEnabled(false);
          in.shp.inr.s1.setEnabled(false);
          in.shp.inr.s2.setEnabled(false);
          break;
        default :
          in.shp.inl.f1.setEnabled(true);
          in.shp.inl.f2.setEnabled(true);
          in.shp.inr.s1.setEnabled(true);
          in.shp.inr.s2.setEnabled(true);
      }
      
      loadInput() ; // note: this also does computeFlow()
      loadOut();
    }

    void recomp_all_parts() {
      Part curr_pt = current_part;
      if (curr_pt != null) 
        curr_pt.save_state();

      // fast recomp block
      computeFlow_fast_recomp = true;
      switch_to_part(wing);
      switch_to_part(stab);
      switch_to_part(strut);
      switch_to_part(fuse);
      computeFlow_fast_recomp = false;

      if (curr_pt != null) 
  switch_to_part(curr_pt);
      else 
  switch_to_part(wing);
    }

    Label addLabel(String text, Color fg, Color bg, int align) {
      Label lb = new Label(text, align);
      if (fg != null) lb.setForeground(fg);
      if (bg != null) lb.setBackground(bg);
      add(lb);
      return lb;
    }

    TextField addOutput() {
      TextField out = new TextField("12.5",5) ;
      out.setBackground(Color.black) ;
      out.setForeground(Color.yellow) ;
      add(out);
      return out;
    }

    void outlft_setText(String text) {
      TextField tf;
      if (current_part == wing) tf = outlft_wing;
      else if (current_part == stab) tf = outlft_stab;
      else if (current_part == strut) tf = outlft_strut;
      else tf = outlft_fuse;
      tf.setText(text);
    }
   
    void outDrag_setText(String text) {
      TextField tf;
      if (current_part == wing) tf = outDrag_wing;
      else if (current_part == stab) tf = outDrag_stab;
      else if (current_part == strut) tf = outDrag_strut;
      else tf = outDrag_fuse;
      tf.setText(text);
    }

    void outLD_setText(String text) {
      TextField tf = null;
      if (current_part == wing) tf = outLD_wing;
      else if (current_part == stab) tf = outLD_stab;

      if (tf != null) tf.setText(text);
    }
   
    void outReynolds_setText(String text) {
      TextField tf = null;
      if (current_part == wing) tf = outReynolds_wing;
      else if (current_part == stab) tf = outReynolds_stab;

      if (tf != null) tf.setText(text);
    }

    Button all_outputs[];
   
    MainControlsPanel (FoilBoardWithProblems target) { 
      app = target ;
      setLayout(new GridLayout(9,/*ignored!*/0,5,5)) ;

      // l1 = new Label("Output", Label.RIGHT) ;
      // l1.setForeground(Color.red) ;
      // l2 = new Label("Input", Label.CENTER) ;
      // l2.setForeground(Color.blue) ;

      addLabel("T Hydro FoilBoardWithProblems", Color.red, null, Label.RIGHT) ;
      addLabel("Simulator v1.0", Color.red, null, Label.LEFT) ;

      addLabel("Units: ", null, null, Label.RIGHT);

      bt3 = new Button("Reset") ;
      bt3.setBackground(Color.red) ;
      bt3.setForeground(Color.white) ;
      bt3.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      solver.setImperialDefaults() ;
      in.shp.inr.shapch.select(FOIL_JOUKOWSKI);
      in.shp.inl.inl1.setBackground(Color.yellow) ;
      in.shp.inl.inl2.setBackground(Color.white) ;
      in.shp.inl.inl3.setBackground(Color.white) ;
      in.shp.inr.inr1.inb2.setBackground(Color.white) ;
      in.shp.inr.inr1.inb1.setBackground(Color.white) ;
      in.shp.inr.inr2.inb3.setBackground(Color.white) ;
      in.shp.inr.inr2.inb4.setBackground(Color.white) ;
      in.cyl.inr.shapch.select(FOIL_JOUKOWSKI);
      in.env.inl.o1.setBackground(Color.black) ;
      in.env.inl.o1.setForeground(Color.yellow) ;
      in.env.inr.inr2.o2.setBackground(Color.black) ;
      in.env.inr.inr2.o2.setForeground(Color.yellow) ;
      in.env.inl.o3.setBackground(Color.black) ;
      in.env.inl.o3.setForeground(Color.yellow) ;
      in.env.inr.inr3.o4.setBackground(Color.black) ;
      in.env.inr.inr3.o4.setForeground(Color.yellow) ;
      layin.show(in, "second")  ;
      ibt_shape.setBackground(Color.yellow) ;
      ibt_flight.setBackground(Color.white) ;
      ibt_size.setBackground(Color.white) ;
      ibt_sel_plot.setBackground(Color.white) ;
      ibt_analysis.setBackground(Color.white) ;
      //          in.anl.bt1.setBackground(Color.yellow) ;
      //          in.anl.bt2.setBackground(Color.white) ;
      in.anl.bt3.setBackground(Color.white) ;
      in.anl.bt4_1.setBackground(Color.yellow) ;
      in.anl.bt5.setBackground(Color.yellow) ;
      in.anl.bt6.setBackground(Color.white) ;
      in.anl.bt7.setBackground(Color.yellow) ;
      in.anl.bt8.setBackground(Color.white) ;
      in.anl.bt9.setBackground(Color.yellow) ;
      in.anl.bt10.setBackground(Color.white) ;
      in.anl.cbt1.setBackground(Color.white) ;
      in.anl.cbt2.setBackground(Color.white) ; 
      in.anl.cbt3.setBackground(Color.white) ; 

      // **** the lunits check MUST come first
      untch.select(METRIC) ;
      setUnits (METRIC) ;
      
      lftout = outch.getSelectedIndex() ;
      dragOut = dragOutputCh.getSelectedIndex();
        
      layplt.show(in.grf.l, "first") ;
        
      layout.show(out, "first")  ;
      bt_plot.setBackground(Color.yellow) ;
      bt_probe.setBackground(Color.white) ;
      bt_gages.setBackground(Color.white) ;
      bt_geom.setBackground(Color.white) ;
      bt_data.setBackground(Color.white) ;
      out.prb.l.bt3.setBackground(Color.white) ;
      out.prb.l.bt2.setBackground(Color.white) ;
      out.prb.l.bt1.setBackground(Color.white) ;
      recomp_all_parts();
    }});

      ibt_flight = new Button("Flight") ;
      ibt_flight.setBackground(Color.white) ;
      ibt_flight.setForeground(Color.blue) ;
      ibt_flight.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_inputs) b.setBackground(Color.white);
      ((Button)e.getSource()).setBackground(Color.yellow);
      layin.show(in, "first")  ;
    }});

      ibt_shape = new Button("Shape") ;
      ibt_shape.setBackground(Color.yellow) ;
      ibt_shape.setForeground(Color.blue) ;
      ibt_shape.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_inputs) b.setBackground(Color.white);
      ((Button)e.getSource()).setBackground(Color.yellow);
      if (!foil_is_cylinder_or_ball(foil)) layin.show(in, "second")  ;
      else layin.show(in, "fifth")  ;
    }});

      ibt_size = new Button("Size") ;
      ibt_size.setBackground(Color.white) ;
      ibt_size.setForeground(Color.blue) ;
      ibt_size.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_inputs) b.setBackground(Color.white);
      ((Button)e.getSource()).setBackground(Color.yellow);
      if (!foil_is_cylinder_or_ball(foil)) layin.show(in, "third")  ;
      else layin.show(in, "fifth")  ;
    }});

      ibt_sel_plot = new Button("Select Plot") ;
      ibt_sel_plot.setBackground(Color.white) ;
      ibt_sel_plot.setForeground(Color.blue) ;
      ibt_sel_plot.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_inputs) b.setBackground(Color.white);
      ((Button)e.getSource()).setBackground(Color.yellow);
      pboflag = 0 ;
      layin.show(in, "fourth")  ;
    }});

      ibt_analysis = new Button("Analysis") ;
      ibt_analysis.setBackground(Color.white) ;
      ibt_analysis.setForeground(Color.blue) ;
      ibt_analysis.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_inputs) b.setBackground(Color.white);
      ((Button)e.getSource()).setBackground(Color.yellow);
      layin.show(in, "sixth")  ;
    }});

      ibt_env = new Button("Environ") ;
      ibt_env.setBackground(Color.white) ;
      ibt_env.setForeground(Color.blue) ;
      ibt_env.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_inputs) b.setBackground(Color.white);
      ((Button)e.getSource()).setBackground(Color.yellow);
      layin.show(in, "seventh")  ;
    }});

      all_inputs = new Button[]{ibt_flight, ibt_shape, ibt_size, ibt_sel_plot, ibt_analysis, ibt_env};

      bt_plot = new Button("Plot") ;
      bt_plot.setBackground(Color.yellow) ;
      bt_plot.setForeground(Color.red) ;
      bt_plot.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_outputs)
        b.setBackground(Color.red);
      bt_plot.setBackground(Color.red) ;
      dispp = 0;
      pboflag = 0 ;
      layout.show(out, "first")  ;
    }});

      bt_probe = new Button("Probe") ;
      bt_probe.setBackground(Color.white) ;
      bt_probe.setForeground(Color.red) ;
      bt_probe.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_outputs)
        b.setBackground(Color.white);
      bt_probe.setBackground(Color.yellow) ;
      pboflag = 0 ;
      layout.show(out, "second")  ;
    }});

      bt_gages = new Button("Gages") ;
      bt_gages.setBackground(Color.white) ;
      bt_gages.setForeground(Color.red) ;
      bt_gages.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_outputs)
        b.setBackground(Color.red);
      bt_gages.setBackground(Color.green) ;
      dispp = 20;
      pboflag = 0 ;
      layout.show(out, "first")  ;
    }});

      bt_geom = new Button("Geometry") ;
      bt_geom.setBackground(Color.white) ;
      bt_geom.setForeground(Color.red) ;
      bt_geom.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      double volume = 0.0 ;
      for (Button b : all_outputs)
        b.setBackground(Color.white);
      bt_geom.setBackground(Color.yellow) ;
      pboflag = 0 ;
      layout.show(out, "third")  ;

      switch (foil) {
      case FOIL_JOUKOWSKI:
        out.perf.prnt.append( "\n\n Joukowski Airfoil" ) ;
        break ;
      case FOIL_NACA4:
      case FOIL_NACA_64_814:
      case FOIL_AQUILA_9P3: 
      case FOIL_NACA_63_412: 
      case FOIL_BLADERIDER_V1: 
        out.perf.prnt.append( "\n\n Tabulated FoilBoardWithProblems. Printing geometry for\nJoukowski Airfoil as example" ) ;
        break ;
      case FOIL_ELLIPTICAL: {        
        out.perf.prnt.append( "\n\n Elliptical Airfoil" ) ;
        break ;
      }
      case FOIL_FLAT_PLATE: {     
        out.perf.prnt.append( "\n\n Plate" ) ;
        break ;
      }
      case FOIL_CYLINDER: {     
        out.perf.prnt.append( "\n\n Rotating Cylinder" ) ;
        break ;
      }
      case FOIL_BALL: {     
        out.perf.prnt.append( "\n\n Spinning Ball" ) ;
        break ;
      }
      }
      if (!foil_is_cylinder_or_ball(foil)) {
        out.perf.prnt.append( "\n Camber = " + filter3(caminpt) ) ;
        out.perf.prnt.append( " % of chord ," ) ;
        out.perf.prnt.append( " Thickness = " + filter3(thkinpt) ) ;
        out.perf.prnt.append( " % chord ," ) ;
        out.perf.prnt.append( "\n Chord = " + filter3(chord) ) ;
        if (lunits == IMPERIAL) out.perf.prnt.append( " ft ," ) ;
        else /*METRIC*/         out.perf.prnt.append( " m ," ) ;
        out.perf.prnt.append( " Span = " + filter3(span) ) ;
        if (lunits == IMPERIAL) out.perf.prnt.append( " ft ," ) ;
        else /*METRIC*/         out.perf.prnt.append( " m ," ) ;
        out.perf.prnt.append( "\n Angle of attack = " + filter3(alpha_degr) );
        out.perf.prnt.append( " degrees ," ) ;
      } else { // cylinder and ball
        out.perf.prnt.append( "\n Spin  = " + filter3(spin*60.0) ) ;
        out.perf.prnt.append( " rpm ," ) ;
        out.perf.prnt.append( " Radius = " + filter3(radius) ) ;
        if (lunits == IMPERIAL) out.perf.prnt.append( " ft ," ) ;
        else /*METRIC*/         out.perf.prnt.append( " m ," ) ;
      }
      switch(planet) {
      case 0: {       
        out.perf.prnt.append( "\n Standard Earth Atmosphere" ) ;
        break ;
      }
      case 1: {       
        out.perf.prnt.append( "\n Martian Atmosphere" ) ;
        break ;
      }
      case 2: {       
        out.perf.prnt.append( "\n Under Water" ) ;
        break ;
      }
      case 3: {       
        out.perf.prnt.append( "\n Specified Conditions" ) ;
        break ;
      }
      case 4: {       
        out.perf.prnt.append( "\n Specified Conditions" ) ;
        break ;
      }
      }
      switch (lunits)  {
      case 0: {                             /* English */
        out.perf.prnt.append( "\n Ambient Pressure = " + filter3(ps0/144.) ) ;
        out.perf.prnt.append( "lb/sq in," ) ;
        break;
      }
      case 1: {                             /* Metric */
        out.perf.prnt.append( "\n Ambient Pressure = " + filter3(101.3/14.7*ps0/144.) );
        out.perf.prnt.append( "kPa," ) ;
        break;
      }
      }
      out.perf.prnt.append( "\n Ambient Velocity = " + filter0(velocity) ) ;
      if (lunits == IMPERIAL) out.perf.prnt.append( " mph ," ) ;
      else /*METRIC*/         out.perf.prnt.append( " km/hr ," ) ;

      out.perf.prnt.append( "\n \t Upper Surface \t \t \t ") ;
      out.perf.prnt.append( "\n X/c \t Y/c \t P \t V \t ");
      double mapfac = 4.0 ;
      if (foil_is_cylinder_or_ball(foil)) mapfac = 2.0 ;
      for (int index = 0; index <= POINTS_COUNT_HALF-1; ++ index) {
        out.perf.prnt.append( "\n" + filter3(xpl[0][POINTS_COUNT_HALF-index]/mapfac) +  "\t"
            + filter3(ypl[0][POINTS_COUNT_HALF-index]/mapfac) + "\t" + filter3(plp[POINTS_COUNT_HALF-index]) + "\t"
            + filter0(plv[POINTS_COUNT_HALF-index]) + "\t"); 
        if (index <= POINTS_COUNT_HALF-2) {
    volume = volume + .5 * (((xpl[0][POINTS_COUNT_HALF-index-1]-xpl[0][POINTS_COUNT_HALF-index])
           *(ypl[0][POINTS_COUNT_HALF-index]+ ypl[0][POINTS_COUNT_HALF-index-1])) / (mapfac * mapfac)) * chord ;
        }
      }
      out.perf.prnt.append( "\n \t Lower Surface \t \t \t ") ;
      for (int index = 0; index <= POINTS_COUNT_HALF-1; ++ index) {
        out.perf.prnt.append( "\n"  + filter3(xpl[0][POINTS_COUNT_HALF+index]/mapfac) + "\t"
            + filter3(ypl[0][POINTS_COUNT_HALF+index]/mapfac) + "\t" + filter3(plp[POINTS_COUNT_HALF+index]) + "\t"
            + filter0(plv[POINTS_COUNT_HALF+index]) ) ;
        if (index <= POINTS_COUNT_HALF-2) {
    volume = volume - .5 * (((xpl[0][POINTS_COUNT_HALF+index+1]-xpl[0][POINTS_COUNT_HALF+index])
           *(ypl[0][POINTS_COUNT_HALF+index]+ ypl[0][POINTS_COUNT_HALF+index+1])) / (mapfac * mapfac)) * chord ;
        }
      }
      volume = volume * span ;
      if (foil_is_cylinder_or_ball(foil)) volume = 3.14159 * radius * radius * span ;
      if (foil >= FOIL_BALL) volume = 3.14159 * radius * radius * radius * 4.0 / 3.0 ;
           
      out.perf.prnt.append( "\n  Volume =" + filter3(volume));
      if (lunits == IMPERIAL) out.perf.prnt.append( " cu ft " ) ;
      else /*METRIC*/         out.perf.prnt.append( " cu m " ) ;
    }});

      bt_data = new Button("Data") ;
      bt_data.setBackground(Color.white) ;
      bt_data.setForeground(Color.red) ;
      bt_data.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed (ActionEvent e) {
          for (Button b : all_outputs)
            b.setBackground(Color.white);
          bt_data.setBackground(Color.yellow);

          layout.show(out, "third");
          pboflag = 0;

          current_part.save_state();

          TextArea ta_out = FoilBoardWithProblems.this.out.perf.prnt;

          if (!t_foil_name.equals("Test"))
            ta_out.append("\n\nHydrofoil: " + t_foil_name);

          java.util.Date date = new java.util.Date();
          ta_out.append("\n     Date: " + date);

          wing.print("Main Wing", ta_out);
          stab.print("Stabilizer Wing", ta_out);
          strut.print("Mast (a.k.a. Strut)", ta_out);
          fuse.print("Fuselage", ta_out);

          ta_out.append("\n\n");
          switch (planet) {
            case 0 : {
              ta_out.append("\n Standard Earth Atmosphere");
              break;
            }
            case 1 : {
              ta_out.append("\n Martian Atmosphere");
              break;
            }
            case 2 : {
              ta_out.append("\n Water");
              break;
            }
            case 3 : {
              ta_out.append("\n Specified Conditions");
              break;
            }
            case 4 : {
              ta_out.append("\n Specified Conditions");
              break;
            }
          }

          // ta_out.append( "\n Altitude = " + filter0(alt) ) ;
          // if (lunits == IMPERIAL) ta_out.append( " ft ," ) ;
          // else /*METRIC*/ ta_out.append( " m ," ) ;

          switch (lunits) {
            case 0 : { /* English */
              ta_out.append("\n Density = " + filter5(rho));
              ta_out.append("slug/cu ft");
              ta_out.append("\n Pressure = " + filter3(ps0 / 144.));
              ta_out.append("lb/sq in,");
              ta_out.append(" Temperature = " + filter0(ts0 - 460.));
              ta_out.append("F,");
              break;
            }
            case 1 : { /* Metric */
              ta_out.append(" Density = " + filter3(rho * 515.4));
              ta_out.append("kg/cu m");
              ta_out.append("\n Pressure = " + filter3(101.3 / 14.7 * ps0 / 144.));
              ta_out.append("kPa,");
              ta_out.append(" Temperature = " + filter0(ts0 * 5.0 / 9.0 - 273.1));
              ta_out.append("C,");
              break;
            }
          }

          ta_out.append("\n Speed = " + filter1(velocity * (lunits == IMPERIAL ? 0.868976 : 0.539957)) + "Kts, or");
          ta_out.append(" " + filter1(velocity));
          if (lunits == IMPERIAL)
            ta_out.append(" mph ,");
          else
            /* METRIC */ta_out.append(" km/hr ,");

          // if (lftout == 1)
          // ta_out.append( "\n  Lift Coefficient = " + filter3(clift) ) ;
          // if (lftout == 0) {
          // if (Math.abs(lift) <= 10.0) ta_out.append( "\n  Lift = " +
          // filter3(lift) ) ;
          // if (Math.abs(lift) > 10.0) ta_out.append( "\n  Lift  = " +
          // filter0(lift) ) ;
          // if (lunits == IMPERIAL) ta_out.append( " lbs " ) ;
          // else /*METRIC*/ ta_out.append( " Newtons " ) ;
          // }
          // if (dragOut == 1)
          // ta_out.append( "\n  Drag Coefficient = " + filter3(dragCoeff) ) ;
          // if (lftout == 0) {
          // ta_out.append( "\n  Drag  = " + filter0(drag) ) ;
          // if (lunits == IMPERIAL) ta_out.append( " lbs " ) ;
          // else /*METRIC*/ ta_out.append( " Newtons " ) ;
          // }

          ta_out.append("\n  Lift = " + con.outTotalLift.getText());
          ta_out.append("\n  Drag  = " + con.outTotalDrag.getText());

          if (min_takeoff_speed_info != null)
            ta_out.append("\n\n" + min_takeoff_speed_info);

          if (cruising_info != null)
            ta_out.append("\n\n" + cruising_info);

          if (max_speed_info != null)
            ta_out.append("\n\n" + max_speed_info);

        }
      });

      untch = new Choice() ;
      untch.setBackground(Color.white) ;
      untch.setForeground(Color.black) ;
      untch.addItem("Imperial") ;
      untch.addItem("Metric");
      untch.select(1) ;
      untch.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed (ActionEvent e) {
          setUnits(untch.getSelectedIndex());
          recomp_all_parts(); // no need for loadInput() - recomp_all_parts does it 
        }
      });

      outch = new Choice() ;
      outch.setBackground(Color.white) ;
      outch.setForeground(Color.black) ;
      outch.addItem("Lift ") ;
      outch.addItem("  Cl ");
      outch.addItem("Total Lift");
      outch.select(0) ;
      outch.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      lftout = outch.getSelectedIndex() ;
      // excessive, fix me!
      recomp_all_parts();
      // above does it, no need loadInput() ;
    }});

      dragOutputCh = new Choice();
      dragOutputCh.setBackground(Color.white);
      dragOutputCh.setForeground(Color.black);
      dragOutputCh.addItem("Drag");
      dragOutputCh.addItem(" Cd ");
      dragOutputCh.select(0);
      dragOutputCh.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      dragOut = dragOutputCh.getSelectedIndex();
      // excessive, fix me!
      recomp_all_parts();
      // above does it, no need loadInput() ;
    }});

      pitchMomentLabel = new Label("Cm",Label.RIGHT);
 
      liftOverDrag = new Label("L/D ratio",Label.RIGHT);
      liftOverDrag.setForeground(Color.black);

      reynoldsLabel = new Label("Reynolds #", Label.RIGHT);
      reynoldsLabel.setForeground(Color.black);

      add(untch);
      add(bt3) ;

      // add(l2) ;
      // add(new Label("Student ", Label.RIGHT));
      // add(new Label(" Version 1.5b", Label.LEFT));
      // add(l1) ;


      {

  //addLabel(t_foil_name, null, null, Label.RIGHT);
  String known_foil_names[]={"Select Foil", "India 777777777777777777","Aus","U.S.A","England","Newzealand"};
  JComboBox known_foils = new JComboBox(known_foil_names);
  add(known_foils);
  known_foils.addActionListener (new ActionListener () {
      public void actionPerformed(ActionEvent e) {
        //doSomething();
      }
    }); 
        
  final Button bt_strut = new Button("Mast") ;
  part_button = bt_strut;
  bt_strut.setBackground(Color.white) ;
  bt_strut.setForeground(Color.blue) ;
  bt_strut.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        if (part_button != bt_strut) {
    part_button.setBackground(Color.white);
    part_button = bt_strut;
    part_button.setBackground(Color.yellow);
    switch_to_part(strut);
        }
      }
    });

  bt_wing = new Button("Wing") ;
  bt_wing.setBackground(Color.yellow) ;
  bt_wing.setForeground(Color.blue) ;
  bt_wing.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        if (part_button != bt_wing) {
    part_button.setBackground(Color.white);
    part_button = bt_wing;
    part_button.setBackground(Color.yellow);
    switch_to_part(wing);
        }
      }
    });
  add(bt_wing);

  bt_stab = new Button("Stab") ;
  bt_stab.setBackground(Color.white) ;
  bt_stab.setForeground(Color.blue) ;
  bt_stab.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        if (part_button != bt_stab) {
    part_button.setBackground(Color.white);
    part_button = bt_stab;
    part_button.setBackground(Color.yellow);
    switch_to_part(stab);
        }            
      }
    });
  add(bt_stab);

  final Button bt_fuse = new Button("Fuse") ;
  bt_fuse.setBackground(Color.white) ;
  bt_fuse.setForeground(Color.blue) ;
  bt_fuse.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        if (part_button != bt_fuse) {
    part_button.setBackground(Color.white);
    part_button = bt_fuse;
    part_button.setBackground(Color.yellow);
    switch_to_part(fuse);
        }
      }
    });

  add(bt_strut);
  add(bt_fuse);

      }


      add(outch) ;
      outlft_wing = addOutput();
      outlft_stab = addOutput();
      outlft_strut = addOutput();
      outlft_fuse = addOutput();

      add(dragOutputCh);
      outDrag_wing = addOutput();
      outDrag_stab = addOutput();
      outDrag_strut = addOutput();
      outDrag_fuse= addOutput();

      add(liftOverDrag);
      outLD_wing = addOutput();
      outLD_stab = addOutput();

      boolean want_matte_border = false;

      if (want_matte_border) {
  javax.swing.JLabel jlbl = new javax.swing.JLabel("Total Lift", javax.swing.JLabel.RIGHT);
  jlbl.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 0, 0, Color.BLACK));
  add(jlbl);
      } else
  addLabel("Total Lift", null, null, Label.RIGHT);

      outTotalLift = addOutput();

      // row 6
      add(reynoldsLabel);
      outReynolds_wing = addOutput();
      outReynolds_stab = addOutput();

      if (want_matte_border) {
  javax.swing.JLabel jlbl = new javax.swing.JLabel("Total Drag", javax.swing.JLabel.RIGHT);
  jlbl.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 1, 0, Color.BLACK));
  add(jlbl);
      } else
  addLabel("Total Drag", null, null, Label.RIGHT);

      outTotalDrag = addOutput();

      
      // row 7. Panel tab coplot_trace_countols. output coplot_trace_countols
      add(ibt_flight); // flight
      add(ibt_size); // size
      add(ibt_shape); // shape

      lbl_lift_loc = addLabel("C.G. to Wing:", null, null, Label.RIGHT);
      outTotalLiftLocation = addOutput();

      // row 8
      add(ibt_env);
      add(ibt_sel_plot);
      add(bt_probe);
      add(bt_geom) ;
      add(bt_data);

      // row 9
      add(ibt_analysis);
      addLabel("", null, null, Label.RIGHT);
      add(bt_gages);
      add(bt_plot);
      
      Button bt_html = new Button("Summary");
      all_outputs = new Button[]{bt_plot, bt_probe, bt_gages, bt_geom, bt_data, bt_html};

      add(bt_html);
      bt_html.addActionListener(new ActionListener() {
    boolean tick_tack;
    @Override
    public void actionPerformed(ActionEvent e) {
      for (Button b : all_outputs)
        b.setBackground(Color.white);
      ((Button)e.getSource()).setBackground(Color.yellow) ;

      String html_text = 
        "<style>\n table {border:1px solid black;border-collapse:collapse;width:100%}\n"+
        " th, td {padding:0px;text-align:right;}\n</style>\n\n" + 
        "<body style='font-size:14pt'>\n" + 
        "<b>$NAME</b>\n" + 
        // "<br>Specs" + 
        "<table>\n"+
        "<thead >\n"+
        "<tr style='background-color:yellow'>\n"+
        "<th>Part</th><th>Span<br>cm</th><th>Chord<br>cm</th><th>Thickness<br>cm</th>\n"+
        "<th>Angle<br>deg</th><th>FoilBoardWithProblems</th><th>Area<br>cm2</th></tr></thead>\n"+
        "<tbody>\n"+
        "  <tr style='background-color:#ffffff'><td>Wing</td><td>$WS</td><td>$WC</td><td>$WT</td><td>$Wa</td><td>$WF</td><td>$WA</td></tr>\n"+
        "  <tr style='background-color:#f0f0f0'><td>Stab</td><td>$SS</td><td>$SC</td><td>$ST</td><td>$Sa</td><td>$SF</td><td>$SA</td></tr>\n"+
        "  <tr style='background-color:#ffffff'><td>Fuse</td><td>$FS</td><td>$FC</td><td>$FT</td><td>$Fa</td><td>$FF</td><td>$FA</td></tr>\n"+
        "  <tr style='background-color:#f0f0f0'><td>Mast</td><td>$MS</td><td>$MC</td><td>$MT</td><td>$Ma</td><td>$MF</td><td>$MA</td></tr>\n"+
        "</tbody></table>\n"+
        "Performance Evaluation\n" + 
        "<table>\n"+
        "<thead >\n"+
        "<tr style='background-color:yellow'>\n"+
        "<th>Task</th><th>Speed<br>km/h</th><th>Lift<br>N</th><th>Drag<br>N</th><th>Description</th></tr></thead>\n"+
        "<tbody>\n"+
        "  <tr style='background-color:#ffffff'><td> Takeoff </td><td>$TKS</td><td>$TKL</td><td>$TKD</td><td>For given drag, the lowest take off speed</td></tr>\n"+
        "  <tr style='background-color:#f0f0f0'><td> Cruise  </td><td>$CRS</td><td>$CRL</td><td>$CRD</td><td>Speed of cruising with less possible drag</td></tr>\n"+
        "  <tr style='background-color:#ffffff'><td> Race    </td><td>$RCS</td><td>$RCL</td><td>$RCD</td><td>Max V for given drag, can coplot_trace_countol lift</td></tr>\n"+
        "</tbody></table>\n\n</body>"
        ;

      html_text = html_text.replace("$TKS", toStringOptQMFilter1(min_takeoff_speed));
      html_text = html_text.replace("$TKL", toStringOptQMFilter0(min_takeoff_lift));
      html_text = html_text.replace("$TKD", toStringOptQMFilter0(min_takeoff_drag));
      html_text = html_text.replace("$CRS", toStringOptQMFilter1(cruising_speed));
      html_text = html_text.replace("$CRL", toStringOptQMFilter0(cruising_lift));
      html_text = html_text.replace("$CRD", toStringOptQMFilter0(cruising_drag));
      html_text = html_text.replace("$RCS", toStringOptQMFilter1(max_speed_speed));
      html_text = html_text.replace("$RCL", toStringOptQMFilter0(max_speed_lift));
      html_text = html_text.replace("$RCD", toStringOptQMFilter0(max_speed_drag));


      html_text = html_text.replace("$NAME", t_foil_name);

      html_text = html_text.replace("$WS", ""+filter1(100*wing.span));
      html_text = html_text.replace("$WC", ""+filter1(100*wing.chord));
      html_text = html_text.replace("$WT", ""+filter1(wing.chord*wing.thickness_pst)); // 100*ch*th/100%
      html_text = html_text.replace("$Wa", ""+filter1(wing.aoa));
      html_text = html_text.replace("$WA", ""+filter1(wing.span*wing.chord*100*100));
      html_text = html_text.replace("$WF", wing.foil_descr());

      html_text = html_text.replace("$SS", ""+filter1(100*stab.span));
      html_text = html_text.replace("$SC", ""+filter1(100*stab.chord));
      html_text = html_text.replace("$ST", ""+filter1(stab.chord*stab.thickness_pst));
      html_text = html_text.replace("$Sa", ""+filter1(stab.aoa));
      html_text = html_text.replace("$SA", ""+filter1(stab.span*stab.chord*100*100));
      html_text = html_text.replace("$SF", stab.foil_descr());

      html_text = html_text.replace("$MS", ""+filter1(100*strut.span));
      html_text = html_text.replace("$MC", ""+filter1(100*strut.chord));
      html_text = html_text.replace("$MT", ""+filter1(strut.chord*strut.thickness_pst));
      html_text = html_text.replace("$Ma", ""+filter1(strut.aoa));
      html_text = html_text.replace("$MA", ""+filter1(strut.span*strut.chord*100*100));
      html_text = html_text.replace("$MF", strut.foil_descr());

      html_text = html_text.replace("$FS", ""+filter1(100*fuse.span));
      html_text = html_text.replace("$FC", ""+filter1(100*fuse.chord));
      html_text = html_text.replace("$FT", ""+filter1(fuse.chord*fuse.thickness_pst));
      html_text = html_text.replace("$Fa", ""+filter1(fuse.aoa));
      html_text = html_text.replace("$FA", ""+filter1(fuse.span*fuse.chord*100*100));
      html_text = html_text.replace("$FF", fuse.foil_descr());

      //System.out.println("-- tick_tack: " + tick_tack);

      if (tick_tack) {
        FoilBoardWithProblems.this.out.perfwebsrc.prnt.setText(html_text);
        layout.show(out, "fifth"); 
      } else {
        FoilBoardWithProblems.this.out.perfweb.prnt.setText(html_text);
        layout.show(out, "fourth");
      }

      tick_tack = !tick_tack;

    }});

    }

  } // Con

  class In extends Panel {
    FoilBoardWithProblems app ;
    Flight flt ;
    Shape shp ;
    Siz siz ;
    Cyl cyl ;
    Grf grf ;
    Anl anl ;
    Env env ;

    In (FoilBoardWithProblems target) { 
      app = target ;
      layin = new CardLayout() ;
      setLayout(layin) ;

      flt = new Flight(app) ;
      shp = new Shape(app) ;
      siz = new Siz(app) ;       
      cyl = new Cyl(app) ;
      grf = new Grf(app) ;
      anl = new Anl(app) ;
      env = new Env(app) ;

      add ("second", shp) ;
      add ("first", flt) ;
      add ("third", siz) ;
      add ("fifth", cyl) ;
      add ("fourth", grf) ;
      add ("sixth", anl) ;
      add ("seventh", env) ;
    }
 
    class Flight extends Panel {
      FoilBoardWithProblems app ;

      class Name extends Label { 
        Name(String text) { super(text, Label.RIGHT); }
        Name(String text, int align) { super(text, align); }
      }

      TextField f1,f2, fAoA;
      Name l1,l2, lAoA;
      Scrollbar s1,s2, sAoA;

      TextField tf_tkoff_min_lift, tf_tkoff_max_drag ;
      Name lbl_tkoff_min_lift, lbl_tkoff_max_drag;

      TextField tf_cruise_min_lift, tf_cruise_starting_speed ;
      Name lbl_cruise_min_lift, lbl_cruise_starting_speed;

      TextField tf_race_min_lift, tf_race_max_drag ;
      Name lbl_race_min_lift, lbl_race_max_drag;

      Flight(FoilBoardWithProblems target) {
        int i1,i2, iAoA ;

        app = target ;
        setLayout(new GridLayout(8,2,2,10)) ;
 
        Panel p = new Panel(new GridLayout(1,2,2,2));
        l1 = new Name("Speed mph") ;
        f1 = new TextField("100.0",5) ;
        p.add(l1);
        p.add(f1);

        add(p);

        i1 = (int) (((100.0 - v_mn)/(v_mx-v_mn))*1000.) ;
        i2 = (int) (((0.0 - al_mn)/(al_mx-al_mn))*1000.) ;
        iAoA = (int) (((0.0 - ang_mn)/(ang_mx-ang_mn))*1000.) ;

        s1 = new Scrollbar(Scrollbar.HORIZONTAL,i1,10,0,1000);
        sAoA = new Scrollbar(Scrollbar.HORIZONTAL,iAoA,10,0,1000);
        s2 = new Scrollbar(Scrollbar.HORIZONTAL,i2,10,0,1000);

        add(s1);

        p = new Panel(new GridLayout(1,2,2,2));
        lAoA = new Name("Craft Pitch deg") ;
        fAoA = new TextField("0.0",5) ;
        p.add(lAoA);
        p.add(fAoA);
        add(p);

        add(sAoA);

        p = new Panel(new GridLayout(1,2,2,2));
        l2 = new Name("Altitude ft") ;
        f2 = new TextField(System.getProperty("TKL", "735"),5) ;
        p.add(l2);
        p.add(f2);
        add(p);

        add(s2);

        lbl_tkoff_min_lift = new Name("Lift >") ;
        tf_tkoff_min_lift = new TextField(System.getProperty("TKL", "735 N"),5) ;

        lbl_tkoff_max_drag = new Name("Drag <") ;
        tf_tkoff_max_drag = new TextField(System.getProperty("TKD", "85 N"),5) ;

        lbl_cruise_min_lift = new Name("Lift >") ;
        tf_cruise_min_lift = new TextField(System.getProperty("CRL", "735 N"),5) ;

        lbl_cruise_starting_speed = new Name("Speed >=") ;
        tf_cruise_starting_speed = new TextField(System.getProperty("CRS", "10 km/h"),5) ;

        lbl_race_min_lift = new Name("Lift >") ;
        tf_race_min_lift = new TextField(System.getProperty("RSL", "735 N"),5) ;

        lbl_race_max_drag = new Name("Drag <") ;
        tf_race_max_drag = new TextField(System.getProperty("RSD", "300 N"),5) ;

        add(new javax.swing.JLabel("\u2193 Constraints \u2193", Label.LEFT));
        // add(new Name("Solvers", Label.LEFT)); 
        add(new javax.swing.JLabel("\u2193 Solvers \u2193", Label.LEFT));

        p = new Panel(new GridLayout(1,4,0,0));
        add(p);

        p.add(lbl_tkoff_min_lift) ; // lift
        p.add(tf_tkoff_min_lift) ;
        p.add(lbl_tkoff_max_drag) ; // drag
        p.add(tf_tkoff_max_drag) ;

        Button b;
        b = new Button("Find Lowest TakeOff speed");
        add(b);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              double min_lift = parse_force_constraint(tf_tkoff_min_lift, "TKL", "735 N");
              double max_drag = parse_force_constraint(tf_tkoff_max_drag, "TKD", "85 N");
              computeFlow_fast_recomp = true;
              vpp.find_min_takeoff_v(min_lift, max_drag);
              computeFlow_fast_recomp = false;
            }});

        p = new Panel(new GridLayout(1,4,0,0));
        add(p);

        p.add(lbl_cruise_min_lift) ; // lift
        p.add(tf_cruise_min_lift) ;
        p.add(lbl_cruise_starting_speed) ; // starting speed
        p.add(tf_cruise_starting_speed) ;

        b = new Button("Find Speed of lesser Drag");
        add(b);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              double min_lift = parse_force_constraint(tf_cruise_min_lift, "CRL", "735 N");
              double starting_speed = parse_speed_constraint(tf_cruise_starting_speed, "CRS", "10 km/h");
              computeFlow_fast_recomp = true;
              vpp.easy_ride(min_lift, min_takeoff_speed_info != null ? min_takeoff_speed : velocity);
              computeFlow_fast_recomp = false;
            }});

        p = new Panel(new GridLayout(1,4,0,0));
        add(p);

        p.add(lbl_race_min_lift) ; // lift
        p.add(tf_race_min_lift) ;
        p.add(lbl_race_max_drag) ; // drag
        p.add(tf_race_max_drag) ;


        b = new Button("Find Max Possible Steady Speed");
        add(b);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              double min_lift = parse_force_constraint(tf_race_min_lift, "RSL", "735 N");
              double max_drag = parse_force_constraint(tf_race_max_drag, "RSD", "300 N");
              computeFlow_fast_recomp = true;
              vpp.max_speed(min_lift, max_drag, true);
              computeFlow_fast_recomp = false;
            }});

        // add(new Name(""));
        Checkbox chb;
        add(chb = new Checkbox("Trace", false));
        chb.addItemListener(new ItemListener() {
         public void itemStateChanged(ItemEvent e) {             
           vpp.trace = e.getStateChange() == ItemEvent.SELECTED;
           System.out.println("-- trace: " + vpp.trace);
         }
      });

        Panel buttons = new Panel();
        add(buttons);
        buttons.setLayout(new GridLayout(1,2,2,10)) ;

        b = new Button("Pitch of Min Drag");
        buttons.add(b);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              vpp.find_aoa_of_min_drag();
            }});

        b = new Button("max V slow version");
        buttons.add(b);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              double min_lift = parse_force_constraint(tf_race_min_lift, "RSL", "735 N");
              double max_drag = parse_force_constraint(tf_race_max_drag, "RSD", "300 N");
              vpp.max_speed_slow(min_lift, max_drag, 70, -1, -4, 0.1);
            }});

      }

      boolean separate_suffix(String val, TextField tf, String suff) {
        if (val.endsWith(suff)) { 
          tf.setText(val.replace(suff, " " + suff));
          return true;
        }
        return false;
      }
        

      // for convenince, allow user to enter units here
      // todo: respect current unit mode.
      double parse_force_constraint(TextField tf, String prop_name, String dflt) {
        String[] input = tf.getText().trim().split("\\s+");
        switch (input.length) {
        case 0: 
          dflt = (dflt==null || 
                  dflt.equals("") || 
                  !dflt.matches("[+-\\.]?\\d*[\\.]?\\d*")) 
            ? "10" : dflt;
          tf.setText(System.getProperty(prop_name, dflt));
          return parse_force_constraint(tf, prop_name, dflt);
        case 1:
          String s = input[0].toLowerCase();
          if (
              separate_suffix(s, tf, "kg")  ||
              separate_suffix(s, tf, "lb") || 
              separate_suffix(s, tf, "n") ||
              // odd ones            
              separate_suffix(s, tf, "kgf") ||
              separate_suffix(s, tf, "lbf") ||
              false)
            return parse_force_constraint(tf, prop_name, dflt);
          else {
            tf.setText(s + " N");
            return parse_force_constraint(tf, prop_name, dflt);
          }
            
        default:
          double val = Double.parseDouble(input[0].toLowerCase());
          String unit = input[1].toLowerCase();
          if (unit.startsWith("n")) return val;
          else if (unit.startsWith("k")) return 9.80665002864 * val;
          else if (unit.startsWith("l")) return 4.44822 * val;
          else return val;
        }
      }

      double parse_speed_constraint(TextField tf, String prop_name, String dflt) {
        String[] input = tf.getText().trim().split("\\s+");
        switch (input.length) {
        case 0: 
          dflt = (dflt==null || 
                  dflt.equals("") || 
                  !dflt.matches("[+-\\.]?\\d*[\\.]?\\d*")) 
            ? "10" : dflt;
          tf.setText(System.getProperty(prop_name, dflt));
          return parse_speed_constraint(tf, prop_name, dflt);
        case 1:
          String s = input[0].toLowerCase();
          if (
              separate_suffix(s, tf, "kt")  ||
              separate_suffix(s, tf, "kts") || 
              separate_suffix(s, tf, "km/h") ||
              separate_suffix(s, tf, "m/s") ||
              separate_suffix(s, tf, "mph") ||
              separate_suffix(s, tf, "fps") ||
              // odd ones            
              separate_suffix(s, tf, "f/s") ||
              separate_suffix(s, tf, "kmh") ||
              false)
            return parse_speed_constraint(tf, prop_name, dflt);
          else {
            tf.setText(s + " km/h");
            return parse_speed_constraint(tf, prop_name, dflt);
          }
        default:
          double val = Double.parseDouble(input[0].toLowerCase());
          String unit = input[1].toLowerCase();
          if      (unit.startsWith("km/h")) return val;
          else if (unit.startsWith("kt")) return 1.852 * val;
          else if (unit.startsWith("mph")) return 1.60934 *val;
          else if (unit.startsWith("m/s")) return 3.6 *val;
          else if (unit.startsWith("fps")) return 1.09728 *val;
          else if (unit.startsWith("f/s")) return 1.09728 *val;
          else return val;
        }
      }

      public boolean handleEvent(Event evt) {
        Double V2,V3 ;
        double v2,v3 ;
        float fl1 ;
        int i1,i2,i3 ;
        boolean recomp_all_parts = false;


        if(evt.id == Event.ACTION_EVENT) {
          double new_pitch = Double.valueOf(fAoA.getText()).doubleValue() ;
          if (new_pitch != craft_pitch) recomp_all_parts = true;
          craft_pitch = new_pitch;

          double speed = Double.valueOf(f1.getText()).doubleValue() ;
          if (speed != velocity) recomp_all_parts = true;

          velocity = speed;
          if(speed < v_mn) {
            velocity = speed = v_mn ;
            fl1 = (float) speed ;
            f1.setText(String.valueOf(fl1)) ;
          }
          if(speed > v_mx) {
            velocity = speed = v_mx ;
            fl1 = (float) speed ;
            f1.setText(String.valueOf(fl1)) ;
          }

          V2 = Double.valueOf(f2.getText()) ;
          v2 = V2.doubleValue() ;

          // alt = v2 ;
          // if(v2 < al_mn) {
          //   alt = v2 = al_mn ;
          //   fl1 = (float) v2 ;
          //   f2.setText(String.valueOf(fl1)) ;
          // }
          // if(v2 > al_mx) {
          //   alt = v2 = al_mx ;
          //   fl1 = (float) v2 ;
          //   f2.setText(String.valueOf(fl1)) ;
          // 

          double LOAD_MIN = 0, LOAD_MAX = 3000; // N
          
          v2 = Math.max(LOAD_MIN, Math.min(v2, LOAD_MAX));
          f2.setText(String.valueOf(v2));
    
          i1 = (int) (((speed - v_mn)/(v_mx-v_mn))*1000.) ;

          // i2 = (int) (((v2 - al_mn)/(al_mx-al_mn))*1000.) ;
          i2 = (int) (((v2 - LOAD_MIN)/(LOAD_MAX-LOAD_MIN))*1000.) ;
     
          s1.setValue(i1) ;
          s2.setValue(i2) ;

          //  set limits on spin
          if(foil_is_cylinder_or_ball(foil)) cyl.setLims() ;

          computeFlow() ;

          if (recomp_all_parts) 
            con.recomp_all_parts();

          return true ;
        }
        if(evt.id == Event.SCROLL_ABSOLUTE) {
          this.handleBar(evt) ;
          return true ;
        }
        if(evt.id == Event.SCROLL_LINE_DOWN) {
          this.handleBar(evt) ;
          return true ;
        }
        if(evt.id == Event.SCROLL_LINE_UP) {
          this.handleBar(evt) ;
          return true ;
        }
        if(evt.id == Event.SCROLL_PAGE_DOWN) {
          this.handleBar(evt) ;
          return true ;
        }
        if(evt.id == Event.SCROLL_PAGE_UP) {
          this.handleBar(evt) ;
          return true ;
        }
        else return false ;
      }

      public void handleBar(Event evt) {
        int i1,i2 ;
        double v1,v2 ;
        float fl1,fl2 ;
        boolean recomp_all_parts = false;

        // Input for computations
        i1 = s1.getValue() ;
        i2 = s2.getValue() ;


        double new_velocity   = v1 = i1 * (v_mx - v_mn)/ 1000. + v_mn ;
        if (new_velocity != velocity) recomp_all_parts = true;
        velocity = new_velocity;

        alt    = v2 = i2 * (al_mx - al_mn)/ 1000. + al_mn ;

        double new_pitch = sAoA.getValue() * (ang_mx - ang_mn)/ 1000. + ang_mn ;
        if (new_pitch != craft_pitch) recomp_all_parts = true;          
        craft_pitch = new_pitch;
        fAoA.setText(String.valueOf((float)new_pitch)) ;

        if (recomp_all_parts) 
          con.recomp_all_parts();

        fl1 = (float) v1 ;
        fl2 = (float) v2 ;

        f1.setText(String.valueOf(fl1)) ;
        f2.setText(String.valueOf(fl2)) ;

        //  set limits on spin
        if(foil_is_cylinder_or_ball(foil)) cyl.setLims() ;

        computeFlow() ;
      } // handle bar

    }  // Flight

    class Env extends Panel {
      FoilBoardWithProblems app ;
      Inl inl ;
      Inr inr ;

      Env(FoilBoardWithProblems target) {

        app = target ;
        setLayout(new GridLayout(1,2,5,5)) ;

        inl = new Inl(app) ;
        inr = new Inr(app) ;

        add(inl) ;
        add(inr) ;
      }

      class Inl extends Panel {
        FoilBoardWithProblems app ;
        TextField f2, o1,o3, o5 ;
        Label l2, la1,la2 ;
        Label lo1,lo3,lo5 ;
     
        Inl (FoilBoardWithProblems target) {
    
          app = target ;
          setLayout(new GridLayout(7,2,2,10)) ;

          la1 = new Label("Environmental", Label.RIGHT) ;
          la1.setForeground(Color.blue) ;
          la2 = new Label("Settings", Label.LEFT) ;
          la2.setForeground(Color.blue) ;

          l2 = new Label("Altitude ft", Label.CENTER) ;
          f2 = new TextField("0.0",5) ;

          lo1 = new Label("Press lb/in2", Label.CENTER) ;
          o1 = new TextField("0.0",5) ;
          o1.setBackground(Color.black) ;
          o1.setForeground(Color.yellow) ;

          lo3 = new Label("Dens slug/ft3", Label.CENTER) ;
          o3 = new TextField("0.00027",5) ;
          o3.setBackground(Color.black) ;
          o3.setForeground(Color.yellow) ;

          lo5 = new Label("Dyn Press lb/ft2", Label.CENTER) ;
          o5 = new TextField("100.",5) ;
          o5.setBackground(Color.black) ;
          o5.setForeground(Color.yellow) ;

          add(la1) ;
          add(la2) ;

          add(l2) ;
          add(f2) ;

          add(lo1) ;
          add(o1) ;

          add(lo3) ;
          add(o3) ;

          add(lo5) ;
          add(o5) ;
        }

        public boolean handleEvent(Event evt) {
          Double V2,V3 ;
          double v2,v3 ;
          float fl1 ;
          int i1,i2,i3 ;
          boolean recomp_all_parts = false;


          if(evt.id == Event.ACTION_EVENT) {
            V2 = Double.valueOf(f2.getText()) ;
            v2 = V2.doubleValue() ;

            alt = v2 ;
            if(v2 < al_mn) {
              alt = v2 = al_mn ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
            }
            if(v2 > al_mx) {
              alt = v2 = al_mx ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
            }
    
            i2 = (int) (((v2 - al_mn)/(al_mx-al_mn))*1000.) ;
     
            inr.altitude.setValue(i2) ;

            if (planet == 3) {    // read in the pressure
              double pressure = Double.valueOf(o1.getText()).doubleValue() ;
              ps0 = pressure /pconv * 2116. ;
              if(ps0 < .5) {
                ps0 = .5 ;
                pressure = ps0 / 2116. * pconv ;
                fl1 = (float) pressure ;
                o1.setText(String.valueOf(fl1)) ;
              }
              if(ps0 > 5000.) {
                ps0 = 5000. ;
                pressure = ps0 / 2116. * pconv ;
                fl1 = (float) pressure ;
                o1.setText(String.valueOf(fl1)) ;
              }
            }

            if (planet == 4) {    // read in the density
              double density = Double.valueOf(o3.getText()).doubleValue() ;
              rho = density ;
              if (lunits == METRIC) rho = density /515.4 ;
              if(rho < .000001) {
                rho = .000001 ;
                density = rho;
                if (lunits == METRIC) density = rho * 515.4 ;
                fl1 = (float) density ;
                o3.setText(String.valueOf(fl1)) ;
              }
              if(rho > 3.0) {
                rho = 3. ;
                density = rho;
                if (lunits == METRIC) density = rho * 515.4 ;
                fl1 = (float) density ;
                o3.setText(String.valueOf(fl1)) ;
              }
            }

            //  set limits on spin
            if(foil_is_cylinder_or_ball(foil)) cyl.setLims() ;

            computeFlow() ;

            if (recomp_all_parts) 
              con.recomp_all_parts();

            return true ;
          }
          else return false ;
        } // Handler
      }  // Inl

      class Inr extends Panel {
        FoilBoardWithProblems app ;
        Scrollbar altitude;
        Choice plntch;
        Inr2 inr2 ;
        Inr3 inr3 ;
        Inr6 inr6 ;

        Inr (FoilBoardWithProblems target) {
          int i1,i2, iAoA ;

          app = target ;
          setLayout(new GridLayout(7,1,2,10)) ;

          i1 = (int) (((100.0 - v_mn)/(v_mx-v_mn))*1000.) ;
          i2 = (int) (((0.0 - al_mn)/(al_mx-al_mn))*1000.) ;
          iAoA = (int) (((0.0 - ang_mn)/(ang_mx-ang_mn))*1000.) ;

          plntch = new Choice() ;
          plntch.addItem("Earth - Average Day") ;
          plntch.addItem("Mars - Average Day");
          plntch.addItem("Water-Const Density");
          plntch.addItem("Specify Air T & P");
          plntch.addItem("Specify Density or Viscosity");
          plntch.addItem("Venus - Surface");
          plntch.setBackground(Color.white) ;
          plntch.setForeground(Color.blue) ;
          plntch.select(0) ;

          inr2 = new Inr2(app) ;
          inr3 = new Inr3(app) ;
          inr6 = new Inr6(app) ;

          add(plntch) ;
          add(inr2) ;
          add(inr3) ;
          add(inr6) ;
        }

        class Inr6 extends Panel {
          FoilBoardWithProblems app ;
          TextField o6;
          Label lo6 ;

          Inr6 (FoilBoardWithProblems target) {
            app = target ;
            setLayout(new GridLayout(1,2,2,10)) ;

            lo6 = new Label("Rel Humid %", Label.LEFT) ;
            o6 = new TextField("0.0",5) ;
            o6.setBackground(Color.white) ;
            o6.setForeground(Color.black) ;

            add(lo6) ;
            add(o6) ;
          }

          public boolean handleEvent(Event evt) {
            Double V1 ;
            double v1 ;
            float fl1 ;
  
            if(evt.id == Event.ACTION_EVENT) {

              V1 = Double.valueOf(o6.getText()) ;
              v1 = V1.doubleValue() ;
              rlhum = v1 ;
              if(rlhum < 0) {
                rlhum = 0 ;
                v1 = rlhum;
                fl1 = (float) v1 ;
                o6.setText(String.valueOf(fl1)) ;
              }
              if(rlhum > 100.0) {
                rlhum = 100. ;
                v1 = rlhum;
                fl1 = (float) v1 ;
                o6.setText(String.valueOf(fl1)) ;
              }

              computeFlow() ;
              return true ;
            }
            else return false ;
          }
        }

        class Inr3 extends Panel {
          FoilBoardWithProblems app ;
          TextField o4;
          Label lo4 ;

          Inr3 (FoilBoardWithProblems target) {
            app = target ;
            setLayout(new GridLayout(1,2,2,10)) ;

            lo4 = new Label("Visc slug/ft-s", Label.LEFT) ;
            o4 = new TextField("0.0",5) ;
            o4.setBackground(Color.black) ;
            o4.setForeground(Color.yellow) ;

            add(lo4) ;
            add(o4) ;
          }

          public boolean handleEvent(Event evt) {
            Double V1 ;
            double v1 ;
            float fl1 ;
  
            if(evt.id == Event.ACTION_EVENT) {

              if (planet == 4) {    // read in viscosity
                V1 = Double.valueOf(o4.getText()) ;
                v1 = V1.doubleValue() ;
                viscos = v1 ;
                if (lunits == METRIC) viscos = v1 /47.87 ;
                if(viscos < .0000001) {
                  viscos = .0000001 ;
                  v1 = viscos;
                  if (lunits == METRIC) v1 = viscos * 47.87 ;
                  fl1 = (float) v1 ;
                  o4.setText(String.valueOf(fl1)) ;
                }
                if(viscos > 3.0) {
                  viscos = 3. ;
                  v1 = viscos;
                  if (lunits == METRIC) v1 = viscos * 47.87 ;
                  fl1 = (float) v1 ;
                  o4.setText(String.valueOf(fl1)) ;
                }
              }

              computeFlow() ;
              return true ;
            }
            else return false ;
          }
        }

        class Inr2 extends Panel {
          FoilBoardWithProblems app ;
          TextField o2;
          Label lo2 ;

          Inr2 (FoilBoardWithProblems target) {
            app = target ;
            setLayout(new GridLayout(1,2,2,10)) ;

            lo2 = new Label("Temp-F", Label.CENTER) ;
            o2 = new TextField("12.5",5) ;
            o2.setBackground(Color.black) ;
            o2.setForeground(Color.yellow) ;

            add(lo2) ;
            add(o2) ;
          }

          public boolean handleEvent(Event evt) {
            Double V1 ;
            double v1 ;
            float fl1 ;

            if(evt.id == Event.ACTION_EVENT) {

              if (planet == 3) {    // read in the temperature
                V1 = Double.valueOf(o2.getText()) ;
                v1 = V1.doubleValue() ;
                ts0 = v1 + 460. ;
                if (lunits == 1) ts0 = (v1 + 273.1)*9.0/5.0 ;
                if(ts0 < 350.) {
                  ts0 = 350. ;
                  v1 = ts0 - 460. ;
                  if (lunits == 1) v1 = ts0*5.0/9.0 - 273.1 ;
                  fl1 = (float) v1 ;
                  o2.setText(String.valueOf(fl1)) ;
                }
                if(ts0 > 660.) {
                  ts0 = 660. ;
                  v1 = ts0 - 460. ;
                  if (lunits == 1) v1 = ts0*5.0/9.0 - 273.1 ;
                  fl1 = (float) v1 ;
                  o2.setText(String.valueOf(fl1)) ;
                }
              }

              computeFlow() ;
              return true ;
            }
            else return false ;
          }
        }

        public boolean handleEvent(Event evt) {
          if(evt.id == Event.ACTION_EVENT) {
            this.handleCho(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_ABSOLUTE) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_LINE_DOWN) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_LINE_UP) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_PAGE_DOWN) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_PAGE_UP) {
            this.handleBar(evt) ;
            return true ;
          }
          else return false ;
        }

        public void handleBar(Event evt) {
          int altitude_int ;
          double v1,v2 ;
          float fl1,fl2 ;
          boolean recomp_all_parts = false;

          // Input for computations
          altitude_int = altitude.getValue() ;

          alt = v2 = altitude_int * (al_mx - al_mn)/ 1000. + al_mn ;

          if (recomp_all_parts) 
            con.recomp_all_parts();

          fl2 = (float) v2 ;

          inl.f2.setText(String.valueOf(fl2)) ;

          //  set limits on spin
          if(foil_is_cylinder_or_ball(foil)) cyl.setLims() ;

          computeFlow() ;
        } // handle bar

        public void handleCho(Event evt) {
          int i1,i2 ;
          double v1,v2 ;
          float fl1,fl2 ;

          planet  = plntch.getSelectedIndex() ;

          if (planet == 2) {
            velocity = 5. ;
            vmax = 50. ;
            if (lunits == 1) vmax = 80. ;
            alt = 0.0 ;
            altmax = 5000. ;
            area = 10.0 ;
            armax = 50. ;
          }
          else {
            vmax = 250. ;
            if (lunits == 1) vmax = 400. ;
            altmax = 50000. ;
            armax = 2500. ;
          }

          if (planet == 0 || planet == 3) {
            inr.inr6.o6.setBackground(Color.white) ;
            inr.inr6.o6.setForeground(Color.black) ;
          }
          if (planet == 1 || planet == 2) {
            inr.inr6.o6.setBackground(Color.black) ;
            inr.inr6.o6.setForeground(Color.yellow) ;
          }
          if (planet == 4 || planet == 6) {
            inr.inr6.o6.setBackground(Color.black) ;
            inr.inr6.o6.setForeground(Color.yellow) ;
          }

          if (planet == 3) {
            inl.o1.setBackground(Color.white) ;
            inl.o1.setForeground(Color.black) ;
            inr.inr2.o2.setBackground(Color.white) ;
            inr.inr2.o2.setForeground(Color.black) ;
          }
          else {
            inl.o1.setBackground(Color.black) ;
            inl.o1.setForeground(Color.yellow) ;
            inr.inr2.o2.setBackground(Color.black) ;
            inr.inr2.o2.setForeground(Color.yellow) ;
          }

          if (planet == 4) {
            inl.o3.setBackground(Color.white) ;
            inl.o3.setForeground(Color.black) ;
            inr.inr3.o4.setBackground(Color.white) ;
            inr.inr3.o4.setForeground(Color.black) ;
          }
          else {
            inl.o3.setBackground(Color.black) ;
            inl.o3.setForeground(Color.yellow) ;
            inr.inr3.o4.setBackground(Color.black) ;
            inr.inr3.o4.setForeground(Color.yellow) ;
          }

          layplt.show(in.grf.l, 
                      foil_is_cylinder_or_ball(foil) ? "second" : "first") ;

          layout.show(out, "first")  ;
          con.bt_plot.setBackground(Color.yellow) ;
          con.bt_probe.setBackground(Color.white) ;
          con.bt_gages.setBackground(Color.white) ;
          con.bt_geom.setBackground(Color.white) ;
          con.bt_data.setBackground(Color.white) ;
          calcrange = 0 ;

          loadInput() ;
        } // handle  choice
      }  // Inr 
    } // Env

    class Shape extends Panel {
      FoilBoardWithProblems app ;
      Inl inl ;
      Inr inr ;   

      Shape (FoilBoardWithProblems target) {

        app = target ;
        setLayout(new GridLayout(1,2,5,5)) ;

        inl = new Inl(app) ;
        inr = new Inr(app) ;

        add(inl) ;
        add(inr) ;
      }

      // what needs be done in general when user altered current foil shape?
      void recompute() {
        cache_t_Cl = cache_t_Cd = null;

        // ???
        // con.switch_to_part(current_part);
        // loadInput() ;

        computeFlow();
      }

      class Inl extends Panel {
        FoilBoardWithProblems app ;
        TextField f1,f2,f3 ;
        Label l1,l2,l3 ;
        Label l01,l02,l03 ;
        Button inl1,inl2,inl3 ;
     
        Inl (FoilBoardWithProblems target) {
      
          app = target ;
          setLayout(new GridLayout(6,2,2,10)) ;

          l01 = new Label("FoilBoardWithProblems", Label.RIGHT) ;
          l01.setForeground(Color.blue) ;
          l02 = new Label("Shape", Label.LEFT) ;
          l02.setForeground(Color.blue) ;

          l1 = new Label("Camber-%c", Label.CENTER) ;
          f1 = new TextField("0.0",5) ;

          l2 = new Label("Thick-%crd", Label.CENTER) ;
          f2 = new TextField("12.5",5) ;

          l3 = new Label("Angle-deg", Label.CENTER) ;
          f3 = new TextField("5.0",5) ;

          l03 = new Label("Basic Shapes:", Label.RIGHT) ;
          l03.setForeground(Color.black) ;

          inl1 = new Button("Symmetric") ;
          inl1.setBackground(Color.yellow) ;
          inl1.setForeground(Color.blue) ;
          inl2 = new Button("Flat Bottom") ;
          inl2.setBackground(Color.white) ;
          inl2.setForeground(Color.blue) ;
          inl3 = new Button("Neg. Camber") ;
          inl3.setBackground(Color.white) ;
          inl3.setForeground(Color.blue) ;

          add(l01) ;
          add(l02) ;

          add(l3) ;
          add(f3) ;

          add(l1) ;
          add(f1) ;

          add(l2) ;
          add(f2) ;
 
          add(l03) ;
          add(inl1) ;
 
          add(inl2) ;
          add(inl3) ;
        }

        // something was done by user
        public boolean action(Event evt, Object arg) {
          Double V1,V2,V3 ;
          double v1,v2,v3 ;
          float fl1 ;
          int i1,i2,i3 ;

          if(evt.target instanceof Button) {
            handleBut (evt,arg) ;
            return true ;
          } else {
            V1 = Double.valueOf(f1.getText()) ;
            v1 = V1.doubleValue() ;
            V2 = Double.valueOf(f2.getText()) ;
            v2 = V2.doubleValue() ;
            V3 = Double.valueOf(f3.getText()) ;
            v3 = V3.doubleValue() ;

            caminpt = v1 ;
            if(v1 < ca_mn) {
              caminpt = v1 = ca_mn ;
              fl1 = (float) v1 ;
              f1.setText(String.valueOf(fl1)) ;
            }
            if(v1 > ca_mx) {
              caminpt = v1 = ca_mx ;
              fl1 = (float) v1 ;
              f1.setText(String.valueOf(fl1)) ;
            }
            camval = caminpt / 25.0 ;

            thkinpt = v2 ;
            if(v2 < thk_mn) {
              thkinpt = v2 = thk_mn ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
            }
            if(v2 > thk_mx) {
              thkinpt = v2 = thk_mx ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
            }
            thkval  = thkinpt / 25.0 ;
    
            alpha_degr = v3 ;
            if(v3 < ang_mn) {
              alpha_degr = v3 = ang_mn  ;
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
            }
            if(v3 > ang_mx) {
              alpha_degr = v3 = ang_mx ;
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
            }

            i1 = (int) (((v1 - ca_mn)/(ca_mx-ca_mn))*1000.) ;
            i2 = (int) (((v2 - thk_mn)/(thk_mx-thk_mn))*1000.) ;
            i3 = (int) (((v3 - ang_mn)/(ang_mx-ang_mn))*1000.) ;
    
            inr.s1.setValue(i1) ;
            inr.s2.setValue(i2) ;
            inr.s3.setValue(i3) ;

            recompute() ;
            return true ;
          }
        } // Handler

        public void handleBut(Event evt, Object arg) {
          float fl1,fl2,fl3 ;
          int i1,i2,i3 ;
          int index ;
          double mapfac; 

          String label = (String)arg ;
   
          foil = FOIL_JOUKOWSKI ;

          if(label.equals("Symmetric")) {
            inl.inl1.setBackground(Color.yellow) ;
            inl.inl2.setBackground(Color.white) ;
            inl.inl3.setBackground(Color.white) ;
            inr.inr1.inb1.setBackground(Color.white) ;
            inr.inr1.inb2.setBackground(Color.white) ;
            inr.inr2.inb3.setBackground(Color.white) ;
            inr.inr2.inb4.setBackground(Color.white) ;
            alpha_degr = 0.0 ;
            caminpt = 0.0 ;
            thkinpt = 12.5 ;
          }

          if(label.equals("Flat Bottom")) {
            inl.inl1.setBackground(Color.white) ;
            inl.inl2.setBackground(Color.yellow) ;
            inl.inl3.setBackground(Color.white) ;
            inr.inr1.inb1.setBackground(Color.white) ;
            inr.inr1.inb2.setBackground(Color.white) ;
            inr.inr2.inb3.setBackground(Color.white) ;
            inr.inr2.inb4.setBackground(Color.white) ;
            alpha_degr = 7.0 ;
            caminpt = 5.0 ;
            thkinpt = 12.5 ;
          }

          if(label.equals("Neg. Camber")) {
            inl.inl1.setBackground(Color.white) ;
            inl.inl2.setBackground(Color.white) ;
            inl.inl3.setBackground(Color.yellow) ;
            inr.inr1.inb1.setBackground(Color.white) ;
            inr.inr1.inb2.setBackground(Color.white) ;
            inr.inr2.inb3.setBackground(Color.white) ;
            inr.inr2.inb4.setBackground(Color.white) ;
            alpha_degr = -7.0 ;
            caminpt = -5.0 ;
            thkinpt = 12.5 ;
          }

          camval = caminpt / 25.0 ;
          thkval = thkinpt / 25.0 ;

          inl.f1.setText(String.valueOf(caminpt)) ;
          inl.f2.setText(String.valueOf(thkinpt)) ;
          inl.f3.setText(String.valueOf(alpha_degr)) ;

          i1 = (int) (((caminpt - ca_mn)/(ca_mx-ca_mn))*1000.) ;
          i2 = (int) (((thkinpt - thk_mn)/(thk_mx-thk_mn))*1000.) ;
          i3 = (int) (((alpha_degr - ang_mn)/(ang_mx-ang_mn))*1000.) ;
    
          inr.s1.setValue(i1) ;
          inr.s2.setValue(i2) ;
          inr.s3.setValue(i3) ;

          inr.shapch.select(FOIL_JOUKOWSKI);
          in.cyl.inr.shapch.select(FOIL_JOUKOWSKI);


          recompute() ;
        }
      }  // Inl 

      class Inr extends Panel {
        FoilBoardWithProblems app ;
        Scrollbar s1,s2,s3;
        Choice shapch ;
        Inr1 inr1 ;
        Inr2 inr2 ;

        Inr (FoilBoardWithProblems target) {
          int i1,i2,i3 ;

          app = target ;
          setLayout(new GridLayout(6,1,2,10)) ;

          inr1 = new Inr1(app) ;
          inr2 = new Inr2(app) ;

          i1 = (int) (((0.0 - ca_mn)/(ca_mx-ca_mn))*1000.) ;
          i2 = (int) (((12.5 - thk_mn)/(thk_mx-thk_mn))*1000.) ;
          i3 = (int) (((alpha_degr - ang_mn)/(ang_mx-ang_mn))*1000.) ;

          s1 = new Scrollbar(Scrollbar.HORIZONTAL,i1,10,0,1000);
          s2 = new Scrollbar(Scrollbar.HORIZONTAL,i2,10,0,1000);
          s3 = new Scrollbar(Scrollbar.HORIZONTAL,i3,10,0,1000);

          shapch = new Choice() ;

          for (int foil_id = 0; foil_id < 100; foil_id++) {
            String descr = foil_descr(foil_id);
            if (descr.equals("N/A")) break;
            shapch.addItem(descr) ;
          }

          shapch.setBackground(Color.white) ;
          shapch.setForeground(Color.blue) ;
          shapch.select(FOIL_JOUKOWSKI) ;

          add(shapch) ;
          add(s3) ;
          add(s1) ;
          add(s2) ;
          add(inr1) ;
          add(inr2) ;
        }

        public boolean handleEvent(Event evt) {
          if(evt.id == Event.ACTION_EVENT) {
            this.handleCho(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_ABSOLUTE) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_LINE_DOWN) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_LINE_UP) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_PAGE_DOWN) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_PAGE_UP) {
            this.handleBar(evt) ;
            return true ;
          }
          else return false ;
        }

        public void handleBar(Event evt) {
          int i1,i2,i3 ;
          double v1,v2,v3 ;
          float fl1,fl2,fl3 ;
              
          // Input for computations
          i1 = s1.getValue() ;
          i2 = s2.getValue() ;
          i3 = s3.getValue() ;

          caminpt = v1 = i1 * (ca_mx - ca_mn)/ 1000. + ca_mn ;
          camval  = caminpt / 25.0 ;
          thkinpt = v2 = i2 * (thk_mx - thk_mn)/ 1000. + thk_mn ;
          thkval  = thkinpt / 25.0 ;
          alpha_degr  = v3 = i3 * (ang_mx - ang_mn)/ 1000. + ang_mn ;

          fl1 = (float) v1 ;
          fl2 = (float) v2 ;
          fl3 = (float) v3 ;

          inl.f1.setText(String.valueOf(fl1)) ;
          inl.f2.setText(String.valueOf(fl2)) ;
          inl.f3.setText(String.valueOf(fl3)) ;
     
          recompute() ;
        }

        public void handleCho(Event evt) {
          int i2 ;
          double v2 ;
          float fl1 ;

          foil  = shapch.getSelectedIndex();
          if (foil_is_cylinder_or_ball(foil)) alpha_degr = 0.0 ;
          if(foil < FOIL_FLAT_PLATE) layin.show(in, "second")  ;
          else if(foil == FOIL_FLAT_PLATE) {
            layin.show(in, "second")  ;
            thkinpt = v2 = thk_mn ;
            thkval  = thkinpt / 25.0 ;
            fl1 = (float) v2 ;
            inl.f2.setText(String.valueOf(fl1)) ;
            i2 = (int) (((v2 - thk_mn)/(thk_mx-thk_mn))*1000.) ;
            inr.s2.setValue(i2) ;
          } else if(foil == FOIL_CYLINDER) {
            layin.show(in, "fifth")  ;
            in.anl.cbt1.setBackground(Color.white) ;
            in.anl.cbt2.setBackground(Color.white) ;
            in.anl.cbt3.setBackground(Color.white) ;
          } else if(foil == FOIL_BALL) {
            span = radius ;
            area = 3.1415926*radius*radius ;
            layin.show(in, "fifth")  ;
            if (viewflg != 0) viewflg = 0 ;
            bdragflag = 1 ;
            in.anl.cbt1.setBackground(Color.yellow) ;
            in.anl.cbt2.setBackground(Color.white) ;
            in.anl.cbt3.setBackground(Color.white) ;
          }
    
          if (!foil_is_cylinder_or_ball(foil)) {
            layplt.show(in.grf.l, "first") ;
            indrag = 1;
            in.anl.bt7.setBackground(Color.yellow) ;
            in.anl.bt8.setBackground(Color.white) ;
            in.anl.cbt1.setBackground(Color.white) ;
            in.anl.cbt2.setBackground(Color.white) ;
            in.anl.cbt3.setBackground(Color.white) ;
          } else {
            layplt.show(in.grf.l, "second") ;
            indrag = 0;
            in.anl.bt7.setBackground(Color.white) ;
            in.anl.bt8.setBackground(Color.yellow) ;
          }

          in.cyl.inr.shapch.select(foil);
          layout.show(out, "first")  ;
          con.bt_plot.setBackground(Color.yellow) ;
          con.bt_probe.setBackground(Color.white) ;
          con.bt_gages.setBackground(Color.white) ;
          con.bt_geom.setBackground(Color.white) ;
          con.bt_data.setBackground(Color.white) ;
          // dispp = 0 ;
          calcrange = 0 ;

          recompute();
        }

        class Inr1 extends Panel {
          FoilBoardWithProblems app ;
          Button inb1,inb2 ;

          Inr1 (FoilBoardWithProblems target) {

            app = target ;
            setLayout(new GridLayout(1,2,2,10)) ;

            inb1 = new Button("High Camber") ;
            inb1.setBackground(Color.white) ;
            inb1.setForeground(Color.blue) ;

            inb2 = new Button("Flat Plate") ;
            inb2.setBackground(Color.white) ;
            inb2.setForeground(Color.blue) ;

            add(inb1) ;
            add(inb2);
          }

          public boolean action(Event evt, Object arg) {

            if(evt.target instanceof Button) {
              handleBut (evt,arg) ;
              return true ;
            }

            else {
              return false ;
            }
          }

          public void handleBut(Event evt, Object arg) {
            float fl1,fl2,fl3 ;
            int i1,i2,i3 ;

            String label = (String)arg ;
   
            if(label.equals("High Camber")) {
              inl.inl1.setBackground(Color.white) ;
              inl.inl2.setBackground(Color.white) ;
              inl.inl3.setBackground(Color.white) ;
              inb1.setBackground(Color.yellow) ;
              inb2.setBackground(Color.white) ;
              inr.inr2.inb3.setBackground(Color.white) ;
              inr.inr2.inb4.setBackground(Color.white) ;
              alpha_degr = 9.0 ;
              caminpt = 15.0 ;
              thkinpt = 12.5 ;
              if (foil >= FOIL_ELLIPTICAL) {
                foil = FOIL_JOUKOWSKI ;
                shapch.select(FOIL_JOUKOWSKI);
                in.cyl.inr.shapch.select(FOIL_JOUKOWSKI);
              }
            }

            if(label.equals("Flat Plate")) {
              inl.inl1.setBackground(Color.white) ;
              inl.inl2.setBackground(Color.white) ;
              inl.inl3.setBackground(Color.white) ;
              inb1.setBackground(Color.white) ;
              inb2.setBackground(Color.yellow) ;
              inr.inr2.inb3.setBackground(Color.white) ;
              inr.inr2.inb4.setBackground(Color.white) ;
              foil = FOIL_FLAT_PLATE ;
              alpha_degr = 5.0 ;
              caminpt = 0.0 ;
              thkinpt = 1.0 ;
              shapch.select(FOIL_FLAT_PLATE);
              in.cyl.inr.shapch.select(FOIL_FLAT_PLATE);
            }

            camval = caminpt / 25.0 ;
            thkval = thkinpt / 25.0 ;

            inl.f1.setText(String.valueOf(caminpt)) ;
            inl.f2.setText(String.valueOf(thkinpt)) ;
            inl.f3.setText(String.valueOf(alpha_degr)) ;

            i1 = (int) (((caminpt - ca_mn)/(ca_mx-ca_mn))*1000.) ;
            i2 = (int) (((thkinpt - thk_mn)/(thk_mx-thk_mn))*1000.) ;
            i3 = (int) (((alpha_degr - ang_mn)/(ang_mx-ang_mn))*1000.) ;
    
            inr.s1.setValue(i1) ;
            inr.s2.setValue(i2) ;
            inr.s3.setValue(i3) ;

            recompute() ;
          }
        }  // Inr1

        class Inr2 extends Panel {
          FoilBoardWithProblems app ;
          Button inb3,inb4 ;

          Inr2 (FoilBoardWithProblems target) {

            app = target ;
            setLayout(new GridLayout(1,2,2,10)) ;

            inb3 = new Button("Ellipse") ;
            inb3.setBackground(Color.white) ;
            inb3.setForeground(Color.blue) ;

            inb4 = new Button("Curve Plate") ;
            inb4.setBackground(Color.white) ;
            inb4.setForeground(Color.blue) ;

            add(inb3) ;
            add(inb4);
          }

          public boolean action(Event evt, Object arg) {

            if(evt.target instanceof Button) {
              handleBut (evt,arg) ;
              return true ;
            }

            else {
              return false ;
            }
          }

          public void handleBut(Event evt, Object arg) {
            float fl1,fl2,fl3 ;
            int i1,i2,i3 ;

            String label = (String)arg ;
   
            if(label.equals("Ellipse")) {
              inl.inl1.setBackground(Color.white) ;
              inl.inl2.setBackground(Color.white) ;
              inl.inl3.setBackground(Color.white) ;
              inr.inr1.inb1.setBackground(Color.white) ;
              inr.inr1.inb2.setBackground(Color.white) ;
              inb3.setBackground(Color.yellow) ;
              inb4.setBackground(Color.white) ;
              foil = FOIL_ELLIPTICAL ;
              alpha_degr = 0.0 ;
              caminpt = 0.0 ;
              thkinpt = 12.5 ;
              shapch.select(FOIL_ELLIPTICAL);
              in.cyl.inr.shapch.select(FOIL_ELLIPTICAL);
            }

            if(label.equals("Curve Plate")) {
              inl.inl1.setBackground(Color.white) ;
              inl.inl2.setBackground(Color.white) ;
              inl.inl3.setBackground(Color.white) ;
              inr.inr1.inb1.setBackground(Color.white) ;
              inr.inr1.inb2.setBackground(Color.white) ;
              inb3.setBackground(Color.white) ;
              inb4.setBackground(Color.yellow) ;
              foil = FOIL_FLAT_PLATE ;
              alpha_degr = 5.0 ;
              caminpt = 5.0 ;
              thkinpt = 1.0 ;
              shapch.select(FOIL_FLAT_PLATE);
              in.cyl.inr.shapch.select(FOIL_FLAT_PLATE);
            }

            camval = caminpt / 25.0 ;
            thkval = thkinpt / 25.0 ;

            inl.f1.setText(String.valueOf(caminpt)) ;
            inl.f2.setText(String.valueOf(thkinpt)) ;
            inl.f3.setText(String.valueOf(alpha_degr)) ;

            i1 = (int) (((caminpt - ca_mn)/(ca_mx-ca_mn))*1000.) ;
            i2 = (int) (((thkinpt - thk_mn)/(thk_mx-thk_mn))*1000.) ;
            i3 = (int) (((alpha_degr - ang_mn)/(ang_mx-ang_mn))*1000.) ;
    
            inr.s1.setValue(i1) ;
            inr.s2.setValue(i2) ;
            inr.s3.setValue(i3) ;

            recompute() ;
          }
        }  // Inr2
      }  // Inr
    }  // Shape 

    class Siz extends Panel {
      FoilBoardWithProblems app ;
      Inl inl ;
      Inr inr ;

      Siz (FoilBoardWithProblems target) {

        app = target ;
        setLayout(new GridLayout(1,2,5,5)) ;

        inl = new Inl(app) ;
        inr = new Inr(app) ;

        add(inl) ;
        add(inr) ;
      }

      class Inl extends Panel {
        FoilBoardWithProblems app ;
        TextField f1,f2,f3,o4 ;
        Label l1,l2,l3,l4 ;
        Label l01,l02 ;
    
        Inl (FoilBoardWithProblems target) {
   
          app = target ;
          setLayout(new GridLayout(5,2,2,10)) ;

          l01 = new Label("Wing", Label.RIGHT) ;
          l01.setForeground(Color.blue) ;
          l02 = new Label("Size", Label.LEFT) ;
          l02.setForeground(Color.blue) ;

          l1 = new Label("Chord-ft", Label.CENTER) ;
          f1 = new TextField("5.0",5) ;

          l2 = new Label("Span-ft", Label.CENTER) ;
          f2 = new TextField("20.0",5) ;

          l3 = new Label("Area-sq ft", Label.CENTER) ;
          f3 = new TextField("100.0",5) ;

          l4 = new Label("Aspect Rat", Label.CENTER) ;
          o4 = new TextField("0.0",5) ;
          o4.setBackground(Color.black) ;
          o4.setForeground(Color.yellow) ;

          add(l01) ;
          add(l02) ;

          add(l1) ;
          add(f1) ;

          add(l2) ;
          add(f2) ;

          add(l3) ;
          add(f3) ;

          add(l4) ;
          add(o4) ;
        }

        public boolean handleEvent(Event evt) {
          Double V1,V2,V3 ;
          double v1,v2,v3 ;
          float fl1 ;
          int i1,i2,i3,choice ;

          if(evt.id == Event.ACTION_EVENT) {
            V1 = Double.valueOf(f1.getText()) ;
            v1 = V1.doubleValue() ;
            V2 = Double.valueOf(f2.getText()) ;
            v2 = V2.doubleValue() ;
            V3 = Double.valueOf(f3.getText()) ;
            v3 = V3.doubleValue() ;

            chord = v1 ;
            System.out.println("-- chord taken from TF: " + chord);
            if(v1 < chrd_mn) {
              chord = v1 = chrd_mn ;
              fl1 = (float) v1 ;
              f1.setText(String.valueOf(fl1)) ;
            }
            if(v1 > chrd_mx) {
              chord = v1 = chrd_mx ;
              fl1 = (float) v1 ;
              f1.setText(String.valueOf(fl1)) ;
            }

            span = v2 ;
            if(v2 < span_mn) {
              span = v2 = span_mn ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
            }
            if(v2 > span_mx) {
              span = v2 = span_mx ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
            }
   
            area = v3 ;
            if(v3 < ar_mn) {
              area = v3 = ar_mn  ;
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
            }
            if(v3 > ar_mx) {
              area = v3 = ar_mx ;
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
            }

            // keeping consistent
            choice = 0 ;
            if (chord >= (chrdold+.01) || chord <= (chrdold-.01)) choice = 1;
            if (span >= (span_old+.1) || span <= (span_old-.1))   choice = 2;
            if (area >= (arold+1.0) || area <= (arold-1.0))       choice = 3;

            switch(choice) {
            case 1: {          // chord changed
              if (chord < span || 
                  current_part == fuse) { // allow fuse to be long and narrow
                v3 = span * chord ;
                aspr = span*span/v3 ;
              }
              else { // (chord >= span)
                v2 = chord ;
                aspr = 1.0 ;
                v3 = v2 * chord ;
                fl1 = (float) v2 ;
                f2.setText(String.valueOf(fl1)) ;
                span_old = span = v2 ;
              }
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
              //                  if (viewflg == 2) {
              fact = fact * chord/chrdold ;
              //                  }
              chrdold = chord ;
              arold = area = v3 ;
              break ;
            }
            case 2: {          // span changed
              if (span > chord || current_part == fuse ) { // allow fuse to be long and narrow
                v3 = span * chord ;
                aspr = span*span/v3 ;
              }
              else { // (span <= chord)
                v1 = span ;
                aspr = 1.0 ;
                v3 = v1 * span ;
                fl1 = (float) v1 ;
                f1.setText(String.valueOf(fl1)) ;
                chord = v1 ;
                //                     if (viewflg == 2) {
                fact = fact * chord/chrdold ;
                //                     }
                chrdold = chord ;
              }
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
              span_old = span ;
              arold = area = v3 ;
              break ;
            }
            case 3: {          // area changed
              v2 = Math.sqrt(area*aspr) ;
              v1 = area / v2 ;
              fl1 = (float) v1 ;
              f1.setText(String.valueOf(fl1)) ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
              chord = v1 ;
              //                   if (viewflg == 2) {
              fact = fact * chord/chrdold ;
              //                   }
              chrdold = chord ;
              span_old = span = v2 ;
              arold = area ;
            }
            }
            spanfac = (int)(2.0*fact*aspr*.3535) ;

            i1 = (int) (((v1 - chrd_mn)/(chrd_mx-chrd_mn))*1000.) ;
            i2 = (int) (((v2 - span_mn)/(span_mx-span_mn))*1000.) ;
            i3 = (int) (((v3 - ar_mn)/(ar_mx-ar_mn))*1000.) ;
   
            inr.sld1.s1.setValue(i1) ;
            inr.sld2.s2.setValue(i2) ;
            inr.sld3.s3.setValue(i3) ;

            computeFlow() ;
            return true ;
          }
          else return false ;
        } // Handler
      }  // Inl 

      class Inr extends Panel {
        FoilBoardWithProblems app ;
        Sld1 sld1 ;
        Sld2 sld2 ;
        Sld3 sld3 ;

        Inr (FoilBoardWithProblems target) {
          int i1,i2,i3 ;

          app = target ;
          setLayout(new GridLayout(5,1,2,10)) ;

          i1 = (int) (((chord - chrd_mn)/(chrd_mx-chrd_mn))*1000.) ;
          i2 = (int) (((span - span_mn)/(span_mx-span_mn))*1000.) ;
          i3 = (int) (((area - ar_mn)/(ar_mx-ar_mn))*1000.) ;

          sld1 = new Sld1(app) ;
          sld2 = new Sld2(app) ;
          sld3 = new Sld3(app) ;

          add(new Label(" ", Label.CENTER)) ;
          add(sld1) ;
          add(sld2) ;
          add(sld3) ;
          add(new Label(" ", Label.CENTER)) ;
        }

        class Sld1 extends Panel {  // chord slider
          FoilBoardWithProblems app ;
          Scrollbar s1 ; 

          Sld1 (FoilBoardWithProblems target) {
            int i1 ;

            app = target ;
            setLayout(new GridLayout(1,1,0,0)) ;

            i1 = (int) (((chord - chrd_mn)/(chrd_mx-chrd_mn))*1000.) ;

            s1 = new Scrollbar(Scrollbar.HORIZONTAL,i1,10,0,1000);

            add(s1) ;
          }

          public boolean handleEvent(Event evt) {
            if(evt.id == Event.ACTION_EVENT) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_ABSOLUTE) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_LINE_DOWN) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_LINE_UP) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_DOWN) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_UP) {
              this.handleBar(evt) ;
              return true ;
            }
            else return false ;
          }

          public void handleBar(Event evt) {
            int i1,i3 ;
            double v1 ;
            float fl1,fl3 ;

            // Input for computations
            i1 = s1.getValue() ;

            chord  = v1 = i1 * (chrd_mx - chrd_mn)/ 1000. + chrd_mn ;

            if (chord >= span && current_part != fuse) {  // limit apsect ratio to 1.0 except for fuse
              chord = v1 = span ;
              i1 = (int) (((chord - chrd_mn)/(chrd_mx-chrd_mn))*1000.) ;
              s1.setValue(i1) ;
            }

            area = span * chord ;
            aspr = span*span/area ;
            i3 = (int) (((area - ar_mn)/(ar_mx-ar_mn))*1000.) ;
            sld3.s3.setValue(i3) ;

            //               if (viewflg == 2) {
            fact = fact * chord/chrdold ;
            //               }

            spanfac = (int)(2.0*fact*aspr*.3535) ;

            arold = area ;
            chrdold = chord ;

            fl1 = (float) v1 ;
            fl3 = (float) area ;

            inl.f1.setText(String.valueOf(fl1)) ;
            inl.f3.setText(String.valueOf(fl3)) ;
       
            computeFlow() ;
          }  // handler for scroll
        }  // sld1

        class Sld2 extends Panel {  // span slider
          FoilBoardWithProblems app ;
          Scrollbar s2 ; 

          Sld2 (FoilBoardWithProblems target) {
            int i2 ;

            app = target ;
            setLayout(new GridLayout(1,1,0,0)) ;

            i2 = (int) (((span - span_mn)/(span_mx-span_mn))*1000.) ;

            s2 = new Scrollbar(Scrollbar.HORIZONTAL,i2,10,0,1000);

            add(s2) ;
          }

          public boolean handleEvent(Event evt) {
            if(evt.id == Event.ACTION_EVENT) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_ABSOLUTE) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_LINE_DOWN) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_LINE_UP) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_DOWN) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_UP) {
              this.handleBar(evt) ;
              return true ;
            }
            else return false ;
          }

          public void handleBar(Event evt) {
            int i2,i3 ;
            double v2 ;
            float fl2,fl3 ;
  
            // Input for computations
            i2 = s2.getValue() ;

            span   = v2 = i2 * (span_mx - span_mn)/ 1000. + span_mn ;

            if (span <= chord && current_part != fuse) {  // limit apsect ratio to 1.0 except for fuse
              span = v2 = chord ;
              i2 = (int) (((span - span_mn)/(span_mx-span_mn))*1000.) ;
              s2.setValue(i2) ;
            }

            area = span * chord ;
            aspr = span*span/area ;
            i3 = (int) (((area - ar_mn)/(ar_mx-ar_mn))*1000.) ;
            sld3.s3.setValue(i3) ;

            arold = area ;
            span_old = span ;

            spanfac = (int)(2.0*fact*aspr*.3535) ;

            fl2 = (float) v2 ;
            fl3 = (float) area ;
  
            inl.f2.setText(String.valueOf(fl2)) ;
            inl.f3.setText(String.valueOf(fl3)) ;
          
            computeFlow() ;
          }  // handler for scroll
        }  // sld2

        class Sld3 extends Panel {  // area slider
          FoilBoardWithProblems app ;
          Scrollbar s3 ; 
 
          Sld3 (FoilBoardWithProblems target) {
            int i3 ;
 
            app = target ;
            setLayout(new GridLayout(1,1,0,0)) ;
  
            i3 = (int) (((area - ar_mn)/(ar_mx-ar_mn))*1000.) ;
 
            s3 = new Scrollbar(Scrollbar.HORIZONTAL,i3,10,0,1000);

            add(s3) ;
          }

          public boolean handleEvent(Event evt) {
            if(evt.id == Event.ACTION_EVENT) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_ABSOLUTE) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_LINE_DOWN) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_LINE_UP) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_DOWN) {
              this.handleBar(evt) ;
              return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_UP) {
              this.handleBar(evt) ;
              return true ;
            }
            else return false ;
          }
 
          public void handleBar(Event evt) {
            int i1,i2,i3 ;
            double v1,v2,v3 ;
            float fl1,fl2,fl3 ;
 
            // Input for computations
            i3 = s3.getValue() ;

            area   = v3 = i3 * (ar_mx - ar_mn)/ 1000. + ar_mn ;
 
            v2 = span = Math.sqrt(area*aspr) ;
            v1 = chord = area / v2 ;
            i1 = (int) (((v1 - chrd_mn)/(chrd_mx-chrd_mn))*1000.) ;
            i2 = (int) (((v2 - span_mn)/(span_mx-span_mn))*1000.) ;
            sld1.s1.setValue(i1) ;
            sld2.s2.setValue(i2) ;

            //                if (viewflg == 2) {
            fact = fact * chord/chrdold ;
            //                }
            spanfac = (int)(2.0*fact*aspr*.3535) ;

            arold = area ;
            span_old = span ;
            chrdold = chord ;

            fl1 = (float) v1 ;
            fl2 = (float) v2 ;
            fl3 = (float) v3 ;

            inl.f1.setText(String.valueOf(fl1)) ;
            inl.f2.setText(String.valueOf(fl2)) ;
            inl.f3.setText(String.valueOf(fl3)) ;
        
            computeFlow() ;
          }  // handler for scroll
        }  // sld3
      }     // Inr
    }  // Siz 

    class Cyl extends Panel {
      FoilBoardWithProblems app ;
      Inl inl ;
      Inr inr ;

      Cyl (FoilBoardWithProblems target) {

        app = target ;
        setLayout(new GridLayout(1,2,5,5)) ;

        inl = new Inl(app) ;
        inr = new Inr(app) ;

        add(inl) ;
        add(inr) ;
      }

      public void setLims() {
        Double V1 ;
        double v1 ;
        float fl1 ;
        int i1 ;

        spin_mx = 2.75 * velocity/vconv /(radius/lconv) ;
        spin_mn = -2.75 * velocity/vconv/(radius/lconv) ;
        if(spin*60.0 < spin_mn) {
          spin = spin_mn/60.0 ;
          fl1 = (float) (spin*60.0)  ;
          inl.f1.setText(String.valueOf(fl1)) ;
        }
        if(spin*60.0 > spin_mx) {
          spin = spin_mx/60.0 ;
          fl1 = (float) (spin*60.0)  ;
          inl.f1.setText(String.valueOf(fl1)) ;
        }
        i1 = (int) (((60*spin - spin_mn)/(spin_mx-spin_mn))*1000.) ;
        inr.s1.setValue(i1) ;
      }

      class Inl extends Panel {
        FoilBoardWithProblems app ;
        TextField f1,f2,f3 ;
        Label l1,l2,l3 ;
        Label l01,l02 ;
     
        Inl (FoilBoardWithProblems target) {
     
          app = target ;
          setLayout(new GridLayout(6,2,2,10)) ;

          l01 = new Label("Cylinder-", Label.RIGHT) ;
          l01.setForeground(Color.blue) ;
          l02 = new Label("Ball Input", Label.LEFT) ;
          l02.setForeground(Color.blue) ;

          l1 = new Label("Spin rpm", Label.CENTER) ;
          f1 = new TextField("0.0",5) ;

          l2 = new Label("Radius ft", Label.CENTER) ;
          f2 = new TextField(".5",5) ;

          l3 = new Label("Span ft", Label.CENTER) ;
          f3 = new TextField("5.0",5) ;

          add(l01) ;
          add(l02) ;

          add(l1) ;
          add(f1) ;

          add(l2) ;
          add(f2) ;

          add(l3) ;
          add(f3) ;

          add(new Label(" ", Label.CENTER)) ;
          add(new Label(" ", Label.CENTER)) ;

          add(new Label(" ", Label.CENTER)) ;
          add(new Label(" ", Label.CENTER)) ;
        }

        public boolean handleEvent(Event evt) {
          Double V1,V2,V3 ;
          double v1,v2,v3 ;
          float fl1 ;
          int i1,i2,i3 ;

          if(evt.id == Event.ACTION_EVENT) {
            V1 = Double.valueOf(f1.getText()) ;
            v1 = V1.doubleValue() ;
            V2 = Double.valueOf(f2.getText()) ;
            v2 = V2.doubleValue() ;
            V3 = Double.valueOf(f3.getText()) ;
            v3 = V3.doubleValue() ;

            spin = v1 ;
            if(v1 < spin_mn) {
              spin = v1 = spin_mn ;
              fl1 = (float) v1 ;
              f1.setText(String.valueOf(fl1)) ;
            }
            if(v1 > spin_mx) {
              spin = v1 = spin_mx ;
              fl1 = (float) v1 ;
              f1.setText(String.valueOf(fl1)) ;
            }
            spin = spin/60.0 ;

            radius = v2 ;
            if(v2 < rad_mn) {
              radius = v2 = rad_mn ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
            }
            if(v2 > rad_mx) {
              radius = v2 = rad_mx ;
              fl1 = (float) v2 ;
              f2.setText(String.valueOf(fl1)) ;
            }
            cyl.setLims() ;
   
            span = v3 ;
            if (foil == FOIL_BALL) {
              span = v3 = radius ;
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
            }
            if(v3 < span_mn) {
              span = v3 = span_mn ;
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
            }
            if(v3 > span_mx) {
              span = v3 = span_mx ;
              fl1 = (float) v3 ;
              f3.setText(String.valueOf(fl1)) ;
            }
            spanfac = (int)(fact*span/radius*.3535) ;
            area = 2.0*radius*span ;
            if (foil == FOIL_BALL) area = 3.1415926 * radius * radius ;

            i1 = (int) (((v1 - spin_mn)/(spin_mx-spin_mn))*1000.) ;
            i2 = (int) (((v2 - rad_mn)/(rad_mx-rad_mn))*1000.) ;
            i3 = (int) (((v3 - span_mn)/(span_mx-span_mn))*1000.) ;
   
            inr.s1.setValue(i1) ;
            inr.s2.setValue(i2) ;
            inr.s3.setValue(i3) ;

            computeFlow() ;
            return true ;
          }
          else return false ;
        } // Handler
      }  // Inl 

      class Inr extends Panel {
        FoilBoardWithProblems app ;
        Scrollbar s1,s2,s3;
        Choice shapch ;

        Inr (FoilBoardWithProblems target) {
          int i1,i2,i3 ;

          app = target ;
          setLayout(new GridLayout(6,1,2,10)) ;

          i1 = (int) (((spin*60.0 - spin_mn)/(spin_mx-spin_mn))*1000.) ;
          i2 = (int) (((radius - rad_mn)/(rad_mx-rad_mn))*1000.) ;
          i3 = (int) (((span - span_mn)/(span_mx-span_mn))*1000.) ;

          s1 = new Scrollbar(Scrollbar.HORIZONTAL,i1,10,0,1000);
          s2 = new Scrollbar(Scrollbar.HORIZONTAL,i2,10,0,1000);
          s3 = new Scrollbar(Scrollbar.HORIZONTAL,i3,10,0,1000);

          shapch = new Choice() ;
          shapch.addItem("Joukowski foil") ;
          shapch.addItem("NACA 4-series foil") ;
          shapch.addItem("NACA 63xyz foil") ;
          shapch.addItem("Aquila 9.3% foil") ;
          shapch.addItem("NACA_63_412") ;
          shapch.addItem("Moth Bladerider") ;
          shapch.addItem("Ellipse");
          shapch.addItem("Plate");
          shapch.addItem("Cylinder");
          shapch.addItem("Ball");
          shapch.setBackground(Color.white) ;
          shapch.setForeground(Color.blue) ;
          shapch.select(FOIL_JOUKOWSKI) ;

          add(shapch) ;
          add(s1) ;
          add(s2) ;
          add(s3) ;
          add(new Label(" ", Label.CENTER)) ;
          add(new Label(" ", Label.CENTER)) ;
        }

        public boolean handleEvent(Event evt) {
          if(evt.id == Event.ACTION_EVENT) {
            this.handleCho(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_ABSOLUTE) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_LINE_DOWN) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_LINE_UP) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_PAGE_DOWN) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_PAGE_UP) {
            this.handleBar(evt) ;
            return true ;
          }
          else return false ;
        }

        public void handleBar(Event evt) {
          int i1,i2,i3 ;
          double v1,v2,v3 ;
          float fl1,fl2,fl3 ;
              
          // Input for computations
          i1 = s1.getValue() ;
          i2 = s2.getValue() ;
          i3 = s3.getValue() ;

          spin = v1 = i1 * (spin_mx - spin_mn)/ 1000. + spin_mn ;
          spin = spin / 60.0 ;
          radius = v2 = i2 * (rad_mx - rad_mn)/ 1000. + rad_mn ;
          span = v3 = i3 * (span_mx - span_mn)/ 1000. + span_mn ;
          if (foil == FOIL_BALL) span = v3 = radius ;
          spanfac = (int)(fact*span/radius*.3535) ;
          area = 2.0*radius*span ;
          if (foil == FOIL_BALL) area = 3.1415926 * radius * radius ;
          cyl.setLims() ;

          fl1 = (float) v1 ;
          fl2 = (float) v2 ;
          fl3 = (float) v3 ;

          inl.f1.setText(String.valueOf(fl1)) ;
          inl.f2.setText(String.valueOf(fl2)) ;
          inl.f3.setText(String.valueOf(fl3)) ;
      
          computeFlow() ;
        }

        public void handleCho(Event evt) {
          int i2 ;
          double v2 ;
          float fl1 ;

          foil = shapch.getSelectedIndex();
          if (foil_is_cylinder_or_ball(foil)) alpha_degr = 0.0 ;
          if(foil < FOIL_FLAT_PLATE) layin.show(in, "second")  ;
          else if(foil == FOIL_FLAT_PLATE) {
            layin.show(in, "second")  ;
            thkinpt = v2 = thk_mn ;
            thkval  = thkinpt / 25.0 ;
            fl1 = (float) v2 ;
            in.shp.inl.f2.setText(String.valueOf(fl1)) ;
            i2 = (int) (((v2 - thk_mn)/(thk_mx-thk_mn))*1000.) ;
            in.shp.inr.s2.setValue(i2) ;
          } else if(foil == FOIL_CYLINDER) {
            layin.show(in, "fifth")  ;
            in.anl.cbt1.setBackground(Color.white) ;
            in.anl.cbt2.setBackground(Color.white) ; 
            in.anl.cbt3.setBackground(Color.white) ; 
          } else if(foil == FOIL_BALL) {
            span = radius ;
            area = 3.1415926*radius*radius ;
            layin.show(in, "fifth")  ;
            if (viewflg != 0) viewflg = 0 ;
            bdragflag = 1;
            in.anl.cbt1.setBackground(Color.yellow) ;
            in.anl.cbt2.setBackground(Color.white) ; 
            in.anl.cbt3.setBackground(Color.white) ; 
          }
     
          if (!foil_is_cylinder_or_ball(foil)) {
              layplt.show(in.grf.l, "first") ;
            indrag = 1 ;
            in.anl.bt7.setBackground(Color.yellow) ;
            in.anl.bt8.setBackground(Color.white) ;
            in.anl.cbt1.setBackground(Color.white) ;
            in.anl.cbt2.setBackground(Color.white) ; 
            in.anl.cbt3.setBackground(Color.white) ; 
          } else {
            layplt.show(in.grf.l, "second") ;
            indrag = 0 ;
            in.anl.bt7.setBackground(Color.white) ;
            in.anl.bt8.setBackground(Color.yellow) ;
          }

          in.shp.inr.shapch.select(foil);
          layout.show(out, "first")  ;
          con.bt_plot.setBackground(Color.yellow) ;
          con.bt_probe.setBackground(Color.white) ;
          con.bt_gages.setBackground(Color.white) ;
          con.bt_geom.setBackground(Color.white) ;
          con.bt_data.setBackground(Color.white) ;
          // dispp = 0 ;
          calcrange = 0 ;

          loadInput() ;
        } // handler
      }  // Inr
    }  // Cyl 

    class Grf extends Panel {
      FoilBoardWithProblems app ;
      Upper u;
      Lower l;

      Grf (FoilBoardWithProblems target) {
        app = target ;
        setLayout(new GridLayout(2,1,5,5)) ;

        u = new Upper(app) ;
        l = new Lower(app) ;

        add (u) ;
        add (l) ;
      }

      class Upper extends Panel {
        FoilBoardWithProblems app ;
        Label l1 ;
        Button pl1,pl2,pl3;

        Upper(FoilBoardWithProblems target) {
          app = target ;
          setLayout(new GridLayout(3,4,5,5)) ;
  
          l1 = new Label("Surface", Label.RIGHT) ;
          l1.setForeground(Color.blue) ;
 
          pl1 = new Button("Pressure") ;
          pl1.setBackground(Color.yellow) ;
          pl1.setForeground(Color.blue) ;

          pl2 = new Button("Velocity") ;
          pl2.setBackground(Color.white) ;
          pl2.setForeground(Color.blue) ;

          pl3 = new Button("Drag Polar") ;
          pl3.setBackground(Color.white) ;
          pl3.setForeground(Color.blue) ;

          add(new Label(" ", Label.RIGHT)) ;
          add(new Label("Select", Label.RIGHT)) ;
          add(new Label("Plot", Label.LEFT)) ;
          add(new Label(" ", Label.RIGHT)) ;
 
          add(l1) ;
          add(pl1) ;
          add(pl2) ;
          add(new Label(" ", Label.RIGHT)) ;
 
          add(new Label(" ", Label.RIGHT)) ;
          add(pl3) ;
          add(new Label(" ", Label.RIGHT)) ;
          add(new Label(" ", Label.RIGHT)) ;
        }

        public boolean action(Event evt, Object arg) {
          if(evt.target instanceof Button) {
            handleBut(evt,arg) ;
            return true ;
          }
          else return false ;
        } // Handler

        public void handleBut(Event evt, Object arg) {
          String label = (String)arg ;
          layout.show(out, "first")  ;
          con.bt_plot.setBackground(Color.yellow) ;
          con.bt_probe.setBackground(Color.white) ;
          con.bt_gages.setBackground(Color.white) ;
          con.bt_geom.setBackground(Color.white) ;
          con.bt_data.setBackground(Color.white) ;
          if(label.equals("Pressure")) {
            // dispp = 0 ;
            pl1.setBackground(Color.yellow) ;
            pl2.setBackground(Color.white) ;
            pl3.setBackground(Color.white) ;
            l.f.pl3.setBackground(Color.white) ;
            l.f.pl3.setForeground(Color.red) ;
            l.f.pl4.setBackground(Color.white) ;
            l.f.pl4.setForeground(Color.red) ;
            l.f.pl5.setBackground(Color.white) ;
            l.f.pl5.setForeground(Color.red) ;
            l.f.pl6.setBackground(Color.white) ;
            l.f.pl6.setForeground(Color.red) ;
            l.f.pl7.setBackground(Color.white) ;
            l.f.pl7.setForeground(Color.red) ;
            l.f.pl8.setBackground(Color.white) ;
            l.f.pl8.setForeground(Color.red) ;
            l.f.pl9.setBackground(Color.white) ;
            l.f.pl9.setForeground(Color.red) ;
          }
          if(label.equals("Velocity")) {
            dispp = 1 ;
            pl1.setBackground(Color.white) ;
            pl2.setBackground(Color.yellow) ;
            pl3.setBackground(Color.white) ;
            l.f.pl3.setBackground(Color.white) ;
            l.f.pl3.setForeground(Color.red) ;
            l.f.pl4.setBackground(Color.white) ;
            l.f.pl4.setForeground(Color.red) ;
            l.f.pl5.setBackground(Color.white) ;
            l.f.pl5.setForeground(Color.red) ;
            l.f.pl6.setBackground(Color.white) ;
            l.f.pl6.setForeground(Color.red) ;
            l.f.pl7.setBackground(Color.white) ;
            l.f.pl7.setForeground(Color.red) ;
            l.f.pl8.setBackground(Color.white) ;
            l.f.pl8.setForeground(Color.red) ;
            l.f.pl9.setBackground(Color.white) ;
            l.f.pl9.setForeground(Color.red) ;
          }
          if(label.equals("Drag Polar")) {
            dispp = 9 ;
            pl1.setBackground(Color.white) ;
            pl2.setBackground(Color.white) ;
            pl3.setBackground(Color.yellow) ;
            l.f.pl3.setBackground(Color.white) ;
            l.f.pl3.setForeground(Color.red) ;
            l.f.pl4.setBackground(Color.white) ;
            l.f.pl4.setForeground(Color.red) ;
            l.f.pl5.setBackground(Color.white) ;
            l.f.pl5.setForeground(Color.red) ;
            l.f.pl6.setBackground(Color.white) ;
            l.f.pl6.setForeground(Color.red) ;
            l.f.pl7.setBackground(Color.white) ;
            l.f.pl7.setForeground(Color.red) ;
            l.f.pl8.setBackground(Color.white) ;
            l.f.pl8.setForeground(Color.red) ;
            l.f.pl9.setBackground(Color.white) ;
            l.f.pl9.setForeground(Color.red) ;
          }
          calcrange = 0 ;
          computeFlow() ;
        } // end handlebut
      } // Upper

      class Lower extends Panel {
        FoilBoardWithProblems app ;
        FoilCtrls f ;
        BallCtrls c ;

        Lower(FoilBoardWithProblems target) {
          app = target ;
          layplt = new CardLayout() ;
          setLayout(layplt) ;

          f = new FoilCtrls(app) ;
          c = new BallCtrls(app) ;

          add ("first", f) ;
          add ("second", c) ;
        }

        class FoilCtrls extends Panel {
          FoilBoardWithProblems app ;
          Label l2 ;
          Button pl3,pl4,pl5,pl6,pl7,pl8,pl9 ;
          Choice plout,ploutb  ;
    
          FoilCtrls(FoilBoardWithProblems target) {
            app = target ;
            setLayout(new GridLayout(3,4,5,5)) ;

            ploutb = new Choice() ;
            ploutb.addItem("Lift vs.") ;
            ploutb.addItem("Drag vs.");
            ploutb.setBackground(Color.white) ;
            ploutb.setForeground(Color.red) ;
            ploutb.select(0) ;

            plout = new Choice() ;
            plout.addItem("Lift vs.") ;
            plout.addItem("Cl vs.");
            plout.addItem("Drag vs.");
            plout.addItem("Cd vs.");
            plout.setBackground(Color.white) ;
            plout.setForeground(Color.red) ;
            plout.select(0) ;
     
            pl3 = new Button("Angle") ;
            pl3.setBackground(Color.white) ;
            pl3.setForeground(Color.red) ;

            pl4 = new Button("Thickness") ;
            pl4.setBackground(Color.white) ;
            pl4.setForeground(Color.red) ;

            pl5 = new Button("Camber") ;
            pl5.setBackground(Color.white) ;
            pl5.setForeground(Color.red) ;

            pl6 = new Button("Speed") ;
            pl6.setBackground(Color.white) ;
            pl6.setForeground(Color.red) ;

            pl7 = new Button("Altitude") ;
            pl7.setBackground(Color.white) ;
            pl7.setForeground(Color.red) ;

            pl8 = new Button("Wing Area") ;
            pl8.setBackground(Color.white) ;
            pl8.setForeground(Color.red) ;

            pl9 = new Button("Density") ;
            pl9.setBackground(Color.white) ;
            pl9.setForeground(Color.red) ;

            add(plout) ;
            add(pl3) ;
            add(pl5) ;
            add(pl4) ;
   
            add(ploutb) ;
            add(pl6) ;
            add(pl7) ;
            add(new Label(" ", Label.RIGHT)) ;
   
            add(new Label(" ", Label.RIGHT)) ;
            add(pl8) ;
            add(pl9) ;
            add(new Label(" ", Label.RIGHT)) ;
          }

          public boolean action(Event evt, Object arg) {
            if(evt.target instanceof Button) {
              handleBut(evt,arg) ;
              return true ;
            }
            if(evt.target instanceof Choice) {
              String label = (String)arg ;
              dout = plout.getSelectedIndex() ;
              doutb = ploutb.getSelectedIndex() ;
                    
              computeFlow() ;
              return true ;
            }
            else return false ;
          } // Handler

          public void handleBut(Event evt, Object arg) {
            String label = (String)arg ;
            layout.show(out, "first")  ;
            con.bt_plot.setBackground(Color.yellow) ;
            con.bt_probe.setBackground(Color.white) ;
            con.bt_gages.setBackground(Color.white) ;
            con.bt_geom.setBackground(Color.white) ;
            con.bt_data.setBackground(Color.white) ;
            if(label.equals("Angle")) {
              dispp = 2 ;
              pl3.setBackground(Color.yellow) ;
              pl3.setForeground(Color.black) ;
              pl4.setBackground(Color.white) ;
              pl4.setForeground(Color.red) ;
              pl5.setBackground(Color.white) ;
              pl5.setForeground(Color.red) ;
              pl6.setBackground(Color.white) ;
              pl6.setForeground(Color.red) ;
              pl7.setBackground(Color.white) ;
              pl7.setForeground(Color.red) ;
              pl8.setBackground(Color.white) ;
              pl8.setForeground(Color.red) ;
              pl9.setBackground(Color.white) ;
              pl9.setForeground(Color.red) ;
              u.pl1.setBackground(Color.white) ;
              u.pl2.setBackground(Color.white) ;
              u.pl3.setBackground(Color.white) ;
            }
            if(label.equals("Thickness")) {
              dispp = 3 ;
              pl3.setBackground(Color.white) ;
              pl3.setForeground(Color.red) ;
              pl4.setBackground(Color.yellow) ;
              pl4.setForeground(Color.black) ;
              pl5.setBackground(Color.white) ;
              pl5.setForeground(Color.red) ;
              pl6.setBackground(Color.white) ;
              pl6.setForeground(Color.red) ;
              pl7.setBackground(Color.white) ;
              pl7.setForeground(Color.red) ;
              pl8.setBackground(Color.white) ;
              pl8.setForeground(Color.red) ;
              pl9.setBackground(Color.white) ;
              pl9.setForeground(Color.red) ;
              u.pl1.setBackground(Color.white) ;
              u.pl2.setBackground(Color.white) ;
              u.pl3.setBackground(Color.white) ;
            }
            if(label.equals("Camber")) {
              dispp = 4 ;
              pl3.setBackground(Color.white) ;
              pl3.setForeground(Color.red) ;
              pl4.setBackground(Color.white) ;
              pl4.setForeground(Color.red) ;
              pl5.setBackground(Color.yellow) ;
              pl5.setForeground(Color.black) ;
              pl6.setBackground(Color.white) ;
              pl6.setForeground(Color.red) ;
              pl7.setBackground(Color.white) ;
              pl7.setForeground(Color.red) ;
              pl8.setBackground(Color.white) ;
              pl8.setForeground(Color.red) ;
              pl9.setBackground(Color.white) ;
              pl9.setForeground(Color.red) ;
              u.pl1.setBackground(Color.white) ;
              u.pl3.setBackground(Color.white) ;
              u.pl2.setBackground(Color.white) ;
            }
            if(label.equals("Speed")) {
              dispp = 5 ;
              pl3.setBackground(Color.white) ;
              pl3.setForeground(Color.red) ;
              pl4.setBackground(Color.white) ;
              pl4.setForeground(Color.red) ;
              pl5.setBackground(Color.white) ;
              pl5.setForeground(Color.red) ;
              pl6.setBackground(Color.yellow) ;
              pl6.setForeground(Color.black) ;
              pl7.setBackground(Color.white) ;
              pl7.setForeground(Color.red) ;
              pl8.setBackground(Color.white) ;
              pl8.setForeground(Color.red) ;
              pl9.setBackground(Color.white) ;
              pl9.setForeground(Color.red) ;
              u.pl1.setBackground(Color.white) ;
              u.pl2.setBackground(Color.white) ;
              u.pl3.setBackground(Color.white) ;
            }
            if(label.equals("Altitude")) {
              dispp = 6 ;
              pl3.setBackground(Color.white) ;
              pl3.setForeground(Color.red) ;
              pl4.setBackground(Color.white) ;
              pl4.setForeground(Color.red) ;
              pl5.setBackground(Color.white) ;
              pl5.setForeground(Color.red) ;
              pl6.setBackground(Color.white) ;
              pl6.setForeground(Color.red) ;
              pl7.setBackground(Color.yellow) ;
              pl7.setForeground(Color.black) ;
              pl8.setBackground(Color.white) ;
              pl8.setForeground(Color.red) ;
              pl9.setBackground(Color.white) ;
              pl9.setForeground(Color.red) ;
              u.pl1.setBackground(Color.white) ;
              u.pl2.setBackground(Color.white) ;
              u.pl3.setBackground(Color.white) ;
            }
            if(label.equals("Wing Area")) {
              dispp = 7 ;
              pl3.setBackground(Color.white) ;
              pl3.setForeground(Color.red) ;
              pl4.setBackground(Color.white) ;
              pl4.setForeground(Color.red) ;
              pl5.setBackground(Color.white) ;
              pl5.setForeground(Color.red) ;
              pl6.setBackground(Color.white) ;
              pl6.setForeground(Color.red) ;
              pl7.setBackground(Color.white) ;
              pl7.setForeground(Color.red) ;
              pl8.setBackground(Color.yellow) ;
              pl8.setForeground(Color.black) ;
              pl9.setBackground(Color.white) ;
              pl9.setForeground(Color.red) ;
              u.pl1.setBackground(Color.white) ;
              u.pl2.setBackground(Color.white) ;
              u.pl3.setBackground(Color.white) ;
            }
            if(label.equals("Density")) {
              dispp = 8 ;
              pl3.setBackground(Color.white) ;
              pl3.setForeground(Color.red) ;
              pl4.setBackground(Color.white) ;
              pl4.setForeground(Color.red) ;
              pl5.setBackground(Color.white) ;
              pl5.setForeground(Color.red) ;
              pl6.setBackground(Color.white) ;
              pl6.setForeground(Color.red) ;
              pl7.setBackground(Color.white) ;
              pl7.setForeground(Color.red) ;
              pl8.setBackground(Color.white) ;
              pl8.setForeground(Color.red) ;
              pl9.setBackground(Color.yellow) ;
              pl9.setForeground(Color.black) ;
              u.pl1.setBackground(Color.white) ;
              u.pl2.setBackground(Color.white) ;
              u.pl3.setBackground(Color.white) ;
            }
    
            computeFlow() ;
          }

        }  // foil

        class BallCtrls extends Panel {
          FoilBoardWithProblems app ;
          Label l2 ;
   
          BallCtrls(FoilBoardWithProblems target) {
            app = target ;
            setLayout(new GridLayout(1,1,5,5)) ;

            l2 = new Label(" ", Label.RIGHT) ;

            add(l2) ;
          }
        }  // BallCtrls
      } // Lower
    }  // Grf

    class Anl extends Panel {
      FoilBoardWithProblems app ;
      Label l1,l3,l4,l5,l6 ;
      Button bt3,bt4_1,bt4_2,bt5,bt6,bt7,bt8,bt9,bt10 ;
      Button foilsim_drag, aquila_9p3_drag, naca4digit_drag;
      // int foil_drag_comp_method = DRAG_COMP_NACA4SERIES;
      Button cbt1,cbt2,cbt3 ;

      Anl (FoilBoardWithProblems target) {

        app = target ;
        setLayout(new GridLayout(8,3,5,5)) ;

//        l2 = new Label("Units:", Label.RIGHT) ;  
//        bt1 = new Button("Imperial Units") ;
//        bt1.setBackground(Color.yellow) ;
//        bt1.setForeground(Color.blue) ;
//
//        bt2 = new Button("Metric Units") ;
//        bt2.setBackground(Color.white) ;
//        bt2.setForeground(Color.blue) ;
 
        l1 = new Label("Lift Analysis", Label.RIGHT) ;
        bt3 = new Button("Ideal Flow") ;
        bt3.setBackground(Color.white) ;
        bt3.setForeground(Color.blue) ;

        bt4_1 = new Button("Default") ;
        bt4_1.setBackground(Color.yellow) ;
        bt4_1.setForeground(Color.blue) ;

        bt4_2 = new Button("Per FoilBoardWithProblems Type") ;
        bt4_2.setBackground(Color.white) ;
        bt4_2.setForeground(Color.blue) ;

        l3 = new Label("AR Lift Correction:", Label.RIGHT) ;
        bt5 = new Button("AR On") ;
        bt5.setBackground(Color.yellow) ;
        bt5.setForeground(Color.blue) ;

        bt6 = new Button("AR Off") ;
        bt6.setBackground(Color.white) ;
        bt6.setForeground(Color.blue) ;

        l4 = new Label("Induced Drag:", Label.RIGHT) ;
        bt7 = new Button("ID On") ;
        bt7.setBackground(Color.yellow) ;
        bt7.setForeground(Color.blue) ;

        bt8 = new Button("ID Off") ;
        bt8.setBackground(Color.white) ;
        bt8.setForeground(Color.blue) ;

        l5 = new Label("Re # Correction:", Label.RIGHT) ;
        bt9 = new Button("Re On") ;
        bt9.setBackground(Color.yellow) ;
        bt9.setForeground(Color.blue) ;

        bt10 = new Button("Re Off") ;
        bt10.setBackground(Color.white) ;
        bt10.setForeground(Color.blue) ;

        // foilsim_drag = new Button("Polynomial") ;
        // foilsim_drag.setBackground(Color.white) ;
        // foilsim_drag.setForeground(Color.blue) ;
        // 
        // naca4digit_drag = new Button("NACA*4** foils") ;
        // naca4digit_drag.setBackground(Color.yellow) ;
        // naca4digit_drag.setForeground(Color.blue) ;
        // 
        // aquila_9p3_drag = new Button("Aquila 9.3%") ;
        // aquila_9p3_drag.setBackground(Color.white) ;
        // aquila_9p3_drag.setForeground(Color.blue) ;

        l6= new Label("Drag of Ball", Label.CENTER) ;
        //           l6.setForeground(Color.red) ;       
        cbt1 = new Button("Smooth Ball") ;
        cbt1.setBackground(Color.white) ;
        cbt1.setForeground(Color.red) ;

        cbt2 = new Button("Rough Ball") ;
        cbt2.setBackground(Color.white) ;
        cbt2.setForeground(Color.red) ;

        cbt3 = new Button("Golf Ball") ;
        cbt3.setBackground(Color.white) ;
        cbt3.setForeground(Color.red) ;

        add(l1) ;
        // Panel p = new Panel(new GridLayout(1,2,2,2));
        Panel p = new Panel(new BorderLayout());
        p.add(bt4_1, BorderLayout.WEST);
        p.add(bt4_2, BorderLayout.EAST);
        add(p) ;
        
        add(bt3) ;

        add(l3) ;
        add(bt5) ;
        add(bt6) ;

        add(l4) ;
        add(bt7) ;
        add(bt8) ;

        add(l5) ;
        add(bt9) ;
        add(bt10) ;

        // add(new Label("Drag of foil", Label.RIGHT)) ;
        // add(naca4digit_drag);
        // add(foilsim_drag);
        // add(new Label(" ", Label.RIGHT)) ;
        // add(aquila_9p3_drag);
        // add(new Label(" ", Label.RIGHT)) ;

        //         add(bt1) ;
        add(l6) ;
        add(cbt1) ;
        add(cbt2) ;

        //         add(bt2) ;
        add(new Label(" ", Label.RIGHT)) ;
        add(cbt3) ;
        add(new Label(" ", Label.RIGHT)) ;
      }

      public boolean action(Event evt, Object arg) {
        if(evt.target instanceof Button) {
          handleBut(evt,arg) ;
          return true ;
        }
        else return false ;
      } // Handler

      public void handleBut(Event evt, Object arg) {
        String label = (String)arg ;
           
//        if(label.equals("Imperial Units")) {
//          lunits = IMPERIAL ;
//          bt1.setBackground(Color.yellow) ;
//          bt2.setBackground(Color.white) ;
//          setUnits () ;
//        } else if(label.equals("Metric Units")) {
//          lunits = METRIC ;
//          bt1.setBackground(Color.white) ;
//          bt2.setBackground(Color.yellow) ;
//          setUnits () ;
//        } else 
          if(label.equals("Ideal Flow")) {
          stall_model_type = STALL_MODEL_IDEAL_FLOW ;
          bt3.setBackground(Color.yellow) ;
          bt4_1.setBackground(Color.white) ;
          bt4_2.setBackground(Color.white) ;
        } else if(label.equals("Default")) {
          stall_model_type = STALL_MODEL_DFLT ;
          bt3.setBackground(Color.white) ;
          bt4_2.setBackground(Color.white) ;
          bt4_1.setBackground(Color.yellow) ;
        } else if(label.equals("Per FoilBoardWithProblems Type")) {
          stall_model_type = STALL_MODEL_REFINED ;
          bt3.setBackground(Color.white) ;
          bt4_1.setBackground(Color.white) ;
          bt4_2.setBackground(Color.yellow) ;
        } else if(label.equals("AR On")) {
          ar_lift_corr = 1 ;
          bt6.setBackground(Color.white) ;
          bt5.setBackground(Color.yellow) ;
        } else if(label.equals("AR Off")) {
          ar_lift_corr = 0 ;
          bt5.setBackground(Color.white) ;
          bt6.setBackground(Color.yellow) ;
        } else if(label.equals("ID On")) {
          indrag = 1 ;
          bt8.setBackground(Color.white) ;
          bt7.setBackground(Color.yellow) ;
        } else if(label.equals("ID Off")) {
          indrag = 0 ;
          bt7.setBackground(Color.white) ;
          bt8.setBackground(Color.yellow) ;
        } else if(label.equals("Re On")) {
          recor = 1 ;
          bt10.setBackground(Color.white) ;
          bt9.setBackground(Color.yellow) ;
        } else if(label.equals("Re Off")) {
          recor = 0 ;
          bt9.setBackground(Color.white) ;
          bt10.setBackground(Color.yellow) ;
        } else if(label.equals("Smooth Ball")) {
          bdragflag = 1 ;
          cbt1.setBackground(Color.yellow) ;
          cbt2.setBackground(Color.white) ;
          cbt3.setBackground(Color.white) ;
        } else if(label.equals("Rough Ball")) {
          bdragflag = 2 ;
          cbt2.setBackground(Color.yellow) ;
          cbt1.setBackground(Color.white) ;
          cbt3.setBackground(Color.white) ;
        } else if(label.equals("Golf Ball")) {
          bdragflag = 3 ;
          cbt3.setBackground(Color.yellow) ;
          cbt2.setBackground(Color.white) ;
          cbt1.setBackground(Color.white) ;
        } else if(label.equals("NACA*4** foils")) {
          //foil_drag_comp_method = DRAG_COMP_NACA4SERIES;
          naca4digit_drag.setBackground(Color.yellow) ;
          foilsim_drag.setBackground(Color.white) ;
          aquila_9p3_drag.setBackground(Color.white) ;
        } else if(label.equals("Polynomial")) {
          //foil_drag_comp_method = DRAG_COMP_POLY_FOILSIMORIG;
          foilsim_drag.setBackground(Color.yellow) ;
          naca4digit_drag.setBackground(Color.white) ;
          aquila_9p3_drag.setBackground(Color.white) ;
        } else if(label.startsWith("Aquila")) {
          //foil_drag_comp_method = DRAG_COMP_AQUILA_9P3;
          aquila_9p3_drag.setBackground(Color.yellow) ;
          foilsim_drag.setBackground(Color.white) ;
          naca4digit_drag.setBackground(Color.white) ;
        }

        loadInput() ;
        con.recomp_all_parts();
      }
    } // end Anl
  }  // In 

  class Out extends Panel {
    FoilBoardWithProblems app ;
    Plt plt ;
    Prb prb ;
    Perf perf ;
    PerfWeb perfweb;
    PerfWebSrc perfwebsrc;

    double ball_spin_angle;
    Viewer viewer;


    Out (FoilBoardWithProblems target) { 
      app = target ;
      viewer = new Viewer(app) ;

      layout = new CardLayout() ;
      setLayout(layout) ;

      plt = new Plt(app) ;
      prb = new Prb(app) ;
      perf = new Perf(app) ;

      add ("first", plt) ;
      add ("second", prb) ;
      add ("third", perf) ;

      perfweb = new PerfWeb(app);
      add("fourth", perfweb);

      perfwebsrc = new PerfWebSrc(app);
      add("fifth", perfwebsrc);
    }


    class Viewer extends Canvas implements Runnable {
      FoilBoardWithProblems app;
      Thread runner;
      Point locate, anchor;

      Viewer(FoilBoardWithProblems target) {
        setBackground(Color.black);
        runner = null;
      }

      public Insets insets () {
        return new Insets(0, 10, 0, 10);
      }

      public boolean mouseDown (Event evt, int x, int y) {
        anchor = new Point(x, y);
        return true;
      }

      public boolean mouseUp (Event evt, int x, int y) {
        handleb(x, y);
        return true;
      }

      public boolean mouseDrag (Event evt, int x, int y) {
        handle(x, y);
        return true;
      }

      public void handle (int x, int y) {
        // determine location
        if (y >= 30) {
          if (x >= 30) { // translate
            if (displ != 2) {
              locate = new Point(x, y);
              yt = yt + (int) (.2 * (locate.y - anchor.y));
              xt = xt + (int) (.4 * (locate.x - anchor.x));
              if (xt > 320)
                xt = 320;
              if (xt < -280)
                xt = -280;
              if (yt > 300)
                yt = 300;
              if (yt < -300)
                yt = -300;
              xt1 = xt + spanfac;
              yt1 = yt - spanfac;
              xt2 = xt - spanfac;
              yt2 = yt + spanfac;
            }
            if (displ == 2) { // move the rake
              locate = new Point(x, y);
              xflow = xflow + .01 * (locate.x - anchor.x);
              if (xflow < -10.0)
                xflow = -10.0;
              if (xflow > 0.0)
                xflow = 0.0;
              computeFlow();
            }
          }
          if (x < 30) { // zoom widget
            sldloc = y;
            if (sldloc < 30)
              sldloc = 30;
            if (sldloc > 165)
              sldloc = 165;
            fact = 10.0 + (sldloc - 30) * 1.0;
            spanfac = (int) (2.0 * fact * aspr * .3535);
            xt1 = xt + spanfac;
            yt1 = yt - spanfac;
            xt2 = xt - spanfac;
            yt2 = yt + spanfac;
          }
        }
      }

      public void handleb (int x, int y) {
        if (y < 15) {
          if (x >= 90 && x <= 139) { // edge view
            viewflg = 0;
          }
          if (x >= 140 && x <= 170) { // top view
            if (foil <= FOIL_CYLINDER)
              viewflg = 1;
            if (foil == FOIL_BALL)
              viewflg = 0;
            displ = 3;
            pboflag = 0;
          }
          if (x >= 171 && x <= 239) { // side view
            if (foil <= FOIL_CYLINDER)
              viewflg = 2;
            if (foil == FOIL_BALL)
              viewflg = 0;
          }
          if (x >= 240 && x <= 270) { // find
            xt = 170;
            yt = 105;
            fact = 30.0;
            sldloc = 50;
            spanfac = (int) (2.0 * fact * aspr * .3535);
            xt1 = xt + spanfac;
            yt1 = yt - spanfac;
            xt2 = xt - spanfac;
            yt2 = yt + spanfac;
          }
        }
        if (y > 15 && y <= 30) {
          if (x >= 80 && x <= 154) { // display streamlines
            if (viewflg != 1)
              displ = 0;
          }
          if (x >= 155 && x <= 204) { // display animation
            if (viewflg != 1)
              displ = 1;
          }
          if (x >= 205 && x <= 249) { // display direction
            if (viewflg != 1)
              displ = 2;
          }
          if (x >= 250 && x <= 330) { // display geometry
            displ = 3;
            pboflag = 0;
          }
        }
        out.viewer.repaint();
      }

      public void start () {
        if (runner == null) {
          runner = new Thread(this);
          runner.start();
        }
        antim = 0; /* MODS 21 JUL 99 */
        ancol = 1; /* MODS 27 JUL 99 */
      }

      int timer = 100;
      void run_step () {
        ++antim;
        viewer.repaint();
        if (antim == 3) {
          antim = 0;
          ancol = -ancol; /* MODS 27 JUL 99 */
        }

        timer = 135 - (int) (.227 * velocity / vconv);
        // make the ball spin
        if (foil_is_cylinder_or_ball(foil)) {
          ball_spin_angle = ball_spin_angle + spin * spindr * 5.;
          if (ball_spin_angle < -360.0) {
            ball_spin_angle = ball_spin_angle + 360.0;
          }
          if (ball_spin_angle > 360.0) {
            ball_spin_angle = ball_spin_angle - 360.0;
          }
        }
      }

      /**
       * @j2sNative
       * 
       *            this.run_step(); var self = this; setTimeout(function()
       *            {self.run();}, self.timer);
       */
      public void run () {
        while (true) {
          try {
            Thread.sleep(timer);
          } catch (InterruptedException e) {
          }
          run_step();
        }
      }

      public void update (Graphics g) {
        out.viewer.paint(g);
      }

      public void paint (Graphics g) {
        int i, j, k, n;
        int xlabel, ylabel, ind, inmax, inmin;
        int exes[] = new int[8];
        int whys[] = new int[8];
        double offx, scalex, offy, scaley, waste, incy, incx;
        double xl, yl, slope, radvec, xvec, yvec;
        int camb_x[] = new int[19];
        int camb_y[] = new int[19];
        Color col;

        col = new Color(0, 0, 0);
        if (planet == 0)
          col = Color.cyan;
        if (planet == 1)
          col = Color.orange;
        if (planet == 2)
          col = Color.green;
        if (planet >= 3)
          col = Color.cyan;
        off1Gg.setColor(Color.black);
        off1Gg.fillRect(0, 0, 500, 500);

        if (viewflg == 1) { // Top View
          off1Gg.setColor(Color.white);
          exes[0] = (int) (.25 * fact * (-span)) + xt;
          whys[0] = (int) (.25 * fact * (-chord)) + yt;
          exes[1] = (int) (.25 * fact * (-span)) + xt;
          whys[1] = (int) (.25 * fact * (chord)) + yt;
          exes[2] = (int) (.25 * fact * (span)) + xt;
          whys[2] = (int) (.25 * fact * (chord)) + yt;
          exes[3] = (int) (.25 * fact * (span)) + xt;
          whys[3] = (int) (.25 * fact * (-chord)) + yt;
          off1Gg.fillPolygon(exes, whys, 4);
          off1Gg.setColor(Color.green);
          off1Gg.drawLine(exes[0], whys[1] + 5, exes[2], whys[1] + 5);
          off1Gg.drawString("Span", exes[2] - 20, whys[1] + 20);
          off1Gg.drawLine(exes[2] + 5, whys[0], exes[2] + 5, whys[1]);
          if (!foil_is_cylinder_or_ball(foil))
            off1Gg.drawString("Chord", exes[2] + 10, 55);
          else
            off1Gg.drawString("Diameter", exes[2] + 10, 55);

          off1Gg.setColor(Color.green);
          off1Gg.drawString("Flow", 45, 145);
          off1Gg.drawLine(40, 155, 40, 125);
          exes[0] = 35;
          exes[1] = 45;
          exes[2] = 40;
          whys[0] = 125;
          whys[1] = 125;
          whys[2] = 115;
          off1Gg.fillPolygon(exes, whys, 3);
        }

        if (viewflg == 0 || viewflg == 2) { // edge View
          if (velocity > .01) {
            /* plot airfoil flowfield */
            radvec = .5;
            for (j = 1; j <= STREAMLINES_COUNT_HALF - 1; ++j) { /* lower half */
              for (i = 1; i <= POINTS_COUNT - 1; ++i) {
                exes[0] = (int) (fact * xpl[j][i]) + xt;
                whys[0] = (int) (fact * (-ypl[j][i])) + yt;
                slope = (ypl[j][i + 1] - ypl[j][i]) / (xpl[j][i + 1] - xpl[j][i]);
                xvec = xpl[j][i] + radvec / Math.sqrt(1.0 + slope * slope);
                yvec = ypl[j][i] + slope * (xvec - xpl[j][i]);
                exes[1] = (int) (fact * xvec) + xt;
                whys[1] = (int) (fact * (-yvec)) + yt;
                if (displ == 0) { /* MODS 21 JUL 99 */
                  off1Gg.setColor(Color.yellow);
                  exes[1] = (int) (fact * xpl[j][i + 1]) + xt;
                  whys[1] = (int) (fact * (-ypl[j][i + 1])) + yt;
                  off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                }
                if (displ == 2 && (i / 3 * 3 == i)) {
                  off1Gg.setColor(col);
                  for (n = 1; n <= 4; ++n) {
                    if (i == 6 + (n - 1) * 9)
                      off1Gg.setColor(Color.yellow);
                  }
                  if (i / 9 * 9 == i)
                    off1Gg.setColor(Color.white);
                  off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                }
                if (displ == 1 && ((i - antim) / 3 * 3 == (i - antim))) {
                  if (ancol == -1) { /* MODS 27 JUL 99 */
                    if ((i - antim) / 6 * 6 == (i - antim))
                      off1Gg.setColor(col);
                    if ((i - antim) / 6 * 6 != (i - antim))
                      off1Gg.setColor(Color.white);
                  }
                  if (ancol == 1) { /* MODS 27 JUL 99 */
                    if ((i - antim) / 6 * 6 == (i - antim))
                      off1Gg.setColor(Color.white);
                    if ((i - antim) / 6 * 6 != (i - antim))
                      off1Gg.setColor(col);
                  }
                  off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                }
              }
            }

            off1Gg.setColor(Color.white); /* stagnation */
            exes[1] = (int) (fact * xpl[STREAMLINES_COUNT_HALF][1]) + xt;
            whys[1] = (int) (fact * (-ypl[STREAMLINES_COUNT_HALF][1])) + yt;
            for (i = 2; i <= POINTS_COUNT_HALF - 1; ++i) {
              exes[0] = exes[1];
              whys[0] = whys[1];
              exes[1] = (int) (fact * xpl[STREAMLINES_COUNT_HALF][i]) + xt;
              whys[1] = (int) (fact * (-ypl[STREAMLINES_COUNT_HALF][i])) + yt;
              if (displ <= 2) { /* MODS 21 JUL 99 */
                off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
              }
            }
            exes[1] = (int) (fact * xpl[STREAMLINES_COUNT_HALF][POINTS_COUNT_HALF + 1]) + xt;
            whys[1] = (int) (fact * (-ypl[STREAMLINES_COUNT_HALF][POINTS_COUNT_HALF + 1])) + yt;
            for (i = POINTS_COUNT_HALF + 2; i <= POINTS_COUNT; ++i) {
              exes[0] = exes[1];
              whys[0] = whys[1];
              exes[1] = (int) (fact * xpl[STREAMLINES_COUNT_HALF][i]) + xt;
              whys[1] = (int) (fact * (-ypl[STREAMLINES_COUNT_HALF][i])) + yt;
              if (displ <= 2) { /* MODS 21 JUL 99 */
                off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
              }
            }
            /* probe location */
            if (pboflag > 0 && pypl <= 0.0) {
              off1Gg.setColor(Color.magenta);
              off1Gg.fillOval((int) (fact * pxpl) + xt, (int) (fact * (-pypl)) + yt - 2, 5, 5);
              off1Gg.setColor(Color.white);
              exes[0] = (int) (fact * (pxpl + .1)) + xt;
              whys[0] = (int) (fact * (-pypl)) + yt;
              exes[1] = (int) (fact * (pxpl + .5)) + xt;
              whys[1] = (int) (fact * (-pypl)) + yt;
              exes[2] = (int) (fact * (pxpl + .5)) + xt;
              whys[2] = (int) (fact * (-pypl + 50.)) + yt;
              off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
              off1Gg.drawLine(exes[1], whys[1], exes[2], whys[2]);
              if (pboflag == 3) { /* smoke trail MODS 21 JUL 99 */
                off1Gg.setColor(Color.green);
                for (i = 1; i <= POINTS_COUNT - 1; ++i) {
                  exes[0] = (int) (fact * xpl[19][i]) + xt;
                  whys[0] = (int) (fact * (-ypl[19][i])) + yt;
                  slope = (ypl[19][i + 1] - ypl[19][i]) / (xpl[19][i + 1] - xpl[19][i]);
                  xvec = xpl[19][i] + radvec / Math.sqrt(1.0 + slope * slope);
                  yvec = ypl[19][i] + slope * (xvec - xpl[19][i]);
                  exes[1] = (int) (fact * xvec) + xt;
                  whys[1] = (int) (fact * (-yvec)) + yt;
                  if ((i - antim) / 3 * 3 == (i - antim)) {
                    off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                  }
                }
              }
            }

            // wing surface
            if (viewflg == 2) { // 3d geom
              off1Gg.setColor(Color.red);
              exes[1] = (int) (fact * (xpl[0][POINTS_COUNT_HALF])) + xt1;
              whys[1] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF])) + yt1;
              exes[2] = (int) (fact * (xpl[0][POINTS_COUNT_HALF])) + xt2;
              whys[2] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF])) + yt2;
              for (i = 1; i <= POINTS_COUNT_HALF - 1; ++i) {
                exes[0] = exes[1];
                whys[0] = whys[1];
                exes[1] = (int) (fact * (xpl[0][POINTS_COUNT_HALF - i])) + xt1;
                whys[1] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF - i])) + yt1;
                exes[3] = exes[2];
                whys[3] = whys[2];
                exes[2] = (int) (fact * (xpl[0][POINTS_COUNT_HALF - i])) + xt2;
                whys[2] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF - i])) + yt2;
                off1Gg.fillPolygon(exes, whys, 4);
              }
            }

            for (j = STREAMLINES_COUNT_HALF + 1; j <= STREAMLINES_COUNT; ++j) { /*
                                                                                 * upper
                                                                                 * half
                                                                                 */
              for (i = 1; i <= POINTS_COUNT - 1; ++i) {
                exes[0] = (int) (fact * xpl[j][i]) + xt;
                whys[0] = (int) (fact * (-ypl[j][i])) + yt;
                slope = (ypl[j][i + 1] - ypl[j][i]) / (xpl[j][i + 1] - xpl[j][i]);
                xvec = xpl[j][i] + radvec / Math.sqrt(1.0 + slope * slope);
                yvec = ypl[j][i] + slope * (xvec - xpl[j][i]);
                exes[1] = (int) (fact * xvec) + xt;
                whys[1] = (int) (fact * (-yvec)) + yt;
                if (displ == 0) { /* MODS 21 JUL 99 */
                  off1Gg.setColor(col);
                  exes[1] = (int) (fact * xpl[j][i + 1]) + xt;
                  whys[1] = (int) (fact * (-ypl[j][i + 1])) + yt;
                  off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                }
                if (displ == 2 && (i / 3 * 3 == i)) {
                  off1Gg.setColor(col); /* MODS 27 JUL 99 */
                  for (n = 1; n <= 4; ++n) {
                    if (i == 6 + (n - 1) * 9)
                      off1Gg.setColor(Color.yellow);
                  }
                  if (i / 9 * 9 == i)
                    off1Gg.setColor(Color.white);
                  off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                }
                if (displ == 1 && ((i - antim) / 3 * 3 == (i - antim))) {
                  if (ancol == -1) { /* MODS 27 JUL 99 */
                    if ((i - antim) / 6 * 6 == (i - antim))
                      off1Gg.setColor(col);
                    if ((i - antim) / 6 * 6 != (i - antim))
                      off1Gg.setColor(Color.white);
                  }
                  if (ancol == 1) { /* MODS 27 JUL 99 */
                    if ((i - antim) / 6 * 6 == (i - antim))
                      off1Gg.setColor(Color.white);
                    if ((i - antim) / 6 * 6 != (i - antim))
                      off1Gg.setColor(col);
                  }
                  off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                }
              }
            }
            /* probe location */
            if (pboflag > 0 && pypl > 0.0) {
              off1Gg.setColor(Color.magenta);
              off1Gg.fillOval((int) (fact * pxpl) + xt, (int) (fact * (-pypl)) + yt - 2, 5, 5);
              off1Gg.setColor(Color.white);
              exes[0] = (int) (fact * (pxpl + .1)) + xt;
              whys[0] = (int) (fact * (-pypl)) + yt;
              exes[1] = (int) (fact * (pxpl + .5)) + xt;
              whys[1] = (int) (fact * (-pypl)) + yt;
              exes[2] = (int) (fact * (pxpl + .5)) + xt;
              whys[2] = (int) (fact * (-pypl - 50.)) + yt;
              off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
              off1Gg.drawLine(exes[1], whys[1], exes[2], whys[2]);
              if (pboflag == 3) { /* smoke trail MODS 21 JUL 99 */
                off1Gg.setColor(Color.green);
                for (i = 1; i <= POINTS_COUNT - 1; ++i) {
                  exes[0] = (int) (fact * xpl[19][i]) + xt;
                  whys[0] = (int) (fact * (-ypl[19][i])) + yt;
                  slope = (ypl[19][i + 1] - ypl[19][i]) / (xpl[19][i + 1] - xpl[19][i]);
                  xvec = xpl[19][i] + radvec / Math.sqrt(1.0 + slope * slope);
                  yvec = ypl[19][i] + slope * (xvec - xpl[19][i]);
                  exes[1] = (int) (fact * xvec) + xt;
                  whys[1] = (int) (fact * (-yvec)) + yt;
                  if ((i - antim) / 3 * 3 == (i - antim)) {
                    off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                  }
                }
              }
            }
          }

          if (viewflg == 0) {
            // draw the airfoil geometry
            off1Gg.setColor(Color.white);
            exes[1] = (int) (fact * (xpl[0][POINTS_COUNT_HALF])) + xt;
            whys[1] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF])) + yt;
            exes[2] = (int) (fact * (xpl[0][POINTS_COUNT_HALF])) + xt;
            whys[2] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF])) + yt;
            for (i = 1; i <= POINTS_COUNT_HALF - 1; ++i) {
              exes[0] = exes[1];
              whys[0] = whys[1];
              exes[1] = (int) (fact * (xpl[0][POINTS_COUNT_HALF - i])) + xt;
              whys[1] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF - i])) + yt;
              exes[3] = exes[2];
              whys[3] = whys[2];
              exes[2] = (int) (fact * (xpl[0][POINTS_COUNT_HALF + i])) + xt;
              whys[2] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF + i])) + yt;
              camb_x[i] = (exes[1] + exes[2]) / 2;
              camb_y[i] = (whys[1] + whys[2]) / 2;
              if (foil == FOIL_FLAT_PLATE) {
                off1Gg.setColor(Color.yellow);
                off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
              } else {
                off1Gg.setColor(Color.white);
                off1Gg.fillPolygon(exes, whys, 4);
              }
            }
            // put some info on the geometry
            if (displ == 3) {
              if (!foil_is_cylinder_or_ball(foil)) {
                inmax = 1;
                for (n = 1; n <= POINTS_COUNT; ++n) {
                  if (xpl[0][n] > xpl[0][inmax])
                    inmax = n;
                }
                off1Gg.setColor(Color.green);
                exes[0] = (int) (fact * (xpl[0][inmax])) + xt;
                whys[0] = (int) (fact * (-ypl[0][inmax])) + yt;
                off1Gg.drawLine(exes[0], whys[0], exes[0] - 250, whys[0]);
                off1Gg.drawString("Reference", 30, whys[0] + 10);
                off1Gg.drawString("Angle", exes[0] + 20, whys[0]);

                off1Gg.setColor(Color.cyan);
                exes[1] = (int) (fact * (xpl[0][inmax] - 4.0 * Math.cos(convdr * effective_aoa()))) + xt;
                whys[1] = (int) (fact * (-ypl[0][inmax] - 4.0 * Math.sin(convdr * effective_aoa()))) + yt;
                off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                off1Gg.drawString("Chord Line", exes[0] + 20, whys[0] + 20);

                off1Gg.setColor(Color.red);
                off1Gg.drawLine(exes[1], whys[1], camb_x[5], camb_y[5]);
                for (i = 7; i <= POINTS_COUNT_HALF - 6; i = i + 2) {
                  off1Gg.drawLine(camb_x[i], camb_y[i], camb_x[i + 1], camb_y[i + 1]);
                }
                off1Gg.drawString("Mean Camber Line", exes[0] - 70, whys[1] - 10);
              } else {
                off1Gg.setColor(Color.red);
                exes[0] = (int) (fact * (xpl[0][1])) + xt;
                whys[0] = (int) (fact * (-ypl[0][1])) + yt;
                exes[1] = (int) (fact * (xpl[0][POINTS_COUNT_HALF])) + xt;
                whys[1] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF])) + yt;
                off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
                off1Gg.drawString("Diameter", exes[0] + 20, whys[0] + 20);
              }

              off1Gg.setColor(Color.green);
              off1Gg.drawString("Flow", 30, 145);
              off1Gg.drawLine(30, 152, 60, 152);
              exes[0] = 60;
              exes[1] = 60;
              exes[2] = 70;
              whys[0] = 157;
              whys[1] = 147;
              whys[2] = 152;
              off1Gg.fillPolygon(exes, whys, 3);
            }
            // spin the cylinder and ball
            if (foil_is_cylinder_or_ball(foil)) {
              exes[0] = (int) (fact * (.5 * (xpl[0][1] + xpl[0][POINTS_COUNT_HALF]) + solver.rval * Math.cos(convdr * (ball_spin_angle + 180.)))) + xt;
              whys[0] = (int) (fact * (-ypl[0][1] + solver.rval * Math.sin(convdr * (ball_spin_angle + 180.)))) + yt;
              exes[1] = (int) (fact * (.5 * (xpl[0][1] + xpl[0][POINTS_COUNT_HALF]) + solver.rval * Math.cos(convdr * ball_spin_angle))) + xt;
              whys[1] = (int) (fact * (-ypl[0][1] + solver.rval * Math.sin(convdr * ball_spin_angle))) + yt;
              off1Gg.setColor(Color.red);
              off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
            }
          }
          if (viewflg == 2) {
            // front foil
            off1Gg.setColor(Color.white);
            exes[1] = (int) (fact * (xpl[0][POINTS_COUNT_HALF])) + xt2;
            whys[1] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF])) + yt2;
            exes[2] = (int) (fact * (xpl[0][POINTS_COUNT_HALF])) + xt2;
            whys[2] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF])) + yt2;
            for (i = 1; i <= POINTS_COUNT_HALF - 1; ++i) {
              exes[0] = exes[1];
              whys[0] = whys[1];
              exes[1] = (int) (fact * (xpl[0][POINTS_COUNT_HALF - i])) + xt2;
              whys[1] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF - i])) + yt2;
              exes[3] = exes[2];
              whys[3] = whys[2];
              exes[2] = (int) (fact * (xpl[0][POINTS_COUNT_HALF + i])) + xt2;
              whys[2] = (int) (fact * (-ypl[0][POINTS_COUNT_HALF + i])) + yt2;
              camb_x[i] = (exes[1] + exes[2]) / 2;
              camb_y[i] = (whys[1] + whys[2]) / 2;
              off1Gg.fillPolygon(exes, whys, 4);
            }
            // put some info on the geometry
            if (displ == 3) {
              off1Gg.setColor(Color.green);
              exes[1] = (int) (fact * (xpl[0][1])) + xt1 + 20;
              whys[1] = (int) (fact * (-ypl[0][1])) + yt1;
              exes[2] = (int) (fact * (xpl[0][1])) + xt2 + 20;
              whys[2] = (int) (fact * (-ypl[0][1])) + yt2;
              off1Gg.drawLine(exes[1], whys[1], exes[2], whys[2]);
              off1Gg.drawString("Span", exes[2] + 10, whys[2] + 10);

              exes[1] = (int) (fact * (xpl[0][1])) + xt2;
              whys[1] = (int) (fact * (-ypl[0][1])) + yt2 + 15;
              exes[2] = (int) (fact * (xpl[0][POINTS_COUNT_HALF])) + xt2;
              whys[2] = whys[1];
              off1Gg.drawLine(exes[1], whys[1], exes[2], whys[2]);
              if (!foil_is_cylinder_or_ball(foil))
                off1Gg.drawString("Chord", exes[2] + 10, whys[2] + 15);
              else
                off1Gg.drawString("Diameter", exes[2] + 10, whys[2] + 15);

              off1Gg.drawString("Flow", 40, 75);
              off1Gg.drawLine(30, 82, 60, 82);
              exes[0] = 60;
              exes[1] = 60;
              exes[2] = 70;
              whys[0] = 87;
              whys[1] = 77;
              whys[2] = 82;
              off1Gg.fillPolygon(exes, whys, 3);
            }
            // spin the cylinder and ball
            if (foil_is_cylinder_or_ball(foil)) {
              exes[0] = (int) (fact * (.5 * (xpl[0][1] + xpl[0][POINTS_COUNT_HALF]) + solver.rval * Math.cos(convdr * (ball_spin_angle + 180.)))) + xt2;
              whys[0] = (int) (fact * (-ypl[0][1] + solver.rval * Math.sin(convdr * (ball_spin_angle + 180.)))) + yt2;
              exes[1] = (int) (fact * (.5 * (xpl[0][1] + xpl[0][POINTS_COUNT_HALF]) + solver.rval * Math.cos(convdr * ball_spin_angle))) + xt2;
              whys[1] = (int) (fact * (-ypl[0][1] + solver.rval * Math.sin(convdr * ball_spin_angle))) + yt2;
              off1Gg.setColor(Color.red);
              off1Gg.drawLine(exes[0], whys[0], exes[1], whys[1]);
            }
          }
        }

        // Labels
        off1Gg.setColor(Color.black);
        off1Gg.fillRect(0, 0, 350, 30);
        off1Gg.setColor(Color.white);
        off1Gg.drawString("View:", 35, 10);
        if (viewflg == 0)
          off1Gg.setColor(Color.yellow);
        else
          off1Gg.setColor(Color.cyan);
        off1Gg.drawString("Edge", 95, 10);
        if (viewflg == 1)
          off1Gg.setColor(Color.yellow);
        else
          off1Gg.setColor(Color.cyan);
        off1Gg.drawString("Top", 145, 10);
        if (viewflg == 2)
          off1Gg.setColor(Color.yellow);
        else
          off1Gg.setColor(Color.cyan);
        off1Gg.drawString("Side-3D", 180, 10);
        off1Gg.setColor(Color.red);
        off1Gg.drawString("Find", 240, 10);

        if (displ == 0)
          off1Gg.setColor(Color.yellow);
        else
          off1Gg.setColor(Color.cyan);
        off1Gg.drawString("Streamlines", 85, 25);
        if (displ == 1)
          off1Gg.setColor(Color.yellow);
        else
          off1Gg.setColor(Color.cyan);
        off1Gg.drawString("Moving", 160, 25);
        if (displ == 2)
          off1Gg.setColor(Color.yellow);
        else
          off1Gg.setColor(Color.cyan);
        off1Gg.drawString("Frozen", 210, 25);
        if (displ == 3)
          off1Gg.setColor(Color.yellow);
        else
          off1Gg.setColor(Color.cyan);
        off1Gg.drawString("Geometry", 260, 25);
        off1Gg.setColor(Color.white);
        off1Gg.drawString("Display:", 35, 25);
        // zoom in
        off1Gg.setColor(Color.black);
        off1Gg.fillRect(0, 30, 30, 150);
        off1Gg.setColor(Color.green);
        off1Gg.drawString("Zoom", 2, 180);
        off1Gg.drawLine(15, 35, 15, 165);
        off1Gg.fillRect(5, sldloc, 20, 5);

        // display model and part in bold
        Font currentFont = off1Gg.getFont();
        off1Gg.setFont(largeFont);
        off1Gg.setColor(Color.yellow);
        off1Gg.drawString(t_foil_name + " : " + part_button.getLabel(), 20, 250);
        off1Gg.setFont(currentFont);
        off1Gg.drawString("V : " + speed_kts_mph_kmh_ms_info, 20, 275);

        g.drawImage(offImg1, 0, 0, this);
      }
    } // end Viewer
 

    class Plt extends Canvas implements Runnable {
      FoilBoardWithProblems app ;
      Thread run2 ;

      int axis_y_label_width, axis_x_label_width, plot_trace_count ;

      double begx,endx,begy,endy ;
      String labx,labxu,laby,labyu ;
      double pltx[][]  = new double[3][40] ;
      double plty[][]  = new double[3][40] ;



      Point locp,ancp;

      Solver plt_solver = new Solver();

      Plt (FoilBoardWithProblems target) { 
        setBackground(Color.blue) ;
        run2 = null ;
      }
   
      public boolean mouseUp(Event evt, int x, int y) {
        handleb(x,y) ;
        return true;                                        
      }

      public void handleb(int x, int y) {
        if (y >= 185) { 
          if (x >= 5 && x <= 55) {   //rescale
            endy = 0.0 ;
            begy = 0.0 ;
            calcrange = 0 ;
            computeFlow() ;
          }
        }
        out.plt.repaint() ;
      }

      public void start() {
        if (run2 == null) {
          run2 = new Thread(this) ;
          run2.start() ;
        }
      }

      /**
       * @j2sNative
       * 
       * this.repaint();
       * var self = this; setTimeout(function() {self.run();}, 100);
       */
      public void run() {
        int timer ;
 
        timer = 100 ;
        while (true) {
          try { Thread.sleep(timer); }
          catch (InterruptedException e) {}
          out.plt.repaint() ;
        }
      }

      // state shared between loadPlot and paint
      int lines = 1 ;

      public void loadPlot() {
        double rad,ang,xc,yc,lftref,clref,drgref,cdref ;
        double del,spd,awng,ppl,tpl,hpl,angl,thkpl,campl,clpl,cdpl ;
        int index,ic ;
        double aoa_absolute = effective_aoa();
        double alfd = aoa_absolute;

        clref =  getClplot(camval,thkval,aoa_absolute) ;
        if (Math.abs(clref) <= .001) clref = .001 ;    /* protection */
        lftref = clref * q0 * area/lconv/lconv ;
        
        thkd = thkinpt ;
        camd = caminpt ;
        //   attempt to fix symmetry problem
        if (camd < 0.0) alfd = - aoa_absolute ;
        //
        solver.getDrag(clref, alfd, thkd, camd) ;
        cdref = dragco ;
        drgref = cdref * q0 * area/lconv/lconv ;
   
        // load up the view image
        for (ic = 0; ic <= STREAMLINES_COUNT; ++ ic) {
          for (index = 0; index <= POINTS_COUNT; ++ index) {
            if (!foil_is_cylinder_or_ball(foil)) {
              xpl[ic][index] = xm[ic][index] ;
              ypl[ic][index] = ym[ic][index] ;
            } else {
              xpl[ic][index] = xg[ic][index] ;
              ypl[ic][index] = yg[ic][index] ;
            }
          }
        }
        // probe
        for (index = 0; index <= POINTS_COUNT; ++ index) {
          if (!foil_is_cylinder_or_ball(foil)) {
            xpl[19][index] = xm[19][index] ;
            ypl[19][index] = ym[19][index] ;
            pxpl = pxm ;
            pypl = pym ;
          } else {
            xpl[19][index] = xg[19][index] ;
            ypl[19][index] = yg[19][index] ;
            pxpl = pxg ;
            pypl = pyg ;
          }
        }

        //  load up surface plots
        switch (dispp) {
        case 0:// pressure variation
          npt = POINTS_COUNT_HALF ;
          plot_trace_count = 3 ;
          axis_y_label_width = axis_x_label_width = 1 ;
          for (index = 1; index <= npt; ++ index) {
            if (!foil_is_cylinder_or_ball(foil)) {
              pltx[0][index] =100.*(xpl[0][POINTS_COUNT_HALF-index + 1]/4.0 + .5) ;
              pltx[1][index] =100.*(xpl[0][POINTS_COUNT_HALF+index - 1]/4.0 + .5) ;
              pltx[2][index] =100.*(xpl[0][POINTS_COUNT_HALF+index - 1]/4.0 + .5) ;
            } else {
              pltx[0][index]=100.*(xpl[0][POINTS_COUNT_HALF-index+1]/(2.0*radius/lconv)+.5);
              pltx[1][index]=100.*(xpl[0][POINTS_COUNT_HALF+index-1]/(2.0*radius/lconv)+.5);
              pltx[2][index]=100.*(xpl[0][POINTS_COUNT_HALF+index-1]/(2.0*radius/lconv)+.5);
            }
            plty[0][index] = plp[POINTS_COUNT_HALF-index + 1] ;
            plty[1][index] = plp[POINTS_COUNT_HALF+index - 1] ;
            plty[2][index] = ps0/2116. * pconv ;
            // **** Impose pstatic on surface plot for stalled foil
            if (stall_model_type != STALL_MODEL_IDEAL_FLOW && index > 7) {
              double apos = stall_model_type == STALL_MODEL_DFLT ? +10 : stall_model_apos;
              double aneg = stall_model_type == STALL_MODEL_DFLT ? -10 : stall_model_aneg;
              if (aoa_absolute > apos) plty[0][index] = plty[2][index] ;
              if (aoa_absolute < aneg) plty[1][index] = plty[2][index] ;
            }
            // *******
          }
          begx = 0.0 ;
          endx = 100. ;
          ntikx = 5 ;
          ntiky = 5 ;
          //       endy=1.02 * ps0/2116. * pconv ;
          //       begy=.95 * ps0/2116. * pconv ;
          laby = String.valueOf("Press");
          if (lunits == IMPERIAL) labyu = String.valueOf("psi");
          if (lunits == 1) labyu = String.valueOf("k-Pa");
          labx = String.valueOf(" X ");
          if (!foil_is_cylinder_or_ball(foil)) labxu = String.valueOf("% chord");
          else labxu = String.valueOf("% diameter");
        break;
        case 1:   // velocity variation
          npt = POINTS_COUNT_HALF ;
          plot_trace_count = 3 ;
          axis_y_label_width = 2 ;
          axis_x_label_width = 1 ;
          for (index = 1; index <= npt; ++ index) {
            if (!foil_is_cylinder_or_ball(foil)) {
              pltx[0][index] = 100.*(xpl[0][POINTS_COUNT_HALF-index+1]/4.0+.5) ;
              pltx[1][index] = 100.*(xpl[0][POINTS_COUNT_HALF+index-1]/4.0+.5) ;
              pltx[2][index] = 100.*(xpl[0][POINTS_COUNT_HALF-index+1]/4.0+.5) ;
            } else {
              pltx[0][index]=100.*(xpl[0][POINTS_COUNT_HALF-index+1]/(2.0*radius/lconv)+.5);
              pltx[1][index]=100.*(xpl[0][POINTS_COUNT_HALF+index-1]/(2.0*radius/lconv)+.5);
              pltx[2][index]=100.*(xpl[0][POINTS_COUNT_HALF+index-1]/(2.0*radius/lconv)+.5);
            }
            plty[0][index] = plv[POINTS_COUNT_HALF-index+1];
            plty[1][index] = plv[POINTS_COUNT_HALF+index-1] ;
            plty[2][index] = velocity ;
            // **** Impose free stream vel on surface plot for stalled foil
            if (stall_model_type != STALL_MODEL_IDEAL_FLOW && index > 7) {
              double apos = stall_model_type == STALL_MODEL_DFLT ? +10 : stall_model_apos;
              double aneg = stall_model_type == STALL_MODEL_DFLT ? -10 : stall_model_aneg;
              if (aoa_absolute > apos) plty[0][index] = plty[2][index] ;
              if (aoa_absolute < aneg) plty[1][index] = plty[2][index] ;
            }
            // *******
          }
          begx = 0.0 ;
          endx = 100. ;
          ntikx = 5 ;
          ntiky = 6 ;
          //      begy = 0.0 ;
          //      endy = 500. ;
          laby = String.valueOf("Vel");
          if (lunits == IMPERIAL) labyu = String.valueOf("mph");
          if (lunits == 1) labyu = String.valueOf("kmh");
          labx = String.valueOf(" X ");
          if (!foil_is_cylinder_or_ball(foil)) labxu = String.valueOf("% chord");
          else labxu = String.valueOf("% diameter");

          //  load up performance plots
        break;
        case 2:  // lift or drag versus angle
          npt = 21 ;
          plot_trace_count = 1 ;
          axis_x_label_width = 2;  axis_y_label_width = 3 ;
          begx=-20.0; endx=20.0; ntikx=5;
          labx = String.valueOf("Angle ");
          labxu = String.valueOf("degrees");
          del = 40.0 / (npt-1) ;
          for (ic=1; ic <=npt; ++ic) {
            angl = -20.0 + (ic-1)*del ;
            clpl = getClplot(camval,thkval,angl) ;
            alfd = angl ;
            thkd = thkinpt ;
            camd = caminpt ;

            //   attempt to fix symmetry problem
            if (camd < 0.0) alfd = - angl ;
            //
            solver.getDrag(clpl, alfd, thkd, camd) ;
            cdpl = dragco ;

            if ( dout <= 1) {
              pltx[0][ic] = angl ;
              if (dout == 0)plty[0][ic] = fconv*lftref * clpl/clref ;
              if (dout == 1)plty[0][ic] = 100.*clpl ;
            }
            else {
              pltx[0][ic] = angl ;
              if (dout == 2)plty[0][ic] = fconv*drgref * cdpl/cdref ;
              if (dout == 3)plty[0][ic] = 100.*cdpl ;
            }
          }
          ntiky = 5 ;
          pltx[1][0] = aoa_absolute ;
          if (dout == 0) {
            laby = String.valueOf("Lift");
            if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
            if (lunits == 1) labyu = String.valueOf("N");
            plty[1][0] = lftref*fconv ;
          }
          if (dout == 1) {
            laby = String.valueOf("Cl");
            labyu = String.valueOf("x 100 ");
            plty[1][0] = 100.*clift ;
          }
          if (dout == 2) {
            laby = String.valueOf("Drag");
            if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
            if (lunits == 1) labyu = String.valueOf("N");
            plty[1][0] = drgref*fconv ;
          }
          if (dout == 3) {
            laby = String.valueOf("Cd");
            labyu = String.valueOf("x 100 ");
            plty[1][0] = 100.*dragCoeff ;
          }              
      
        break;
        case 3:   // lift or drag versus thickness
          npt = 20 ;
          plot_trace_count = 1 ;
          axis_x_label_width = 3;  axis_y_label_width = 3 ;
          begx=0.0; endx=20.0; ntikx=5;
          labx = String.valueOf("Thickness ");
          labxu = String.valueOf("% chord");
          del = 1.0 / (npt) ;
          for (ic=1; ic <=npt; ++ic) {
            thkpl = .05 + (ic-1)*del ;
            clpl = getClplot(camval,thkpl,aoa_absolute) ;
            alfd = aoa_absolute ;
            thkd = thkpl*25.0 ;
            camd = caminpt ;
            //   attempt to fix symmetry problem
            if (camd < 0.0) alfd = - aoa_absolute ;
            //
            solver.getDrag(clpl, alfd, thkd, camd) ;
            cdpl = dragco ;

            if ( dout <= 1) {
              pltx[0][ic] = thkpl*25. ;
              if (dout == 0)plty[0][ic] = fconv*lftref * clpl/clref ;
              if (dout == 1)plty[0][ic] = 100.*clpl ;
            }
            else {
              pltx[0][ic] = thkd ;
              if (dout == 2)plty[0][ic] = fconv*drgref * cdpl/cdref ;
              if (dout == 3)plty[0][ic] = 100.*cdpl ;
            }
          }
          ntiky = 5 ;
          pltx[1][0] = thkinpt ;
          if (dout == 0) {
            laby = String.valueOf("Lift");
            if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
            if (lunits == 1) labyu = String.valueOf("N");
            plty[1][0] = lftref*fconv ;
          }
          if (dout == 1) {
            laby = String.valueOf("Cl");
            labyu = String.valueOf("x 100 ");
            plty[1][0] = 100.*clift ;
          }
          if (dout == 2) {
            laby = String.valueOf("Drag");
            if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
            if (lunits == 1) labyu = String.valueOf("N");
            plty[1][0] = drgref*fconv ;
            plty[0][npt]= plty[0][npt-1]= plty[0][npt-2]=plty[0][npt-3]=plty[0][npt-4] ;
          }
          if (dout == 3) {
            laby = String.valueOf("Cd");
            labyu = String.valueOf("x 100 ");
            plty[1][0] = 100.*dragCoeff ;
            plty[0][npt] = plty[0][npt-1] = plty[0][npt-2]=plty[0][npt-3]=plty[0][npt-4] ;
          }

        break;
        case 4:   // lift or drag versus camber
          npt = 21 ;
          plot_trace_count = 1 ;
          axis_x_label_width = 4;  axis_y_label_width = 3 ;
          begx=-20.; endx=20.; ntikx=5;
          labx = String.valueOf("Camber ");
          labxu = String.valueOf("% chord");
          del = 2.0 / (npt-1) ;
          for (ic=1; ic <=npt; ++ic) {
            campl = -1.0 + (ic-1)*del ;
            clpl = getClplot(campl,thkval,aoa_absolute) ;
            alfd = aoa_absolute ;
            thkd = thkinpt ;
            camd = campl * 25.0 ;
            //   attempt to fix symmetry problem
            if (camd < 0.0) alfd = - aoa_absolute ;
            //
            solver.getDrag(clpl, alfd, thkd, camd) ;
            cdpl = dragco ;

            if ( dout <= 1) {
              pltx[0][ic] = campl*25.0 ;
              if (dout == 0)plty[0][ic] = fconv*lftref * clpl/clref ;
              if (dout == 1)plty[0][ic] = 100.*clpl ;
            }
            else {
              pltx[0][ic] = camd  ;
              if (dout == 2)plty[0][ic] = fconv*drgref * cdpl/cdref ;
              if (dout == 3)plty[0][ic] = 100.*cdpl ;
            }
          }
          ntiky = 5 ;
          pltx[1][0] = caminpt ;
          if (dout == 0) {
            laby = String.valueOf("Lift");
            if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
            if (lunits == 1) labyu = String.valueOf("N");
            plty[1][0] = lftref*fconv ;
          }
          if (dout == 1) {
            laby = String.valueOf("Cl");
            labyu = String.valueOf("x 100 ");
            plty[1][0] = 100.*clift ;
          }
          if (dout == 2) {
            laby = String.valueOf("Drag");
            if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
            if (lunits == 1) labyu = String.valueOf("N");
            plty[1][0] = drgref*fconv ;
            plty[0][1] = plty[0][2]= plty[0][3] ;
            plty[0][npt] = plty[0][npt -1] = plty[0][npt - 2] ;
          }
          if (dout == 3) {
            laby = String.valueOf("Cd");
            labyu = String.valueOf("x 100 ");
            plty[1][0] = 100.*dragCoeff ;
            plty[0][1] = plty[0][2]= plty[0][3] ;
            plty[0][npt] = plty[0][npt -1] = plty[0][npt-2] ;
          }
        break;
        case 5:   // lift and drag versus speed
          npt = 20 ;
          plot_trace_count = 1 ;
          axis_x_label_width = 5;  axis_y_label_width = 3 ;
          begx=0.0; endx=300.0; ntikx=7;
          labx = String.valueOf("Speed ");
          if (lunits == IMPERIAL) labxu = String.valueOf("mph");
          if (lunits == 1) labxu = String.valueOf("kmh");
          del = vmax / npt ;
          for (ic=1; ic <=npt; ++ic) {
            spd = (ic-1)*del ;
            pltx[0][ic] = spd ;
            if (doutb == 0) plty[0][ic] = fconv*lftref * spd * spd / (velocity * velocity) ;
            if (doutb == 1) plty[0][ic] = fconv*drgref * spd * spd / (velocity * velocity) ;
          }
          ntiky = 5 ;
          if (doutb == 0) laby = String.valueOf("Lift");
          if (doutb == 1) laby = String.valueOf("Drag");
          pltx[1][0] = velocity ;
          if (doutb == 0) plty[1][0] = lftref*fconv ;
          if (doutb == 1) plty[1][0] = drgref*fconv ;
          if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
          if (lunits == 1) labyu = String.valueOf("N");

        break;
        case 6:   // lift and drag versus altitude
          npt = 20 ;
          plot_trace_count = 1 ;
          axis_x_label_width = 6;  axis_y_label_width = 3 ;
          begx=0.0; endx=50.0; ntikx=6;
          if (lunits == IMPERIAL) endx = 50.0 ;
          if (lunits == 1) endx = 15.0 ;
          labx = String.valueOf("Altitude");
          if (lunits == IMPERIAL) labxu = String.valueOf("k-ft");
          if (lunits == 1) labxu = String.valueOf("km");
          del = altmax / npt ;
          for (ic=1; ic <=npt; ++ic) {
            hpl = (ic-1)*del ;
            pltx[0][ic] = lconv*hpl/1000. ;
            tpl = 518.6 ;
            ppl = 2116. ;
            if (planet == 0) {
              if (hpl < 36152.)   {
                tpl = 518.6 - 3.56 * hpl /1000. ;
                ppl = 2116. * Math.pow(tpl/518.6, 5.256) ;
              }
              else {
                tpl = 389.98 ;
                ppl = 2116. * .236 * Math.exp((36000.-hpl)/(53.35*tpl)) ;
              }
              if (doutb == 0) plty[0][ic] = fconv*lftref * ppl/(tpl*53.3*32.17) / rho ;
              if (doutb == 1) plty[0][ic] = fconv*drgref * ppl/(tpl*53.3*32.17) / rho ;
            }
            if (planet == 1) {
              if (hpl <= 22960.) {
                tpl = 434.02 - .548 * hpl/1000. ;
                ppl = 14.62 * Math.pow(2.71828,-.00003 * hpl) ;
              }
              if (hpl > 22960.) {
                tpl = 449.36 - 1.217 * hpl/1000. ;
                ppl = 14.62 * Math.pow(2.71828,-.00003 * hpl) ;
              }
              if (doutb == 0) plty[0][ic] = fconv*lftref * ppl/(tpl*1149.) / rho ;
              if (doutb == 1) plty[0][ic] = fconv*drgref * ppl/(tpl*1149.) / rho ;
            }
            if (planet == 2) {
              if (doutb == 0) plty[0][ic] = fconv*lftref ;
              if (doutb == 1) plty[0][ic] = fconv*drgref ;
            }
          }
          ntiky = 5 ;
          if (doutb == 0) laby = String.valueOf("Lift");
          if (doutb == 1) laby = String.valueOf("Drag");
          pltx[1][0] = alt/1000. ;
          if (doutb == 0) plty[1][0] = lftref*fconv ;
          if (doutb == 1) plty[1][0] = drgref*fconv ;
          if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
          if (lunits == 1) labyu = String.valueOf("N");
          
        break;
        case 7:  // lift and drag versus area
          npt = 2 ;
          plot_trace_count = 1 ;
          axis_x_label_width = 7;  axis_y_label_width = 3 ;
          begx=0.0; ntikx=6;
          labx = String.valueOf("Area ");
          if (lunits == IMPERIAL) {
            labxu = String.valueOf("sq ft");
            endx = 2000.0 ;
            labyu = String.valueOf("lbs");
            pltx[0][1] = 0.0 ;
            plty[0][1] = 0.0 ;
            pltx[0][2] = 2000. ;
            if (doutb == 0) plty[0][2] = fconv*lftref * 2000. /area ;
            if (doutb == 1) plty[0][2] = fconv*drgref * 2000. /area ;
          }
          if (lunits == 1) {
            labxu = String.valueOf("sq m");
            endx = 200. ;
            labyu = String.valueOf("N");
            pltx[0][1] = 0.0 ;
            plty[0][1] = 0.0 ;
            pltx[0][2] = 200. ;
            if (doutb == 0) plty[0][2] = fconv*lftref * 200. /area ; 
            if (doutb == 1) plty[0][2] = fconv*drgref * 200. /area ; 
          }

          ntiky = 5 ;
          pltx[1][0] = area ;
          if (doutb == 0) {
            laby = String.valueOf("Lift");
            plty[1][0] = lftref*fconv ;
          }
          else {
            laby = String.valueOf("Drag");
            plty[1][0] = drgref*fconv ;
          }
          
        break;
        case 8:   // lift and drag versus density
          npt = 2 ;
          plot_trace_count = 1 ;
          axis_x_label_width = 7; axis_y_label_width = 3 ;
          begx=0.0; ntikx=6;
          labx = String.valueOf("Density ");
          if (planet == 0) {
            if (lunits == IMPERIAL) {
              labxu = String.valueOf("x 10,000 slug/cu ft");
              endx = 25.0 ;
              pltx[0][1] = 0.0 ;
              plty[0][1] = 0.0 ;
              pltx[0][2] = 23.7 ;
              if (doutb == 0) plty[0][2] = fconv*lftref * 23.7 /(rho*10000.);
              if (doutb == 1) plty[0][2] = fconv*drgref * 23.7 /(rho*10000.);
              pltx[1][0] = rho*10000. ;
            }
            if (lunits == 1) {
              labxu = String.valueOf("g/cu m");
              endx = 1250. ;
              pltx[0][1] = 0.0 ;
              plty[0][1] = 0.0 ;
              pltx[0][2] = 1226 ;
              if (doutb == 0) plty[0][2] = fconv*lftref * 23.7 /(rho*10000.);
              if (doutb == 1) plty[0][2] = fconv*drgref * 23.7 /(rho*10000.);
              pltx[1][0] = rho*1000.*515.4 ;
            }
          }

          if (planet == 1) {
            if (lunits == IMPERIAL) {
              labxu = String.valueOf("x 100,000 slug/cu ft");
              endx = 5.0 ;
              pltx[0][1] = 0.0 ;
              plty[0][1] = 0.0 ;
              pltx[0][2] = 2.93 ;
              if (doutb == 0) plty[0][2] = fconv*lftref * 2.93 /(rho*100000.);
              if (doutb == 1) plty[0][2] = fconv*drgref * 2.93 /(rho*100000.);
              pltx[1][0] = rho*100000. ;
            }
            if (lunits == 1) {
              labxu = String.valueOf("g/cu m");
              endx = 15. ;
              pltx[0][1] = 0.0 ;
              plty[0][1] = 0.0 ;
              pltx[0][2] = 15.1 ;
              if (doutb == 0) plty[0][2] = fconv*lftref * 2.93 /(rho*100000.);
              if (doutb == 1) plty[0][2] = fconv*drgref * 2.93 /(rho*100000.);
              pltx[1][0] = rho*1000.*515.4 ;
            }
          }
          ntiky = 5 ;
          if (doutb == 0) laby = String.valueOf("Lift");
          if (doutb == 1) laby = String.valueOf("Drag");
          if (doutb == 0) plty[1][0] = lftref*fconv ;
          if (doutb == 1) plty[1][0] = drgref*fconv ;
          if (lunits == IMPERIAL) labyu = String.valueOf("lbs");
          if (lunits == 1) labyu = String.valueOf("N");
          
        break;
        case 9:   // drag polar
          npt = 20 ;
          plot_trace_count = 1 ;
          axis_x_label_width = 4;  axis_y_label_width = 3 ;
          ntikx=5;
          del = 40.0 / npt ;
          for (ic=1; ic <=npt; ++ic) {
            angl = -20.0 + (ic-1)*del ;
            clpl = getClplot(camval,thkval,angl) ;
            plty[0][ic] = clpl ;
            alfd = angl ;
            thkd = thkinpt ;
            camd = caminpt ;
            //   attempt to fix symmetry problem
            if (camd < 0.0) alfd = - angl ;
            //
            solver.getDrag(clpl, alfd, thkd, camd) ;
            cdpl = dragco ;
            pltx[0][ic] = cdpl ;
          }
          ntiky = 5 ;
          pltx[1][0] = cdref;
          plty[1][0] = clref;
          labx = String.valueOf("Cd");
          labxu = String.valueOf("");
          laby = String.valueOf("Cl");
          labyu = String.valueOf("");
        default:;
        }              

        if (dispp>= 2 && dispp < 6) {  // determine y - range zero in middle
          if(dout <=1) {
            if (plty[0][npt] >= plty[0][1]) {
              begy=0.0 ;
              if (plty[0][1]   > endy) endy = plty[0][1]  ;
              if (plty[0][npt] > endy) endy = plty[0][npt]  ;
              if (endy <= 0.0) {
                begy = plty[0][1] ;
                endy = plty[0][npt] ;
              }
            }
            if (plty[0][npt] < plty[0][1]) {
              endy = 0.0 ;
              if (plty[0][1]   < begy) begy = plty[0][1]  ;
              if (plty[0][npt] < begy) begy = plty[0][npt]  ;
              if (begy <= 0.0) {
                begy = plty[0][npt] ;
                endy = plty[0][1] ;
              }
            }
          }
          else {
            begy = 0.0 ;
            endy = 0.0 ;
            for (index =1; index <= npt; ++ index) {
              if (plty[0][index] > endy) endy = plty[0][index] ;
            }
          }
        }

        if (dispp >= 6 && dispp <= 8) {    // determine y - range
          if (plty[0][npt] >= plty[0][1]) {
            begy = plty[0][1]  ;
            endy = plty[0][npt]  ;
          }
          if (plty[0][npt] < plty[0][1]) {
            begy = plty[0][npt]  ;
            endy = plty[0][1]  ;
          }
        }

        if (dispp == 9) {    // determine y - range and x- range
          begx = 0.0 ;
          endx = 0.0 ;
          for (index =1; index <= npt; ++ index) {
            if (pltx[0][index] > endx) endx = pltx[0][index] ;
          }

          begy = plty[0][1]  ;
          endy = plty[0][1] ;
          for (index =1; index <= npt; ++ index) {
            if (plty[0][index] > endy) endy = plty[0][index] ;
          }
        }

        if (dispp >= 0 && dispp <= 1) {    // determine y - range
          if (calcrange == 0) {
            begy = plty[0][1] ;
            endy = plty[0][1] ;
            for (index = 1; index <= POINTS_COUNT_HALF; ++ index) {
              if (plty[0][index] < begy) begy = plty[0][index] ;
              if (plty[1][index] < begy) begy = plty[1][index] ;
              if (plty[0][index] > endy) endy = plty[0][index] ;
              if (plty[1][index] > endy) endy = plty[1][index] ;
            }
            calcrange = 1 ;
          }
        }
      }


      // camb_val and thic_val are in %/25, angl is in degrees
      public double getClplot(double camb_val, double thic_val, double angl) {
        // return new Solver(angl, thic_val*25, camb_val*25).getClift(angl);
        Solver s = plt_solver;
        s.getFreeStream () ;
        s.getCirculation(angl, thic_val*25, camb_val*25);
        double cl = s.getClift(angl);
        // System.out.println("-- s: " + s + " cl: " + cl);
        return cl;
      }
      
      // // old. this was replica of solver.getCirculation & getClift
      // public double getClplot_(double camb, double thic, double angl) {
      //   double number ;
      //   double yc = camb / 2.0 ;
      //   double rc = thic/4.0 + Math.sqrt( thic*thic/16.0 + yc*yc + 1.0);
      //   double xc = 1.0 - Math.sqrt(rc*rc - yc*yc) ;
      //   double beta = Math.asin(yc/rc)/convdr ;       /* Kutta condition */
      //   double gamc = 2.0*rc*Math.sin((angl+beta)*convdr) ;
      //   double lec = xc - Math.sqrt(rc*rc - yc*yc) ;
      //   double tec = xc + Math.sqrt(rc*rc - yc*yc) ;
      //   double lecm = lec + 1.0/lec ;
      //   double tecm = tec + 1.0/tec ;
      //   double crdc = tecm - lecm ;
      // 
      //   // stall model 1
      //   double stfact = 1.0 ;
      // 
      //   switch (stall_model_type) {
      //   case STALL_MODEL_DFLT:
      //     if (angl > 10 ) {
      //       stfact = .5 + .1 * angl - .005 * angl * angl ;
      //     } else if (angl < -10 ) {
      //       stfact = .5 - .1 * angl - .005 * angl * angl ;
      //     }
      //     break;
      //   case STALL_MODEL_REFINED:
      //     // stfact = stall_model_k0 + stall_model_k1 * Math.abs(angl) + stall_model_k2 * angl * angl ;
      //     if (angl > stall_model_apos ) {
      //       stfact = stall_model_k0 + stall_model_k1 * +angl + stall_model_k2 * angl * angl ;
      //     } else if (angl < stall_model_aneg ) {
      //       stfact = stall_model_k0 + stall_model_k1 * -angl + stall_model_k2 * angl * angl ;
      //     }
      //   break;
      //   case STALL_MODEL_IDEAL_FLOW:
      //   default:
      //     // do nothing. stfact = 1
      //   }
      // 
      //   number = stfact*gamc*4.0*3.1415926/crdc ;
      // 
      //   if (ar_lift_corr == 1) {  // correction for low aspect ratio
      //     number = number /(1.0 + Math.abs(number)/(3.14159*aspr)) ;
      //   }
      // 
      //   return (number) ;
      // }
   
      public void update(Graphics g) {
        out.plt.paint(g) ;
      }
   
      public void paint(Graphics g) {
        int i,j,k,n,index ;
        int xlabel,ylabel,ind,inmax,inmin ;
        int exes[] = new int[8] ;
        int whys[] = new int[8] ;
        double offx,scalex,offy,scaley,waste,incy,incx;
        double xl,yl;
        double liftab,dragab ;
        Color col ;

        if (dispp <= 1) {
          off2Gg.setColor(Color.black) ;
          off2Gg.fillRect(0,0,350,350) ;
          off2Gg.setColor(Color.white) ;
          off2Gg.fillRect(2,185,70,20) ;
          off2Gg.setColor(Color.red) ;
          off2Gg.drawString("Rescale",8,200) ;
        }
        if (dispp > 1 && dispp <= 15) {
          off2Gg.setColor(Color.blue) ;
          off2Gg.fillRect(0,0,350,350) ;
          off2Gg.setColor(Color.white) ;
          off2Gg.fillRect(2,185,70,20) ;
          off2Gg.setColor(Color.red) ;
          off2Gg.drawString("Rescale",8,200) ;
        }
        if (dispp == 20) {
          off2Gg.setColor(Color.black) ;
          off2Gg.fillRect(0,0,350,350) ;
          off2Gg.setColor(Color.white) ;
          off2Gg.drawString("Output",10,10) ;
        }
 
        if (ntikx < 2) ntikx = 2 ;     /* protection 13June96 */
        if (ntiky < 2) ntiky = 2 ;
        offx = 0.0 - begx ;
        scalex = 6.0/(endx-begx) ;
        incx = (endx-begx)/(ntikx-1);
        offy = 0.0 - begy ;
        scaley = 4.5/(endy-begy) ;
        incy = (endy-begy)/(ntiky-1) ;
 
        if (dispp <= 15) {             /*  draw a graph */
          /* draw axes */
          off2Gg.setColor(Color.white) ;
          exes[0] = (int) (factp* 0.0) + xtp ;
          whys[0] = (int) (factp* -4.5) + ytp ;
          exes[1] = (int) (factp* 0.0) + xtp ;
          whys[1] = (int) (factp* 0.0) + ytp ;
          exes[2] = (int) (factp* 6.0) + xtp ;
          whys[2] = (int) (factp* 0.0) + ytp ;
          off2Gg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
          off2Gg.drawLine(exes[1],whys[1],exes[2],whys[2]) ;
 
          xlabel = (int) (-90.0) + xtp ;   /*  label y axis */
          ylabel = (int) (factp*-1.5) + ytp ;
          off2Gg.drawString(laby,xlabel,ylabel) ;
          off2Gg.drawString(labyu,xlabel,ylabel+10) ;
          /* add tick values */
          for (ind= 1; ind<= ntiky; ++ind){
            xlabel = (int) (-50.0) + xtp ;
            yl = begy + (ind-1) * incy ;
            ylabel = (int) (factp* -scaley*(yl + offy)) + ytp ;
            if (axis_y_label_width >= 2) {
              if (endy >= 100.0) {
                off2Gg.drawString(String.valueOf((int) yl),xlabel,ylabel) ;
              }
              if (endy <= 100.0 && endy >= 1.0) {
                off2Gg.drawString(String.valueOf(filter1(yl)),xlabel,ylabel) ;
              }
              if (endy <= 1.0) {
                off2Gg.drawString(String.valueOf(filter3(yl)),xlabel,ylabel) ;
              }
            }
            else {
              off2Gg.drawString(String.valueOf(filter3(yl)),xlabel,ylabel);
            }
          }
          xlabel = (int) (factp*3.0) + xtp ;    /* label x axis */
          ylabel = (int) (40.0) + ytp ;
          off2Gg.drawString(labx,xlabel,ylabel-10) ;
          off2Gg.drawString(labxu,xlabel,ylabel) ;
          /* add tick values */
          for (ind= 1; ind<= ntikx; ++ind){
            ylabel = (int) (15.) + ytp ;
            xl = begx + (ind-1) * incx ;
            xlabel = (int) (factp*(scalex*(xl + offx) -.05)) + xtp ;

            if (axis_x_label_width == 1) {
              off2Gg.drawString(String.valueOf(xl),xlabel,ylabel) ;
            } else if (endx >= 10)
              off2Gg.drawString(String.valueOf((int)xl),xlabel,ylabel) ;
            else
              off2Gg.drawString(String.valueOf(filter3(xl)),xlabel,ylabel) ;
          }
       
          if (lines == 0) {
            for (i=1; i<=npt; ++i) {
              xlabel = (int) (factp*scalex*(offx+pltx[0][i])) + xtp ;
              ylabel = (int)(factp*-scaley*(offy+plty[0][i]) +7.)+ytp;
              off2Gg.drawString("*",xlabel,ylabel) ;
            }
          }
          else {
            if (dispp <= 1) {
              for (j=0; j<= plot_trace_count-1; ++j) {
                k = 2 -j ;
                if (k == 0) {
                  off2Gg.setColor(Color.magenta) ;
                  xlabel = (int) (factp* 6.1) + xtp ;
                  ylabel = (int) (factp* -2.5) + ytp ;
                  off2Gg.drawString("Upper",xlabel,ylabel) ;
                }
                if (k == 1) {
                  off2Gg.setColor(Color.yellow) ;
                  xlabel = (int) (factp* 6.1) + xtp ;
                  ylabel = (int) (factp* -1.5) + ytp ;
                  off2Gg.drawString("Lower",xlabel,ylabel) ;
                }
                if (k == 2) {
                  off2Gg.setColor(Color.green) ;
                  xlabel = (int) (factp* 2.0) + xtp ;
                  ylabel = (int) (factp* -5.0) + ytp ;
                  off2Gg.drawString("Free Stream",xlabel,ylabel) ;
                }
                exes[1] = (int) (factp*scalex*(offx+pltx[k][1])) + xtp;
                whys[1] = (int) (factp*-scaley*(offy+plty[k][1]))+ ytp;
                for (i=1; i<=npt; ++i) {
                  exes[0] = exes[1] ;
                  whys[0] = whys[1] ;
                  exes[1] = (int)(factp*scalex*(offx+pltx[k][i]))+xtp;
                  whys[1] = (int)(factp*-scaley*(offy+plty[k][i]))+ytp;
                  off2Gg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                }
              }
            }
            if (dispp > 1) {
              off2Gg.setColor(Color.white) ;
              exes[1] = (int) (factp*scalex*(offx+pltx[0][1])) + xtp;
              whys[1] = (int) (factp*-scaley*(offy+plty[0][1])) + ytp;
              for (i=2; i<=npt; ++i) {
                exes[0] = exes[1] ;
                whys[0] = whys[1] ;
                exes[1] = (int) (factp*scalex*(offx+pltx[0][i])) + xtp;
                whys[1] = (int) (factp*-scaley*(offy+plty[0][i])) + ytp;
                off2Gg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
              }
              xlabel = (int) (factp*scalex*(offx+pltx[1][0])) + xtp ;
              ylabel = (int)(factp*-scaley*(offy+plty[1][0]))+ytp -4;
              off2Gg.setColor(Color.red) ;
              off2Gg.fillOval(xlabel,ylabel,5,5) ;
            }
          }
        }

        if(dispp == 20)  {      /*  draw the lift and drag gauge */
          off2Gg.setColor(Color.black) ;
          off2Gg.fillRect(0,100,300,30) ;
          // Thermometer Lift gage
          off2Gg.setColor(Color.white) ;
          if (lftout == 0) {
            off2Gg.drawString("Lift =",70,75) ;
            if (lunits == IMPERIAL) off2Gg.drawString("Pounds",190,75) ;
            if (lunits == 1) off2Gg.drawString("Newtons",190,75) ;
          }
          else if (lftout == 1) 
            off2Gg.drawString(" Cl  =",70,185) ;
          // Thermometer Drag gage
          if (dragOut == 0) {
            off2Gg.drawString("Drag =",70,185) ;
            if (lunits == IMPERIAL) off2Gg.drawString("Pounds",190,185) ;
            if (lunits == 1) off2Gg.drawString("Newtons",190,185) ;
          }
          if (dragOut == 1) off2Gg.drawString(" Cd  =",70,185) ;

          off2Gg.setColor(Color.yellow);
          for (index=0 ; index <= 10; index ++) {
            off2Gg.drawLine(7+index*25,100,7+index*25,110) ;
            off2Gg.drawString(String.valueOf(index),5+index*25,125) ;
            off2Gg.drawLine(7+index*25,130,7+index*25,140) ;
          }
          // Lift value
          liftab = lift ;
          if (lftout == 0) {
            if (Math.abs(lift) <= 1.0) {
              liftab = lift*10.0 ;
              off2Gg.setColor(Color.cyan);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("-1",180,70) ;
            }
            if (Math.abs(lift) > 1.0 && Math.abs(lift) <= 10.0) {
              liftab = lift ;
              off2Gg.setColor(Color.yellow);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("0",180,70) ;
            }
            if (Math.abs(lift) > 10.0 && Math.abs(lift) <=100.0) {
              liftab = lift/10.0 ;
              off2Gg.setColor(Color.green);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("1",180,70) ;
            }
            if (Math.abs(lift) > 100.0 && Math.abs(lift) <=1000.0) {
              liftab = lift/100.0 ;
              off2Gg.setColor(Color.red);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("2",180,70) ;
            }
            if (Math.abs(lift) > 1000.0 && Math.abs(lift) <=10000.0) {
              liftab = lift/1000.0 ;
              off2Gg.setColor(Color.magenta);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("3",180,70) ;
            }
            if (Math.abs(lift) > 10000.0 && Math.abs(lift) <=100000.0) {
              liftab = lift/10000.0 ;
              off2Gg.setColor(Color.orange);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("4",180,70) ;
            }
            if (Math.abs(lift) > 100000.0 && Math.abs(lift) <=1000000.0) {
              liftab = lift/100000.0 ;
              off2Gg.setColor(Color.white);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("5",180,70) ;
            }
            if (Math.abs(lift) > 1000000.0) {
              liftab = lift/1000000.0 ;
              off2Gg.setColor(Color.white);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("6",180,70) ;
            }
          }
          
          if (lftout == 1) {
            liftab = clift ;
            if (Math.abs(clift) <= 1.0) {
              liftab = clift*10.0 ;
              off2Gg.setColor(Color.cyan);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("-1",180,70) ;
            }
            if (Math.abs(clift) > 1.0 && Math.abs(clift) <= 10.0) {
              liftab = clift ;
              off2Gg.setColor(Color.yellow);
              off2Gg.fillRect(0,100,7 + (int) (25*Math.abs(liftab)),10) ;
              off2Gg.drawString("0",180,70) ;
            }
          }
          // Drag value
          dragab = drag ;
          if (dragOut == 0) {
            if (Math.abs(drag) <= 1.0) {
              dragab = drag*10.0 ;
              off2Gg.setColor(Color.cyan);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("-1",180,180) ;
            }
            if (Math.abs(drag) > 1.0 && Math.abs(drag) <= 10.0) {
              dragab = drag ;
              off2Gg.setColor(Color.yellow);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("0",180,180) ;
            }
            if (Math.abs(drag) > 10.0 && Math.abs(drag) <=100.0) {
              dragab = drag/10.0 ;
              off2Gg.setColor(Color.green);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("1",180,180) ;
            }
            if (Math.abs(drag) > 100.0 && Math.abs(drag) <=1000.0) {
              dragab = drag/100.0 ;
              off2Gg.setColor(Color.red);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("2",180,180) ;
            }
            if (Math.abs(drag) > 1000.0 && Math.abs(drag) <=10000.0) {
              dragab = drag/1000.0 ;
              off2Gg.setColor(Color.magenta);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("3",180,180) ;
            }
            if (Math.abs(drag) > 10000.0 && Math.abs(drag) <=100000.0) {
              dragab = drag/10000.0 ;
              off2Gg.setColor(Color.orange);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("4",180,180) ;
            }
            if (Math.abs(drag) > 100000.0 && Math.abs(drag) <=1000000.0) {
              dragab = drag/100000.0 ;
              off2Gg.setColor(Color.white);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("5",180,180) ;
            }
            if (Math.abs(drag) > 1000000.0) {
              dragab = drag/1000000.0 ;
              off2Gg.setColor(Color.white);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("6",180,180) ;
            }
          }
          
          if (dragOut == 1) {
            dragab = dragCoeff ;
            if (Math.abs(dragCoeff) <= .1) {
              dragab = dragCoeff*100.0 ;
              off2Gg.setColor(Color.magenta);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("-2",180,180) ;
            }
            if (Math.abs(dragCoeff) > .1 && Math.abs(dragCoeff) <= 1.0) {
              dragab = dragCoeff*10.0 ;
              off2Gg.setColor(Color.cyan);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("-1",180,180) ;
            }
            if (Math.abs(dragCoeff) > 1.0 && Math.abs(dragCoeff) <= 10.0) {
              dragab = dragCoeff ;
              off2Gg.setColor(Color.yellow);
              off2Gg.fillRect(0,130,7 + (int) (25*Math.abs(dragab)),10) ;
              off2Gg.drawString("0",180,180) ;
            }
          }

          off2Gg.setColor(Color.white);
          off2Gg.drawString(String.valueOf(filter3(liftab)),110,75) ;
          off2Gg.drawString(" X 10 ",150,75) ;
          off2Gg.drawString(String.valueOf(filter3(dragab)),110,185) ;
          off2Gg.drawString(" X 10 ",150,185) ;
        }
        g.drawImage(offImg2,0,0,this) ;   
      }
    }     // Plt 

    class Prb extends Panel {
      FoilBoardWithProblems app ;
      L l ;
      R r ;

      Prb (FoilBoardWithProblems target) {

        app = target ;
        setLayout(new GridLayout(1,2,5,5)) ;

        l = new L(app) ;
        r = new R(app) ;

        add(l) ;
        add(r) ;
      }

      class L extends Panel {
        FoilBoardWithProblems app ;
        Label l01 ;
        Button bt1,bt2,bt3 ;
     
        L (FoilBoardWithProblems target) {
          app = target ;
          setLayout(new GridLayout(4,1,10,10)) ;

          l01 = new Label("Probe", Label.CENTER) ;
          l01.setForeground(Color.red) ;

          bt1 = new Button("Velocity") ;
          bt1.setBackground(Color.white) ;
          bt1.setForeground(Color.blue) ;

          bt2 = new Button("Pressure") ;
          bt2.setBackground(Color.white) ;
          bt2.setForeground(Color.blue) ;

          bt3 = new Button("Smoke") ;
          bt3.setBackground(Color.white) ;
          bt3.setForeground(Color.blue) ;
          add(l01) ;
          add(bt1) ;
          add(bt2) ;
          add(bt3) ;
        }

        public boolean action(Event evt, Object arg) {
          if(evt.target instanceof Button) {
            String label = (String)arg ;
            if(label.equals("Velocity")) {
              pboflag = 1 ;
              bt1.setBackground(Color.yellow) ;
              bt2.setBackground(Color.white) ;
              bt3.setBackground(Color.white) ;
            }
            if(label.equals("Pressure")) {
              pboflag = 2 ;
              bt2.setBackground(Color.yellow) ;
              bt1.setBackground(Color.white) ;
              bt3.setBackground(Color.white) ;
            }
            if(label.equals("Smoke")) {
              pboflag = 3 ;
              bt3.setBackground(Color.yellow) ;
              bt2.setBackground(Color.white) ;
              bt1.setBackground(Color.white) ;
            }

            computeFlow() ;
            return true ;
          }
          else return false ;
        } // Handler
      }  // Inl

      class R extends Panel {
        FoilBoardWithProblems app ;
        Scrollbar s1,s2;
        L2 l2;
        Button bt4 ;

        R (FoilBoardWithProblems target) {

          app = target ;
          setLayout(new BorderLayout(5,5)) ;

          s1 = new Scrollbar(Scrollbar.VERTICAL,550,10,0,1000);
          s2 = new Scrollbar(Scrollbar.HORIZONTAL,550,10,0,1000);

          l2 = new L2(app) ;

          bt4 = new Button("OFF") ;
          bt4.setBackground(Color.red) ;
          bt4.setForeground(Color.white) ;

          add("West",s1) ;
          add("South",s2) ;
          add("Center",l2) ;
          add("North",bt4) ;
        }

        public boolean handleEvent(Event evt) {
          if(evt.id == Event.ACTION_EVENT) {
            pboflag = 0 ;
            l.bt3.setBackground(Color.white) ;
            l.bt2.setBackground(Color.white) ;
            l.bt1.setBackground(Color.white) ;
            computeFlow() ;
            return true ;
          }
          if(evt.id == Event.SCROLL_ABSOLUTE) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_LINE_DOWN) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_LINE_UP) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_PAGE_DOWN) {
            this.handleBar(evt) ;
            return true ;
          }
          if(evt.id == Event.SCROLL_PAGE_UP) {
            this.handleBar(evt) ;
            return true ;
          }
          else return false ;
        }

        public void handleBar(Event evt) {
          int i1,i2 ;

          i1 = s1.getValue() ;
          i2 = s2.getValue() ;

          ypval = 5.0 - i1 * 10.0/ 1000. ;
          xpval = i2 * 20.0/ 1000. -10.0 ;
    
          computeFlow() ;
        }

        class L2 extends Canvas  {
          FoilBoardWithProblems app ;

          L2 (FoilBoardWithProblems target) {
            setBackground(Color.black) ;
          }

          public void update(Graphics g) {
            out.prb.r.l2.paint(g) ;
          }

          public void paint(Graphics g) {
            int ex,ey,index ;
            double pbout ;
    
            off3Gg.setColor(Color.black) ;
            off3Gg.fillRect(0,0,150,150) ;

            if (pboflag == 0 || pboflag == 3)off3Gg.setColor(Color.gray);
            if (pboflag == 1 || pboflag == 2)off3Gg.setColor(Color.yellow) ;
            off3Gg.fillArc(20,30,80,80,-23,227) ;
            off3Gg.setColor(Color.black) ;
            // tick marks
            for (index = 1; index <= 4; ++ index) {
              ex = 60 + (int) (50.0 * Math.cos(convdr * (-22.5 + 45.0 * index))) ;
              ey = 70 - (int) (50.0 * Math.sin(convdr * (-22.5 + 45.0 * index))) ;
              off3Gg.drawLine(60,70,ex,ey) ;
            }
            off3Gg.fillArc(25,35,70,70,-25,235) ;
      
            off3Gg.setColor(Color.yellow) ;
            off3Gg.drawString("0",10,95) ;
            off3Gg.drawString("2",10,55) ;
            off3Gg.drawString("4",35,30) ;
            off3Gg.drawString("6",75,30) ;
            off3Gg.drawString("8",100,55) ;
            off3Gg.drawString("10",100,95) ;

            off3Gg.setColor(Color.green) ;
            if (pboflag == 1) {
              off3Gg.drawString("Velocity",40,15) ;
              if (lunits == IMPERIAL) off3Gg.drawString("mph",50,125) ;
              else /*METRIC*/         off3Gg.drawString("km/h",50,125) ;
            }
            if (pboflag == 2) {
              off3Gg.drawString("Pressure",30,15) ;
              if (lunits == IMPERIAL) off3Gg.drawString("psi",50,125) ;
              else /* METRIC */       off3Gg.drawString("kPa",50,125) ;
            }

            off3Gg.setColor(Color.green) ;
            off3Gg.drawString("x 10",65,110) ;

            ex = 60 ;
            ey = 70 ;
               
            pbout = 0.0 ;
            if (pbval <= .001) {
              pbout = pbval * 1000. ;
              off3Gg.drawString("-4",90,105) ;
            }
            if (pbval <= .01 && pbval > .001) {
              pbout = pbval * 100. ;
              off3Gg.drawString("-3",90,105) ;
            }
            if (pbval <= .1 && pbval > .01) {
              pbout = pbval * 10. ;
              off3Gg.drawString("-2",90,105) ;
            }
            if (pbval <= 1 && pbval > .1) {
              pbout = pbval * 10. ;
              off3Gg.drawString("-1",90,105) ;
            }
            if (pbval <= 10 && pbval > 1) {
              pbout = pbval  ;
              off3Gg.drawString("0",90,105) ;
            }
            if (pbval <= 100 && pbval > 10) {
              pbout = pbval * .1 ;
              off3Gg.drawString("1",90,105) ;
            }
            if (pbval <= 1000 && pbval > 100) {
              pbout = pbval * .01 ;
              off3Gg.drawString("2",90,105) ;
            }
            if (pbval > 1000) {
              pbout = pbval * .001 ;
              off3Gg.drawString("3",90,105) ;
            }
            off3Gg.setColor(Color.green) ;
            off3Gg.drawString(String.valueOf(filter3(pbout)),30,110) ;

            off3Gg.setColor(Color.yellow) ;
            ex = 60 - (int) (30.0 * Math.cos(convdr *
                                             (-22.5 + pbout * 225. /10.0))) ;
            ey = 70 - (int) (30.0 * Math.sin(convdr *
                                             (-22.5 + pbout * 225. /10.0))) ;
            off3Gg.drawLine(60,70,ex,ey) ;

            g.drawImage(offImg3,0,0,this) ;
          }
        } //L2
      }  // Inr
    }  // Prb

    class Perf extends Panel {
      FoilBoardWithProblems app ;
      TextArea prnt ;

      Perf (FoilBoardWithProblems target) {

        setLayout(new GridLayout(1,1,0,0)) ;

        prnt = new TextArea() ;
        prnt.setEditable(false) ;

        prnt.append("T-Hydrofoil Simulator V1.0.\nDerived from FoilSim III 1.5b beta") ;
        add(prnt) ;
      }
    }  // Perf


    class PerfWeb extends JPanel {
      FoilBoardWithProblems app ;
      javax.swing.JEditorPane prnt;

      PerfWeb (FoilBoardWithProblems target) {
        setLayout(new GridLayout(1,1,0,0)) ;
        prnt = new javax.swing.JEditorPane();
        prnt.setAutoscrolls(true);
        prnt.setContentType("text/html");
        add(prnt);
      }
    }

    class PerfWebSrc extends JPanel {
      FoilBoardWithProblems app ;
      TextArea prnt;

      PerfWebSrc (FoilBoardWithProblems target) {
        setLayout(new GridLayout(1,1,0,0)) ;
        prnt = new TextArea();
        prnt.setEditable(false) ;
        add(prnt);
      }
    }

  } // Out 


}
